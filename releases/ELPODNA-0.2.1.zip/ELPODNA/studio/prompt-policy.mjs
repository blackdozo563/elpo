import {buildPrompt} from './core.mjs';

const escapeRE=value=>String(value).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
// Keep hand-edited visual prose; replace only the reference instructions owned by the app.
export function syncReferencePrompt(scene,project){
  let prompt=scene.prompt||'';
  for(const ref of project.references){
    prompt=prompt.replace(new RegExp(escapeRE(ref.tag)+':[^\\n]*?Use the attached reference to preserve appearance\\.','g'),'');
    if(!scene.refIds.includes(ref.id))prompt=prompt.replace(new RegExp(escapeRE(ref.tag)+'(?![\\w-])','g'),'');
  }
  const refs=project.references.filter(r=>scene.refIds.includes(r.id));
  const footer=refs.map(r=>`${r.tag}: ${r.description?r.description.trim()+'. ':''}Use the attached reference to preserve appearance.`).join(' ');
  scene.prompt=[prompt.replace(/\n[ \t]*\n/g,'\n').trim(),footer].filter(Boolean).join('\n');
}
export function migratePromptMetadata(project){
  let changed=false;
  if(project.settings.style==='documentary'){project.settings.style='bold2d';changed=true;}
  for(const scene of project.scenes){
    for(const key of ['prompt','previousPrompt','visual']){
      if(typeof scene[key]!=='string')continue;
      for(const ref of project.references){
        if(!ref.name||!scene[key].includes(ref.name))continue;
        scene[key]=scene[key].split(ref.name).join('').replace(/: \. Use the attached reference/g,': Use the attached reference');changed=true;
      }
    }
  }
  return changed;
}

// Language-independent checks: Turkish prompts and hand edits are valid too.
// Deliberately reject only obvious generation loops, not stylistic preferences.
// Digit groups are not words: "1,000,000,000,000 marks" belongs in a hyperinflation story. The app's
// own reference footer repeats one sentence per reference and is not a loop either. Same rule as the
// server (youtube-analyzer src/lib/narration-prompts.ts > repetitionLoop).
export function repetitionReason(value) {
  const text=String(value||'').replace(/Use the attached reference to preserve appearance\./g,'');
  const words=text.toLocaleLowerCase('tr').match(/[\p{L}\p{N}]+/gu)||[],numeric=w=>/^\p{N}+$/u.test(w);
  let repeat=1;
  for(let i=1;i<words.length;i++){
    repeat=words[i]===words[i-1]&&!numeric(words[i])?repeat+1:1;
    if(repeat>=4)return 'word-loop';
  }
  const grams=new Map();
  for(let i=0;i+2<words.length;i++){
    const gram=words.slice(i,i+3);if(gram.some(numeric))continue;
    const key=gram.join(' '),n=(grams.get(key)||0)+1;
    grams.set(key,n);if(n>=4)return 'phrase-loop';
  }
  // Numbered repetitions, e.g. 1. They sell 2. They sell 3. They sell.
  const lines=text.split(/(?:^|\s)\d+[.)]\s/).slice(1).map(s=>s.trim().toLowerCase());
  if(lines.length>=3&&new Set(lines).size<=Math.ceil(lines.length/2))return 'list-loop';
  return '';
}

export function applyPromptCandidate(scene,project,visual) {
  if(!String(visual||'').trim()||repetitionReason(visual))return false;
  const next=buildPrompt(scene,project,visual);
  scene.previousPrompt=scene.prompt;scene.prompt=next;scene.promptSource='ai';
  return true;
}

export function repairCorruptPrompts(project) {
  let count=0;
  for(const scene of project.scenes){
    if(!repetitionReason(scene.prompt))continue;
    scene.rejectedPrompt=scene.prompt;
    scene.prompt=scene.previousPrompt&&!repetitionReason(scene.previousPrompt)
      ? scene.previousPrompt:buildPrompt(scene,project);
    scene.promptSource='recovered';count++;
  }
  return count;
}
