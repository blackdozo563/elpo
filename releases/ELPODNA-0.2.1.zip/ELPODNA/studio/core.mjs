export const MAX_DURATION = 15 * 60;
// Kullanilmayan sabit: surum artik manifest'ten okunur (studio/app.mjs showVersion).
export const VERSION = '1.5.0';
// Error texts: the studio installs its translator; tests and workers keep the Turkish default.
let translate = null;
export function useMessages(fn) { translate = fn; }
export function message(key, fallback) { return translate ? translate(key) : fallback; }
export const STYLES = {
  cinematic: 'Cinematic photography, atmospheric natural lighting, subtle film grain, rich shadows, realistic detail',
  illustration: 'Editorial illustration, textured paper, expressive shapes, restrained color palette, beautifully composed',
  anime: 'Hand-painted anime film background, expressive character design, soft cinematic lighting, detailed environment',
  bold2d: '2D illustration with bold thick black outlines, clean confident linework, flat colors, cel shading, expressive characters, graphic composition',
  watercolor: 'Watercolor painting on textured paper, delicate pigment, soft edges, layered washes, poetic composition',
  threeD: 'Stylized 3D animation still, tactile materials, soft global illumination, appealing character shapes'
};
// 'custom' is the user's own style line ("Diğer"); it replaces the preset line in every prompt.
export function styleText(settings) {
  return settings.style === 'custom' ? String(settings.customStyle || '').trim() : (STYLES[settings.style] || STYLES.cinematic);
}
export function uid() { return crypto.randomUUID(); }
export function fmt(seconds, fractions = false) {
  const ms = Math.max(0, Math.round(Number(seconds || 0) * 1000));
  return `${String(Math.floor(ms / 60000)).padStart(2, '0')}:${String(Math.floor(ms / 1000) % 60).padStart(2, '0')}${fractions ? '.' + String(ms % 1000).padStart(3, '0') : ''}`;
}
export function parseTime(s) {
  const parts = String(s).trim().replace(',', '.').split(':').map(Number);
  if (!parts.length || parts.length > 3 || parts.some(x => !Number.isFinite(x) || x < 0)) return NaN;
  return parts.reduce((n, x) => n * 60 + x, 0);
}
export function newProject() {
  return { id: uid(), schema: 1, title: 'İsimsiz hikâye', createdAt: Date.now(), updatedAt: Date.now(),
    duration: 0, audioKey: null, audioName: '', step: 0, scenes: [], transcript: '',
    settings: {style: 'cinematic', aspect: '16:9', sceneSeconds: 8, language: 'auto', whisper: 'tiny',
      resolution: '1080', motion: 'still', imageModel: 'Nano Banana 2', interval: 1, extra: '', customStyle: ''},
    references: [], run: null };
}
export function parseSubtitles(text) {
  const lines = String(text).replace(/^\uFEFF/, '').replace(/\r/g, '').split('\n');
  const chunks = [];
  for (let i = 0; i < lines.length; i++) {
    const match = lines[i].match(/((?:\d{1,3}:)?\d{2}:\d{2}[.,]\d{3})\s*-->\s*((?:\d{1,3}:)?\d{2}:\d{2}[.,]\d{3})/);
    if (!match) continue;
    const start = parseTime(match[1]), end = parseTime(match[2]);
    const body = [];
    while (++i < lines.length && lines[i].trim()) body.push(lines[i]);
    const caption = body.join(' ').replace(/<[^>]*>/g, '').trim();
    if (end > start && caption) chunks.push({timestamp: [start, end], text: caption});
  }
  if (!chunks.length) throw new Error(message('cNoSubs', 'Zaman kodlu altyazı bulunamadı. SRT veya WebVTT dosyası seçin.'));
  return chunks.sort((a,b) => a.timestamp[0] - b.timestamp[0]);
}
export function scenesFromChunks(chunks, duration, target = 8) {
  if (!(duration > 0 && duration <= MAX_DURATION)) throw new Error(message('cDuration', 'Ses süresi 0–15 dakika arasında olmalı.'));
  const items = chunks.filter(c => String(c.text || '').trim() && Number.isFinite(c.timestamp?.[0]) && c.timestamp[0] < duration)
    .sort((a,b) => a.timestamp[0] - b.timestamp[0]);
  if (!items.length) throw new Error(message('cNoSpeech', 'Konuşma bulunamadı. Başka bir model deneyin veya zaman kodlu altyazı ekleyin.'));
  if (target==='sentence-1'||target==='sentence-2') return sentenceScenes(items,duration,target==='sentence-2'?2:1);
  target=Number(target)||8;
  const lengths=items.map(c=>c.timestamp[1]-c.timestamp[0]).filter(Number.isFinite).sort((a,b)=>a-b);
  const wordTiming=items.length>15 && lengths[Math.floor(lengths.length/2)]<1.3;
  const groups = [];
  let group = null;
  for (const item of items) {
    const start = Math.max(0, item.timestamp[0]);
    const end = Math.min(duration, Number.isFinite(item.timestamp[1]) ? item.timestamp[1] : start + 1);
    const elapsed=group?start-group.start:0;
    const cut=group && (wordTiming
      ? (elapsed>=target*.65 && /[.!?…]["'’”)]*$/.test(group.text.trim())) || elapsed>=target*1.4
      : elapsed>=target);
    if (!group || cut) {
      group = {start, end, text: String(item.text).trim()}; groups.push(group);
    } else { group.end = Math.max(group.end, end); group.text += ' ' + String(item.text).trim(); }
  }
  // Absolute speech boundaries determine cuts; silence belongs to the preceding scene.
  // The first and last images cover leading and trailing silence, without trimming audio.
  return groups.map((g,i) => ({id: uid(), start: i === 0 ? 0 : g.start,
    end: i < groups.length - 1 ? groups[i+1].start : duration, text: g.text,
    prompt: '', status: 'draft', imageKey: null, refIds: [], generation: 0})).filter(s => s.end > s.start);
}
// Which reference belongs to which scene. A named reference (@Yusuf) follows the name through
// the narration; Turkish suffixes attach to names, so a word that starts with the tag counts.
// A reference whose name never appears in the story describes the world, not a character, and
// stays on every scene. The scene checkboxes always win afterwards.
// Word timestamps stay exact. Multi-sentence subtitle cues have no word boundaries;
// split those proportionally within the cue and expose the approximation in the UI.
export function sentenceScenes(items,duration,perScene=1) {
  const units=[];
  for(const item of items){
    const text=String(item.text).trim(),parts=text.match(/.+?(?:[.!?…]+["'’”)]*(?=\s|$)|$)/gu)||[text];
    let offset=0;const start=Math.max(0,item.timestamp[0]),end=Math.min(duration,Number.isFinite(item.timestamp[1])?item.timestamp[1]:start+1);
    for(const part of parts){const at=text.indexOf(part,offset);units.push({text:part.trim(),start:start+(end-start)*at/text.length,end:start+(end-start)*(at+part.length)/text.length,approximate:parts.length>1});offset=at+part.length;}
  }
  const groups=[];let group=null,count=0;
  for(const unit of units){
    if(!group){group={start:unit.start,text:'',approximate:false};groups.push(group);}
    group.text+=(group.text?' ':'')+unit.text;group.approximate ||= unit.approximate;
    if(/[.!?…]["'’”)]*$/.test(unit.text)&&++count>=perScene){group=null;count=0;}
  }
  return groups.map((g,i)=>({id:uid(),start:i===0?0:g.start,end:groups[i+1]?.start??duration,text:g.text,prompt:'',status:'draft',imageKey:null,refIds:[],generation:0,approximateTiming:g.approximate})).filter(s=>s.end>s.start);
}
export function assignReferences(scenes, references) {
  const words = text => String(text || '').toLocaleLowerCase('tr').match(/[\p{L}\p{N}]+/gu) || [];
  const spoken = scenes.map(s => words(s.text));
  // The tag and the capitalised names in the Gemini note ("Arnold bu karakter") both count as names.
  const noteNames = r => (String(r.note || '').match(/\p{Lu}[\p{L}\p{N}]{2,}/gu) || []);
  const tagWords = r => [...String(r.tag || '').replace(/^@+/, '').split(/[\s_]+/), ...noteNames(r)]
    .map(w => w.toLocaleLowerCase('tr').replace(/[^\p{L}\p{N}]/gu, '')).filter(w => w.length >= 3);
  return scenes.map((scene, i) => references.filter(ref => {
    const tags = tagWords(ref);
    if (!tags.length) return true;
    const mentions = list => tags.some(t => list.some(w => w.startsWith(t)));
    return spoken.some(mentions) ? mentions(spoken[i]) : true;
  }).map(ref => ref.id));
}
// ── Proofreading (1.4.3) ─────────────────────────────────────────────────────────────
// Lines sent to Gemini. Whisper word timestamps are grouped into short lines; subtitle cues stay
// one line each. Every line remembers the chunks it covers, so a correction goes back onto the
// exact word timestamps and the audio timing never changes.
const hasWordTiming = items => {
  const lengths = items.map(c => c.timestamp[1] - c.timestamp[0]).filter(Number.isFinite).sort((a,b) => a-b);
  return items.length > 15 && lengths[Math.floor(lengths.length/2)] < 1.3;
};
export function transcriptLines(chunks) {
  const items = (chunks || []).filter(c => String(c.text || '').trim() && Number.isFinite(c.timestamp?.[0]))
    .sort((a,b) => a.timestamp[0] - b.timestamp[0]);
  const lines = [];
  if (!hasWordTiming(items)) {
    items.forEach((c, k) => lines.push({i: lines.length, text: String(c.text).trim(), from: k, to: k}));
    return {items, lines};
  }
  let line = null;
  items.forEach((c, k) => {
    const prev = items[k-1], gap = prev ? c.timestamp[0] - prev.timestamp[1] : 0;
    if (!line || k - line.from >= 12 || /[.!?…]["'’”)]*$/.test(String(prev.text).trim()) || gap >= .8) {
      line = {i: lines.length, text: '', from: k, to: k}; lines.push(line);
    }
    line.text += (line.text ? ' ' : '') + String(c.text).trim(); line.to = k;
  });
  return {items, lines};
}
const plainWords = s => String(s || '').toLocaleLowerCase('tr').normalize('NFC').match(/[\p{L}\p{N}]+/gu) || [];
function editDistance(a, b) {
  let prev = Array.from({length: b.length + 1}, (_, j) => j);
  for (let i = 1; i <= a.length; i++) {
    const row = [i];
    for (let j = 1; j <= b.length; j++) row[j] = Math.min(prev[j] + 1, row[j-1] + 1, prev[j-1] + (a[i-1] === b[j-1] ? 0 : 1));
    prev = row;
  }
  return prev[b.length];
}
// Same rule as the server (narration-transcript.ts): the same words in the same order with at most
// a third respelled, or one word split/joined differently with the letters nearly unchanged.
export function lineAccept(original, fixed) {
  const a = plainWords(original), b = plainWords(fixed);
  if (!b.length) return false;
  if (a.length === b.length) return a.filter((w, i) => w !== b[i]).length <= Math.max(1, Math.ceil(a.length / 3));
  if (Math.abs(a.length - b.length) !== 1) return false;
  const x = a.join(''), y = b.join('');
  return 1 - editDistance(x, y) / Math.max(x.length, y.length, 1) >= .85;
}
export function applyLineFixes(items, lines, fixedByLine) {
  const out = []; let changed = 0;
  for (const line of lines) {
    const span = items.slice(line.from, line.to + 1), fixed = String(fixedByLine?.[line.i] ?? '').trim();
    if (!fixed || fixed === line.text || !lineAccept(line.text, fixed)) { out.push(...span); continue; }
    changed++;
    // Punctuation standing alone belongs to the word before it.
    const tokens = fixed.split(/\s+/).reduce((list, tok) => {
      if (list.length && !/[\p{L}\p{N}]/u.test(tok)) list[list.length-1] += tok; else list.push(tok);
      return list;
    }, []);
    if (span.length === 1) out.push({...span[0], text: fixed});
    else if (tokens.length === span.length) span.forEach((c, k) => out.push({...c, text: tokens[k]}));
    else out.push({timestamp: [span[0].timestamp[0], span.at(-1).timestamp[1]], text: fixed});
  }
  return {chunks: out, changed};
}
export function validateTimeline(scenes, duration) {
  if (!scenes.length) throw new Error(message('cNoScenes', 'Önce sahneleri oluşturun.'));
  let end = 0;
  for (const scene of scenes) {
    if (![scene.start,scene.end].every(Number.isFinite) || scene.end <= scene.start || Math.abs(scene.start-end) > .002) {
      throw new Error(message('cGap', 'Sahne zamanlarında boşluk veya çakışma var. Sahne sınırlarını kontrol edin.'));
    }
    end = scene.end;
  }
  if (Math.abs(end-duration) > .002) throw new Error(message('cCover', 'Sahneler sesin tamamını kapsamalı.'));
  return true;
}
export function changeBoundary(scenes, index, value) {
  if (index < 0 || index >= scenes.length - 1) throw new Error(message('cLastFixed', 'Son sahne sesin bitişine sabittir.'));
  if (!(value > scenes[index].start + .2 && value < scenes[index+1].end - .2)) throw new Error(message('cBoundary', 'Sahne sınırı komşu sahnelerin içinde olmalı.'));
  scenes[index].end = value; scenes[index+1].start = value;
}
export function sceneAt(scenes, time) { return scenes.find(s => s.start <= time && time < s.end) || scenes.at(-1); }
export function buildPrompt(scene, project, visual = '') {
  const refs = project.references.filter(r => scene.refIds.includes(r.id));
  return [visual || scene.text, styleText(project.settings),
    project.settings.extra, refs.map(r => `${r.tag}: ${r.description ? r.description.trim()+'. ' : ''}Use the attached reference to preserve appearance.`).join(' '),
    `${project.settings.aspect} composition. A single coherent image. No captions, no typography, no text overlay.`]
    .filter(Boolean).join('\n');
}
export function makeRun(project, scenes) {
  validateTimeline(project.scenes, project.duration);
  if (!scenes.length) throw new Error(message('cNothing', 'Üretilecek sahne yok.'));
  if (scenes.some(s => !s.prompt.trim())) throw new Error(message('cNeedPrompt', 'Her sahne için görsel istemi hazırlayın.'));
  return {id: uid(), projectId: project.id, sceneIds: scenes.map(s => s.id),
    versions: scenes.map(s => s.generation), sceneNumbers: scenes.map(s => project.scenes.indexOf(s)+1), createdAt: Date.now()};
}
export function acceptResult(project, runId, sceneId, generation, imageKey) {
  const s = project.scenes.find(s => s.id === sceneId);
  if (!s || project.run?.id !== runId || s.generation !== generation) return false;
  s.imageKey = imageKey; s.status = 'ready'; return true;
}
export function srt(scenes) {
  const time = n => { const ms = Math.round(n*1000); return `${String(Math.floor(ms/3600000)).padStart(2,'0')}:${fmt(n, true).replace('.',',')}`; };
  return scenes.map((s,i) => `${i+1}\n${time(s.start)} --> ${time(s.end)}\n${s.text}\n`).join('\n');
}
export function dimensions(aspect, resolution) {
  const h = resolution === '720' ? 720 : 1080;
  return aspect === '9:16' ? {width:h,height:Math.round(h*16/9)} : aspect === '1:1' ? {width:h,height:h} : {width:Math.round(h*16/9),height:h};
}
