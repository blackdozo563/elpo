import {storyPayload,applyStoryPrompts} from './cloud-prompts.mjs';
import {newProject,uid,fmt,parseTime,parseSubtitles,scenesFromChunks,validateTimeline,changeBoundary,sceneAt,buildPrompt,makeRun,acceptResult,srt,dimensions,MAX_DURATION,STYLES,assignReferences,useMessages,transcriptLines,applyLineFixes} from './core.mjs';
import {t,applyStatic,loadLang,watchLang,localizeMessage,locale,variants} from './i18n.mjs';
const renderGate=()=>{};
const relabelTokenStore=()=>{};
import {get,put,all,readLibrary} from './storage.mjs';
import {applyPromptCandidate,repairCorruptPrompts,migratePromptMetadata,syncReferencePrompt} from './prompt-policy.mjs';
const $=id=>document.getElementById(id), embedded=new URLSearchParams(location.search).has('embedded');
document.body.classList.toggle('is-embedded',embedded);if(!embedded)$('expand').hidden=true;
const extension=typeof chrome!=='undefined'&&!!chrome.runtime?.id;
let project,audioBuffer,audioUrl,filter='all',busy=false,aiWorker,exportWorker,taskReject,saveTimer,saving=Promise.resolve(),toastTimer,previewRaf,lockRelease,readonly=false;
let pipelineActive=false,cancelRequested=false;
let currentAIType=null,pollInFlight=false,decodedAudioKey=null;
const settledRuns=new Set();
const urls=new Map(),safe=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const on=(id,event,fn)=>$(id).addEventListener(event,e=>Promise.resolve().then(()=>fn(e)).catch(report));
function toast(message,error=false){clearTimeout(toastTimer);$('toast').textContent=message;$('toast').classList.toggle('error',error);$('toast').hidden=false;toastTimer=setTimeout(()=>$('toast').hidden=true,error?10000:4500);}
function report(e){console.error(e);toast(e.message||String(e),true);}
let saveStatusKey='localProject',audioSize=0;
function setSaveStatus(key){saveStatusKey=key;$('save-status').textContent=t(key);}
function renderAudioMeta(){$('audio-meta').textContent=t('audioMeta',{duration:fmt(project.duration),size:(audioSize/1048576).toFixed(1)});}
function assertStyle(){if(project.settings.style==='custom'&&!String(project.settings.customStyle||'').trim()){go(1);$('custom-style').focus();throw new Error(t('errCustomStyle'));}}
function assertEditable(){if(readonly)throw new Error(t('errOtherTab'));if(busy)throw new Error(t('errBusy'));}
async function ask(title,text,yes=t('continue'),{model=false}={}){$('confirm-model').hidden=!model;if(model)$('confirm-model-select').value=project.settings.imageModel;$('confirm-title').textContent=title;$('confirm-text').textContent=text;$('confirm-yes').textContent=yes;$('confirm-dialog').showModal();return new Promise(resolve=>{const finish=v=>{$('confirm-dialog').close();$('confirm-yes').onclick=null;$('confirm-no').onclick=null;$('confirm-dialog').oncancel=null;resolve(v);};$('confirm-yes').onclick=()=>finish(true);$('confirm-no').onclick=()=>finish(false);$('confirm-dialog').oncancel=e=>{e.preventDefault();finish(false);};});}
function requestSave(){if(readonly)return;clearTimeout(saveTimer);setSaveStatus('saving');saveTimer=setTimeout(()=>save().catch(report),300);}
async function save(){clearTimeout(saveTimer);if(readonly||!project)return;project.updatedAt=Date.now();const p=structuredClone(project);for(const scene of p.scenes)delete scene.promptPending;saving=saving.catch(()=>{}).then(()=>put('projects',p.id,p));await saving;localStorage.setItem('elpodna-story-current',p.id);setSaveStatus('saved');}
function task(title,detail,percent){$('reset-project').disabled=true;$('undo-reset').disabled=true;document.querySelector('main').inert=true;$('projects-btn').disabled=true;$('task-progress').hidden=false;$('task-title').textContent=title;$('task-detail').textContent=detail||'';if(Number.isFinite(percent))$('task-bar').value=percent;else $('task-bar').removeAttribute('value');}
function endTask(){busy=false;taskReject=null;document.querySelector('main').inert=pipelineActive;$('projects-btn').disabled=pipelineActive||readonly;$('task-progress').hidden=true;renderActions();}
function renderActions(){$('reset-project').disabled=busy||readonly||pipelineActive;$('undo-reset').disabled=busy||readonly||pipelineActive;$('undo-reset').hidden=!project?.resetUndoId;$('transcribe').disabled=!project?.audioKey||busy||readonly;$('create-scenes').disabled=!project?.chunks?.length||busy||readonly;$('improve-prompts').disabled=!project?.scenes.length||busy||readonly;}
// Story engine screen while the scenes and prompts are prepared (the look of the site's Script Analiz
// screen). Proofreading, scene splitting and the final check are real milestones. The Gemini request is
// one call, so inside it the stages walk on measured time (continuity pass first, then ~10 s per two
// batches of 20 scenes) and the prompt stage waits for the reply: nothing reads 100% before it lands.
let ai=null,aiDoneDelay=1100;
const AI_WEIGHT={proofread:14,split:4,analyze:78,check:4};
function aiLabel(key){return {proofread:'aiStageProofread',split:'aiStageSplit',analyze:'aiStageAnalyze',cast:project.references.length?'aiStageCast':'aiStageWorld',prompts:'aiStagePrompts',check:'aiStageCheck'}[key];}
function aiLines(text){const out=[];for(const sentence of String(text||'').replace(/\s+/g,' ').split(/(?<=[.!?…])\s+/)){const words=sentence.trim().split(' ').filter(Boolean);for(let i=0;i<words.length;i+=12)out.push(words.slice(i,i+12).join(' '));if(out.length>=48)break;}return out.slice(0,48);}
function aiGeminiSeconds(n){return 8+Math.ceil(Math.ceil(Math.max(1,n)/20)/2)*10;}
// Whole wait: proofreading (~15 s when it runs) plus the Gemini call.
function aiEstimate(n){const sec=aiGeminiSeconds(n)+(ai?.stages.includes('proofread')?15:0);return sec<90?t('aiSeconds',{n:Math.ceil(sec/10)*10}):t('aiMinutes',{n:Math.ceil(sec/60)});}
function aiOpen(stages,scenes=0){
  if(ai)return false;
  ai={stages,stage:stages[0],stageAt:Date.now(),started:Date.now(),geminiAt:0,n:scenes,words:(String(project.transcript||'').match(/[\p{L}\p{N}]+/gu)||[]).length,done:false,lit:0};
  const list=$('ai-stages');list.replaceChildren();
  stages.forEach((key,i)=>{const li=document.createElement('li');li.innerHTML=`<span data-n="${i+1}"></span><em>${safe(t(aiLabel(key)))}</em>`;list.append(li);});
  const roll=$('ai-reader-roll'),lines=aiLines(project.transcript);roll.replaceChildren();
  for(let copy=0;copy<2;copy++)for(const line of lines){const p=document.createElement('p');p.textContent=line;roll.append(p);}
  roll.style.animationDuration=`${Math.max(18,lines.length*1.1)}s`;
  aiCells();$('ai-overlay').classList.toggle('is-done',false);$('ai-overlay').hidden=false;document.body.classList.add('ai-busy');document.querySelector('.studio-shell').inert=true;
  ai.timer=setInterval(aiTick,200);aiTick();return true;
}
function aiStage(stage){if(!ai)return;ai.stage=stage;ai.stageAt=Date.now();if(stage==='analyze')ai.geminiAt=Date.now();aiTick();}
function aiScenes(n){if(!ai)return;ai.n=n;aiCells();aiTick();}
function aiCells(){const box=$('ai-cells');box.replaceChildren();ai.lit=0;if(!ai.n){const em=document.createElement('em');em.textContent=t('aiSceneWait');box.append(em);return;}const count=Math.min(ai.n,160);for(let i=0;i<count;i++){const cell=document.createElement('span');cell.style.setProperty('--mix',`${Math.round(100-i/Math.max(1,count-1)*100)}%`);box.append(cell);}}
function aiTick(){
  if(!ai)return;
  const now=Date.now(),E=aiGeminiSeconds(ai.n),g=ai.geminiAt?(now-ai.geminiAt)/1000:0,a1=Math.max(3,.18*E),a2=a1+Math.max(2.5,.12*E);
  const stage=ai.stage==='analyze'?(g<a1?'analyze':g<a2?'cast':'prompts'):ai.stage,at=ai.done?ai.stages.length:ai.stages.indexOf(stage);
  [...$('ai-stages').children].forEach((li,i)=>{li.className=i<at?'done':i===at?'active':'';});
  // Progress: weighted groups (the Gemini call covers analyze, cast and prompts), asymptotic inside each.
  const groups=ai.stages.filter(k=>AI_WEIGHT[k]),total=groups.reduce((n,k)=>n+AI_WEIGHT[k],0),group=stage==='cast'||stage==='prompts'?'analyze':stage;
  let before=0;for(const k of groups){if(k===group)break;before+=AI_WEIGHT[k];}
  const within=group==='proofread'?.9*(1-Math.exp(-(now-ai.stageAt)/4000)):group==='analyze'?.96*(1-Math.exp(-g/(E/2.2))):.5;
  const pct=ai.done?100:Math.min(99,Math.round((before+(AI_WEIGHT[group]||0)*within)/total*100));
  $('ai-fill').style.width=pct+'%';$('ai-pct').textContent=t('aiPct',{n:pct});
  $('ai-now').textContent=ai.done?t('aiDoneNow'):t('aiNow',{stage:t(aiLabel(stage))});
  $('ai-title').textContent=ai.done?t('aiDoneTitle',{n:ai.n}):t(ai.stages.includes('split')?'aiTitleCreate':'aiTitleRewrite');
  const num=v=>Number(v).toLocaleString(locale());
  $('ai-facts').textContent=ai.n?t('aiFacts',{words:num(ai.words),duration:fmt(project.duration),n:num(ai.n)}):t('aiFactsNoScenes',{words:num(ai.words),duration:fmt(project.duration)});
  // The narration is read during the first stage; prompts light the scene map while Gemini writes them.
  const first=ai.stages[0]==='analyze'?Math.min(1,g/a1):ai.stage===ai.stages[0]?Math.min(1,(now-ai.stageAt)/5000):1;
  $('ai-words').textContent=t('aiWordsRead',{read:num(Math.round(ai.words*(ai.done?1:first))),words:num(ai.words)});
  const written=ai.done||ai.stage==='check'?ai.n:stage==='prompts'?Math.floor(ai.n*.95*(1-Math.exp(-(g-a2)/Math.max(4,(E-a2)/1.8)))):0;
  $('ai-scene-count').textContent=ai.n?t('aiSceneCount',{done:num(written),n:num(ai.n)}):'';
  const cells=[...$('ai-cells').children].filter(c=>c.tagName==='SPAN'),lit=cells.length?Math.round(written*cells.length/Math.max(1,ai.n)):0;
  cells.forEach((c,i)=>{c.classList.toggle('on',i<lit);c.classList.toggle('new',i>=ai.lit&&i<lit);});ai.lit=lit;
  const time=fmt((now-ai.started)/1000);$('ai-time').textContent=ai.n?t('aiEstimate',{time,est:aiEstimate(ai.n)}):t('aiElapsed',{time});
}
// Success plays a short completed state, then the scenes are shown.
async function aiDone(){if(!ai)return;ai.done=true;$('ai-overlay').classList.toggle('is-done',true);aiTick();clearInterval(ai.timer);await new Promise(r=>setTimeout(r,aiDoneDelay));aiClose();}
function aiClose(){if(!ai)return;clearInterval(ai.timer);ai=null;$('ai-overlay').hidden=true;document.body.classList.remove('ai-busy');document.querySelector('.studio-shell').inert=false;}
// The server names why Gemini failed with a short code (narration-prompts.ts); older servers send none.
const GEN_REASONS={provider_429:'gwBusy',provider_network:'gwDown',timeout:'gwTimeout',blocked:'gwBlocked',truncated:'gwOutput',incomplete_generation:'gwOutput',invalid_json:'gwOutput',incomplete_response:'gwOutput',invalid_response:'gwOutput',repetitive_response:'gwOutput'};
function genFailure(result){
  const base=t(/iadesi tamamlanamad/.test(result.message||'')?'errGenRefundFailed':'errGenFailed'),code=String(result.reason||'');
  if(!/^[a-z_0-9]{3,40}$/.test(code))return base;
  return `${base} ${t(GEN_REASONS[code]||(/^provider_5/.test(code)?'gwDown':'gwOther'))} (${t('gwCode',{code})})`;
}
// Sahneler Stil adimindaki "Sahneleri ve istemleri hazirla" ile olusur. Eskiden transkript ya da SRT hazirken de
// "Once sesi cozumle" deniyordu; kullanicilar transkripsiyonun ve SRT'nin basarisiz oldugunu saniyordu.
function sceneHint(){if(!project.chunks?.length){toast(t('needTranscript'));return;}if(project.step!==1)go(1);toast(t('needScenes'));const b=$('create-scenes');b.scrollIntoView({behavior:'smooth',block:'center'});b.focus({preventScroll:true});}
function go(step){if(step>0&&!project.audioKey){toast(t('needAudio'));return;}if(step>1&&!project.scenes.length){sceneHint();return;}const moved=project.step!==step;project.step=step;document.querySelectorAll('[data-view]').forEach(el=>el.hidden=Number(el.dataset.view)!==step);document.querySelectorAll('[data-step]').forEach(el=>{el.classList.toggle('active',Number(el.dataset.step)===step);el.classList.toggle('done',Number(el.dataset.step)<step);el.setAttribute('aria-current',Number(el.dataset.step)===step?'step':'false');});$('flow-scenes').append($('flow-card'));if(step===2)refreshFlow().catch(report);if(step===2)renderScenes();if(step===3)renderVideo();if(moved)scrollTo({top:0,left:0,behavior:'instant'});requestSave();}
async function blobURL(key){if(!key)return null;if(urls.has(key))return urls.get(key);const blob=await get('assets',key);if(!(blob instanceof Blob))return null;const url=URL.createObjectURL(blob);urls.set(key,url);return url;}
function revokeURLs(){for(const url of urls.values())URL.revokeObjectURL(url);urls.clear();if(audioUrl){URL.revokeObjectURL(audioUrl);audioUrl=null;}$('audio-player').pause();}
async function decodeAudio(blob){const ctx=new AudioContext();try{return await ctx.decodeAudioData(await blob.arrayBuffer());}finally{await ctx.close();}}
async function loadAudio(){$('audio-drop').hidden=!!project.audioKey;$('audio-card').hidden=!project.audioKey;if(!project.audioKey){$('audio-player').removeAttribute('src');audioBuffer=null;decodedAudioKey=null;return;}const blob=await get('assets',project.audioKey);if(!blob)throw new Error(t('errAudioMissing'));if(audioUrl)URL.revokeObjectURL(audioUrl);audioUrl=URL.createObjectURL(blob);$('audio-player').src=audioUrl;$('audio-name').textContent=project.audioName;audioSize=blob.size;renderAudioMeta();if(!audioBuffer||decodedAudioKey!==project.audioKey){audioBuffer=await decodeAudio(blob);decodedAudioKey=project.audioKey;}drawWave();}
function drawWave(){if(!audioBuffer)return;const c=$('waveform'),ctx=c.getContext('2d');c.width=Math.max(300,c.clientWidth*2);c.height=120;ctx.clearRect(0,0,c.width,c.height);const data=audioBuffer.getChannelData(0),bars=Math.floor(c.width/7);for(let i=0;i<bars;i++){let peak=0;const from=Math.floor(i*data.length/bars),to=Math.floor((i+1)*data.length/bars);for(let j=from;j<to;j+=Math.max(1,Math.floor((to-from)/200)))peak=Math.max(peak,Math.abs(data[j]));const h=Math.max(4,peak*110);ctx.fillStyle=i/bars<$('audio-player').currentTime/project.duration?'#d1edaa':'#ac96e5';ctx.fillRect(i*7,(120-h)/2,3,h);}}
async function addAudio(file){assertEditable();if(!file)return;if(file.size>250*1048576)throw new Error(t('errAudioSize'));if(project.audioKey&&!await ask(t('askReplaceTitle'),t('askReplaceText'),t('askReplaceYes')))return;busy=true;task(t('taskAudio'),t('taskAudioDetail'));try{const decoded=await decodeAudio(file);if(!(decoded.duration>0&&decoded.duration<=MAX_DURATION))throw new Error(t('errAudioLong'));if(project.audioKey){await save();project=newProject();revokeURLs();}const key=`audio:${project.id}`;await put('assets',key,file);project.audioKey=key;project.audioName=file.name;project.duration=decoded.duration;project.title=file.name.replace(/\.[^.]+$/,'');audioBuffer=decoded;decodedAudioKey=key;await save();await render();toast(t('toastAudioAdded'));}finally{endTask();}}
function runAI(type,payload){
  currentAIType=type;
  aiWorker?.terminate();const worker=aiWorker=new Worker('./vendor/ai-worker.js',{type:'module'});
  return new Promise((resolve,reject)=>{
    let timer,clock,budget,started=Date.now(),lastDetail=t('modelPreparing'),finished=false;
    const finish=(error,result)=>{if(finished)return;finished=true;clearTimeout(timer);clearTimeout(budget);clearInterval(clock);worker.terminate();if(aiWorker===worker)aiWorker=null;currentAIType=null;error?reject(error):resolve(result);};
    const arm=()=>{clearTimeout(timer);timer=setTimeout(()=>finish(new Error(t('errModelStalled'))),300000);};
    taskReject=error=>finish(error);arm();
    clock=setInterval(()=>{$('task-detail').textContent=`${lastDetail} · ${t('seconds',{n:Math.floor((Date.now()-started)/1000)})}`;},1000);
    worker.onerror=e=>finish(new Error(e.message||t('errModelStart')));
    worker.onmessage=e=>{const m=e.data;
      if(m.type==='progress'){arm();lastDetail=m.detailKey?t(m.detailKey,m.vars):'';task(t(m.titleKey),lastDetail,m.percent);}
      if(m.type==='checkpoint'){arm();lastDetail=t('checkpoint',{done:m.completed,total:m.total,sec:Math.round(m.seconds)});}
      if(m.type==='result')finish(null,m.result);if(m.type==='error')finish(new Error(t('wLocalModel',{detail:m.code?t(m.code):(m.detail||m.error)})));
    };worker.postMessage({type,...payload});
  });
}
async function transcribe({confirmed=false}={}){
  assertEditable();if(!audioBuffer)throw new Error(t('errAddAudio'));
  if(!confirmed&&!await ask(t('askAsrTitle'),t('askAsrText'),t('transcribeBtn')))return false;
  busy=true;renderActions();task(t('taskAsrPrep'),t('taskAsrPrepDetail'));
  let cancelled=false;taskReject=()=>{cancelled=true;};
  try{
    const offline=new OfflineAudioContext(1,Math.ceil(audioBuffer.duration*16000),16000),src=offline.createBufferSource();src.buffer=audioBuffer;src.connect(offline.destination);src.start();const mono=await offline.startRendering();
    if(cancelled)throw new Error(t('errAsrCancelled'));
    const result=await runAI('transcribe',{audio:mono.getChannelData(0),model:project.settings.whisper,language:project.settings.language});
    if(!result.chunks?.length)throw new Error(t('errNoSpeech'));
    project.chunks=result.chunks;project.transcript=result.text;project.transcriptSource='whisper-validated-v2';project.transcriptProofread=false;project.rawChunks=null;await save();renderTranscript();showTranscript();toast(t('toastAsrDone'));return true;
  }finally{aiWorker?.terminate();aiWorker=null;endTask();}
}
function renderTranscript(){const has=!!project.chunks?.length;$('transcript-card').hidden=!has;$('transcript-preview').textContent=project.transcript||'';$('transcript-count').textContent=t(project.transcriptSource==='whisper-validated-v2'?'transcriptWords':'transcriptParts',{n:project.chunks?.length||0});renderActions();}
// Kart dugmenin altinda, kucuk ekranda gorunmeyebiliyor; kullanici "hicbir sey cikmadi" diyordu.
function showTranscript(){$('transcript-card').scrollIntoView({behavior:'smooth',block:'center'});}
// file.text() her dosyayi UTF-8 sayar; bazi Windows araclari SRT'yi BOM'lu UTF-16 kaydeder.
async function subtitleText(file){const b=new Uint8Array(await file.arrayBuffer());return new TextDecoder(b[0]===0xFF&&b[1]===0xFE?'utf-16le':b[0]===0xFE&&b[1]===0xFF?'utf-16be':'utf-8').decode(b);}
async function addSubtitles(file){assertEditable();if(!project.audioKey)throw new Error(t('errSubsNeedAudio'));if(!file)return;const chunks=parseSubtitles(await subtitleText(file));if(chunks.some(c=>c.timestamp[1]>project.duration+.001))throw new Error(t('errSubsTooLong'));for(const c of chunks)if(c.timestamp[1]>project.duration)c.timestamp[1]=project.duration;project.chunks=chunks;project.transcriptSource='subtitles';project.transcriptProofread=false;project.rawChunks=null;project.transcript=chunks.map(c=>c.text).join(' ');await save();renderTranscript();showTranscript();toast(t('toastSubsAdded'));}
// One confirmation covers the whole Gemini preparation: proofreading (not charged), then the prompts (charged).
let proofreadNote='';
async function createScenes({confirmed=false}={}){
 assertEditable();assertStyle();if(project.scenes.length&&!confirmed&&!await ask(t('askRescenesTitle'),t('askRescenesText')))return;
 project.scenes=scenesFromChunks(project.chunks,project.duration,project.settings.sceneSeconds);
 const refs=assignReferences(project.scenes,project.references);project.scenes.forEach((s,i)=>{s.refIds=refs[i];s.prompt=buildPrompt(s,project);});
 project.run=null;project.promptError='';await save();go(2);await renderScenes();toast('Scènes préparées. Concevez ou réécrivez leurs descriptions avec Gemini.');
}
function geminiRequest(){return 'Conçois les descriptions visuelles cohérentes de toutes ces scènes. Ne génère pas les images : elles seront produites dans Google Flow. Retourne uniquement un objet JSON {"scenes":[{"id":"identifiant inchangé","visual":"description précise en 20 à 6000 caractères","refs":["id de référence connu"]}]}. Conserve tous les IDs, toutes les scènes, le sens de la narration et les références utiles.\n\n'+JSON.stringify(storyPayload(project));}
async function copyGemini(){assertEditable();if(!project.scenes.length)throw Error(t('errNeedScenesFirst'));try{await navigator.clipboard.writeText(geminiRequest());toast('Demande copiée. Confirmez vous-même son envoi sur Gemini.');}catch{download(new Blob([geminiRequest()],{type:'text/plain;charset=utf-8'}),'ELPODNA-Demande-Gemini.txt');toast('Demande enregistrée dans un fichier texte. Copiez-la dans Gemini et confirmez son envoi.');}}
async function improvePrompts(){assertEditable();assertStyle();if(!project.scenes.length)throw Error(t('errNeedScenesFirst'));go(2);await copyGemini();$('gemini-web').scrollIntoView({block:'center'});}
async function applyGeminiWeb(){assertEditable();const result=JSON.parse($('gemini-reply').value);const known=new Set(project.references.map(r=>r.id));if(!Array.isArray(result.scenes)||result.scenes.some(s=>!Array.isArray(s.refs)||s.refs.some(id=>!known.has(id))))throw Error('Références Gemini inconnues ou réponse incomplète.');const next=structuredClone(project);applyStoryPrompts(next,result);project=next;await save();await renderScenes();toast('Descriptions Gemini vérifiées et appliquées.');}
function showScenePrompt(scene){const card=document.querySelector(`[data-scene-id="${scene.id}"]`);if(!card)return;card.querySelector('.scene-prompt').value=scene.prompt;card.querySelector('.scene-state').textContent=scene.promptPending?t('promptWriting'):promptLabel(scene);}
async function addReferences(files){assertEditable();for(const file of files){if(project.references.length>=10){toast(t('errMaxRefs'),true);break;}if(!/^image\/(png|jpeg|webp)$/.test(file.type)||file.size>10*1048576){toast(t('errRefType'),true);continue;}const id=uid(),key=`ref:${id}`;await put('assets',key,file);project.references.push({id,key,name:file.name,tag:`${t('refTagPrefix')}${project.references.length+1}`,description:'',note:''});}await save();renderReferences();}
async function renderReferences(){const list=$('reference-list');list.replaceChildren();for(const ref of project.references){const div=document.createElement('div');div.className='reference-item';div.innerHTML=`<img alt="${safe(t('refAlt'))}"><div><input aria-label="${safe(t('refTagAria'))}" class="tag" value="${safe(ref.tag)}" maxlength="40"><textarea aria-label="${safe(t('refDescAria'))}" placeholder="${safe(t('refDescPh'))}" maxlength="1000">${safe(ref.description)}</textarea><textarea class="ref-note" aria-label="${safe(t('refNoteAria'))}" placeholder="${safe(t('refNotePh'))}" maxlength="1000">${safe(ref.note||'')}</textarea></div><button aria-label="${safe(t('refRemove'))}">×</button>`;list.append(div);div.querySelector('img').src=await blobURL(ref.key)||'';div.querySelector('.tag').onchange=e=>{ref.tag='@'+e.target.value.replace(/^@+/,'').replace(/\s+/g,'_');e.target.value=ref.tag;const hit=assignReferences(project.scenes,[ref]);project.scenes.forEach((s,i)=>{s.refIds=hit[i].length?[...new Set([...s.refIds,ref.id])]:s.refIds.filter(id=>id!==ref.id);});requestSave();renderScenes();};div.querySelector('textarea').oninput=e=>{ref.description=e.target.value;requestSave();};div.querySelector('.ref-note').oninput=e=>{ref.note=e.target.value;requestSave();};div.querySelector('button').onclick=()=>{project.references=project.references.filter(r=>r.id!==ref.id);project.scenes.forEach(s=>s.refIds=s.refIds.filter(id=>id!==ref.id));requestSave();renderReferences();};}}
async function openLibrary(){const library=await readLibrary();$('library-list').replaceChildren();if(!library.length)$('library-list').innerHTML='<div class="empty">'+safe(t('libEmpty'))+'</div>';for(const ref of library){if(!/^data:image\/(png|jpeg|webp);base64,/.test(ref.dataUrl||''))continue;const div=document.createElement('div');div.className='library-entry';div.innerHTML=`<img alt=""><div><strong>${safe(ref.tag||ref.name)}</strong></div><button class="secondary">${safe(t('add'))}</button>`;div.querySelector('img').src=ref.dataUrl;div.querySelector('button').onclick=async()=>{if(project.references.length>=10){toast(t('errMaxRefs'),true);return;}const blob=await(await fetch(ref.dataUrl)).blob(),id=uid(),key=`ref:${id}`;await put('assets',key,blob);project.references.push({id,key,name:ref.name,tag:ref.tag||t('refDefaultTag'),description:'',note:''});await save();renderReferences();toast(t('toastRefAdded'));};$('library-list').append(div);}$('library-dialog').showModal();}
const promptLabel=scene=>scene.status!=='draft'?stateLabel(scene.status):t(scene.promptSource==='gemini'?'promptGeminiReady':scene.promptSource==='manual'?'promptEdited':'st_draft');
const stateLabel=s=>t('st_'+(['draft','queued','ready','failed','unmatched'].includes(s)?s:'draft'));
async function renderScenes(){const list=$('scenes');list.replaceChildren();const ready=project.scenes.filter(s=>s.imageKey).length;$('prompt-status').textContent=t(project.scenes.every(s=>s.promptSource==='gemini')?'promptStatusGemini':project.scenes.some(s=>s.promptSource==='gemini')?'promptStatusMixed':'promptStatusNone');$('prompt-error').hidden=!project.promptError;$('prompt-error').textContent=project.promptError?t('promptFailure',{detail:project.promptError}):'';$('scene-summary').textContent=t('sceneSummary',{n:project.scenes.length,duration:fmt(project.duration),ready});const visible=project.scenes.filter(s=>filter==='all'||(filter==='ready'?s.imageKey:!s.imageKey));if(!visible.length)list.innerHTML='<div class="empty">'+safe(t('noScenesView'))+'</div>';for(const scene of visible){const i=project.scenes.indexOf(scene),card=document.createElement('article');card.className='scene-card';card.dataset.sceneId=scene.id;card.innerHTML=`<div class="scene-aside"><div class="scene-image${scene.status==='queued'?' queued':''}">◇<span class="scene-number">${String(i+1).padStart(2,'0')}</span>${scene.imageKey?'':`<small class="scene-auto">${safe(t(scene.status==='queued'?'sceneQueuedImage':scene.status==='unmatched'?'sceneUnmatchedImage':scene.status==='failed'?'sceneFailedImage':'sceneAutoImage'))}</small>`}</div><button class="secondary choose-image" title="${safe(t('chooseImageTitle'))}">${safe(t('chooseImage'))}</button><input type="file" accept="image/png,image/jpeg,image/webp" hidden></div><div class="scene-main"><div class="scene-head"><strong>${safe(t('sceneN',{n:String(i+1).padStart(2,'0')}))}</strong><span class="scene-state ${scene.imageKey?'ready':''}">${scene.promptPending?t('promptWriting'):promptLabel(scene)}</span></div><textarea class="scene-text" aria-label="${safe(t('sceneTextAria',{n:i+1}))}">${safe(scene.text)}</textarea><label>${safe(t('imagePrompt'))}<textarea class="scene-prompt" aria-label="${safe(t('scenePromptAria',{n:i+1}))}">${safe(scene.prompt)}</textarea></label><p class="scene-warning" ${scene.promptWarning?'':'hidden'}>${safe(scene.promptWarning)}</p><p class="scene-match" ${scene.status==='unmatched'&&!scene.imageKey&&scene.matchError?'':'hidden'}>${safe(localizeMessage(scene.matchError||''))}</p><div class="ref-choices"></div><div class="scene-times"><span>${fmt(scene.start,true)} →</span><input type="text" class="end-time" aria-label="${safe(t('sceneEndAria',{n:i+1}))}" value="${fmt(scene.end,true)}" ${i===project.scenes.length-1?'disabled':''}><button class="quiet-btn regenerate">${safe(t('regenerate'))}</button></div></div>`;list.append(card);if(scene.imageKey){const img=document.createElement('img');img.alt=t('sceneN',{n:i+1});img.src=await blobURL(scene.imageKey)||'';const button=card.querySelector('.scene-image');button.prepend(img);button.tabIndex=0;button.setAttribute('role','button');button.setAttribute('aria-label',t('sceneZoomAria',{n:i+1}));button.onclick=()=>openImage(scene.id).catch(report);button.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openImage(scene.id).catch(report);}};}card.querySelector('.scene-text').oninput=e=>{scene.text=e.target.value;requestSave();};card.querySelector('.scene-prompt').oninput=e=>{scene.prompt=e.target.value;scene.promptSource='manual';showScenePrompt(scene);requestSave();};card.querySelector('.end-time').onchange=e=>{try{changeBoundary(project.scenes,i,parseTime(e.target.value));requestSave();renderScenes();}catch(err){report(err);e.target.value=fmt(scene.end,true);}};card.querySelector('.choose-image').onclick=()=>card.querySelector('input[type=file]').click();card.querySelector('input[type=file]').onchange=async e=>{try{assertEditable();const file=e.target.files[0];if(file){await assignImage(scene,file);await save();renderScenes();}}catch(err){report(err);}};card.querySelector('.regenerate').onclick=()=>generate([scene]).catch(report);for(const ref of project.references){const label=document.createElement('label'),input=document.createElement('input');input.type='checkbox';input.checked=scene.refIds.includes(ref.id);input.onchange=()=>{scene.refIds=input.checked?[...new Set([...scene.refIds,ref.id])]:scene.refIds.filter(id=>id!==ref.id);scene.refsManual=true;syncReferencePrompt(scene,project);showScenePrompt(scene);requestSave();};label.append(input,document.createTextNode(ref.tag));card.querySelector('.ref-choices').append(label);}}renderActions();}
async function assignImage(scene,file){if(!/^image\/(png|jpeg|webp)$/.test(file.type)||file.size>25*1048576)throw new Error(t('errImageType'));const bitmap=await createImageBitmap(file);bitmap.close();const key=`scene:${scene.id}:${uid()}`;await put('assets',key,file);scene.imageKey=key;scene.status='ready';scene.generation++;}
async function importImages(files){assertEditable();let matched=0,unmatched=[];const seen=new Set();for(const file of files){const m=file.name.match(/^(\d{1,5})(?:[_.\s-]|$)/),n=m?Number(m[1])-1:-1;if(n<0||n>=project.scenes.length||seen.has(n)){unmatched.push(file.name);continue;}await assignImage(project.scenes[n],file);seen.add(n);matched++;}await save();renderScenes();toast(t('toastImported',{n:matched})+(unmatched.length?t('toastUnmatched',{n:unmatched.length}):''),!!unmatched.length);}
async function send(message){if(!extension)throw new Error(t('errNotExtension'));return chrome.runtime.sendMessage(message);}
async function refreshFlow(){if(!extension){$('flow-status').textContent=t('designPreview');return;}const selected=$('flow-tab').value,tabs=await chrome.tabs.query({url:['https://labs.google/*','https://*.labs.google/*','https://flow.google.com/*']}),projects=tabs.filter(t=>/\/project\//.test(t.url||''));$('flow-tab').replaceChildren();if(!projects.length){$('flow-tab').add(new Option(t('openFlowProjectFirst'),''));$('flow-status').textContent=t('waitingProject');}else{for(const tab of projects)$('flow-tab').add(new Option((tab.title||t('flowProject')).slice(0,80),String(tab.id)));if(projects.some(t=>String(t.id)===selected))$('flow-tab').value=selected;else if(projects.some(t=>t.active))$('flow-tab').value=String(projects.find(t=>t.active).id);$('flow-status').textContent=t('projectsLinked',{n:projects.length});}}
async function toDataURL(blob){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(r.error);r.readAsDataURL(blob);});}
// 1.5.0: Flow'un urettigi gorseli sahneye baglamak icin uc Google medya adresine erisim
// gerekir. Gorsel credentials:'include' ile cekildigi icin CORS yetmiyor, gercek host izni
// sart. Izin manifest'te optional_host_permissions altinda: boylece magazadaki mevcut
// kullanicilar guncellemede izin artisi gormez ve eklenti devre disi kalmaz.
//
// Izin TAM BURADA isteniyor, kullanici uretimi onayladigi anda. Daha erken istemiyoruz:
// ses cozumleme (Hugging Face) ve istem yazimi (viraldna.io) CORS ile izinsiz calisiyor,
// yani kullanici sekmeyi acar acmaz kutuyla karsilasmasin. Ucretli Gemini adimi da zaten
// bundan once bittigi icin reddedilen izin token yakmaz.
const FLOW_MEDIA_ORIGINS=['https://flow-content.google/*','https://*.googleusercontent.com/*','https://storage.googleapis.com/*'];
async function ensureFlowMediaAccess(){
  if(!extension)return;
  // debugger cannot be optional in Chrome. It must be granted at extension load.
  let sendAllowed=false;
  try{sendAllowed=await chrome.permissions.contains({permissions:['debugger']});}catch(_){}
  if(!sendAllowed)throw new Error(t('permSendReload'));
  try{if(await chrome.permissions.contains({origins:FLOW_MEDIA_ORIGINS}))return;}catch(_){throw new Error(t('permDenied'));}
  let granted=false;
  try{granted=await chrome.permissions.request({origins:FLOW_MEDIA_ORIGINS});}
  catch(_){
    // Cerceve icinden istenemedi (kullanici hareketi dogrulanamadi). Panel ust duzey bir
    // eklenti sayfasi, orada kesin calisir: seridi acmasini soyle.
    try{window.parent.postMessage({af:'narration-permission'},'*');}catch(_){}
    throw new Error(t('permUsePanel'));
  }
  if(!granted)throw new Error(t('permDenied'));
}
async function generate(only,{confirmed=false,tabId:boundTabId}={}){
  assertEditable();
  const repaired=repairCorruptPrompts(project);if(repaired){await save();toast(t('toastRepaired',{n:repaired}));}
  const scenes=Array.isArray(only)?only:project.scenes.filter(s=>!s.imageKey);
  if(!scenes.length){toast(t('toastAllReady'));return;}
  await refreshFlow();const tabId=boundTabId||Number($('flow-tab').value);if(!tabId)throw new Error(t('errOpenFlowRefresh'));
  const current=await send({action:'getState'});
  if(current?.status==='running'||current?.status==='paused'||current?.autoDlActive||current?.bulkDownloading)throw new Error(t('errAutoFlowBusy'));
  
  if(!confirmed){if(!await ask(t('askGenTitle',{n:scenes.length}),t('askGenText'),t('askGenYes'),{model:true}))return;project.settings.imageModel=$('confirm-model-select').value;$('image-model').value=project.settings.imageModel;}
  await ensureFlowMediaAccess();   // onaydan hemen sonra: kullanici hareketi hala taze
  const oldRun=project.run,snapshot=scenes.map(s=>({s,generation:s.generation,status:s.status}));
  busy=true;task(t('taskQueue'),t('taskQueueDetail'));$('cancel-task').hidden=true;
  try{
    scenes.forEach(s=>{s.generation++;s.status='queued';});const run=makeRun(project,scenes),used=new Set(scenes.flatMap(s=>s.refIds)),refs=[];
    for(const r of project.references.filter(r=>used.has(r.id))){const blob=await get('assets',r.key);if(blob)refs.push({id:r.id,name:`afsv-${r.id.slice(0,8)}-${r.name.replace(/[^\w.\-]/g,'_')}`,dataUrl:await toDataURL(blob),type:blob.type});}
    const payload={run,prompts:scenes.map(s=>`(${fmt(s.start,true)}) ${s.prompt}`),refImagesAll:refs.map(({id,...r})=>r),promptRefNames:scenes.map(s=>refs.filter(r=>s.refIds.includes(r.id)).map(r=>r.name)),tabId,interval:Number(project.settings.interval),genSettings:{mode:'IMAGE',model:project.settings.imageModel,aspect:project.settings.aspect==='9:16'?'PORTRAIT':project.settings.aspect==='1:1'?'SQUARE':'LANDSCAPE',count:1}};
    await put('results',`run:${run.id}`,run);await put('results',`request:${run.id}`,payload);project.run=run;await save();
    const result=await send({action:'narrationStart',runId:run.id});if(!result?.success)throw new Error(localizeMessage(result?.error)||t('errFlowStart'));
    // The queue is already committed. A tab-focus error must not roll back its scene IDs.
    chrome.tabs.update(tabId,{active:true}).catch(()=>{});toast(t('toastGenStarted'));
  }catch(e){for(const old of snapshot){old.s.generation=old.generation;old.s.status=old.status;}project.run=oldRun;await save();throw e;}
  finally{$('cancel-task').hidden=false;endTask();}
  renderScenes();await pollFlow();
}
async function pollFlow(){
  if(!project?.run||!extension||pollInFlight||settledRuns.has(project.run.id))return;
  const target=project,run=project.run;pollInFlight=true;
  try{
    const state=await send({action:'narrationStatus',runId:run.id});
    if(project!==target||project.run?.id!==run.id||!state?.success)return;
    const active=state.status==='running'||state.status==='paused'||state.downloading;
    $('run-controls').hidden=false;$('pause-flow').hidden=!active;$('stop-flow').hidden=!active;
    $('pause-flow').textContent=t(state.status==='paused'?'resume':'pause');$('pause-flow').dataset.paused=state.status==='paused'?'1':'0';
    $('run-summary').textContent=t('runSummary',{done:state.currentIndex||0,total:run.sceneIds.length,status:t(state.retrying?'runRetrying':state.retrySoon?'runRetrySoon':state.downloading?'runDownloading':state.status==='paused'?'runPaused':state.status==='running'?'runRunning':'runEnded')});
    let changed=false;
    for(const result of state.results||[]){const s=project.scenes.find(s=>s.id===result.sceneId);if(!s||s.generation!==result.generation)continue;
      if(result.imageKey&&s.imageKey!==result.imageKey)changed=acceptResult(project,result.runId,result.sceneId,result.generation,result.imageKey)||changed;
      else if(result.error&&s.status!=='unmatched'&&!s.imageKey){s.status='unmatched';s.matchError=result.error;changed=true;}
    }
    if(!active){settledRuns.add(run.id);for(const s of project.scenes.filter(s=>s.status==='queued')){s.status=s.imageKey?'ready':'failed';changed=true;}}
    if(changed){await save();if(project.step===2&&!$('scenes').contains(document.activeElement))renderScenes();if(project.step===3)renderVideo();}
  }finally{pollInFlight=false;}
}
async function renderVideo(){const d=dimensions(project.settings.aspect,project.settings.resolution);$('preview').width=d.width;$('preview').height=d.height;$('scrub').max=project.duration;$('preview-time').textContent=`${fmt($('audio-player').currentTime)} / ${fmt(project.duration)}`;const missing=project.scenes.filter(s=>!s.imageKey).length;$('export-check').textContent=missing?t('exportMissing',{n:missing}):t('exportReady',{n:project.scenes.length,duration:fmt(project.duration),w:d.width,h:d.height});$('export-video').disabled=missing>0||!project.scenes.length||busy||readonly;$('timeline').replaceChildren();for(const[i,s]of project.scenes.entries()){const btn=document.createElement('button');btn.style.flex=String(s.end-s.start);btn.title=t('sceneRange',{n:i+1,from:fmt(s.start),to:fmt(s.end)});btn.setAttribute('aria-label',btn.title);btn.innerHTML=`<span>${i+1}</span>`;if(s.imageKey){const img=document.createElement('img');img.src=await blobURL(s.imageKey)||'';img.alt='';btn.prepend(img);}btn.onclick=()=>{$('audio-player').currentTime=s.start;drawPreview(s.start);};$('timeline').append(btn);}drawPreview($('audio-player').currentTime);}
let previewImageKey=null,previewImage=null,previewDrawId=0;
async function drawPreview(time){const drawId=++previewDrawId,scene=sceneAt(project.scenes,time),c=$('preview'),ctx=c.getContext('2d');ctx.fillStyle='#08080b';ctx.fillRect(0,0,c.width,c.height);$('preview-empty').hidden=!!scene?.imageKey;if(!scene?.imageKey)return;if(previewImageKey!==scene.imageKey){const url=await blobURL(scene.imageKey);if(!url)return;const img=new Image();img.src=url;await img.decode();if(drawId!==previewDrawId)return;previewImage=img;previewImageKey=scene.imageKey;}const zoom=project.settings.motion==='zoom'?1+.06*Math.max(0,Math.min(1,(time-scene.start)/(scene.end-scene.start))):1,ratio=Math.max(c.width/previewImage.width,c.height/previewImage.height)*zoom,w=previewImage.width*ratio,h=previewImage.height*ratio;ctx.drawImage(previewImage,(c.width-w)/2,(c.height-h)/2,w,h);}
function updatePlayback(){const a=$('audio-player');$('scrub').value=a.currentTime;$('preview-time').textContent=`${fmt(a.currentTime)} / ${fmt(project.duration)}`;if(project.step===3)drawPreview(a.currentTime);if(!a.paused)previewRaf=requestAnimationFrame(updatePlayback);}
async function exportVideo(){
 assertEditable();validateTimeline(project.scenes,project.duration);if(project.scenes.some(s=>!s.imageKey))throw Error(t('errImageEvery'));
 busy=true;renderVideo();$('audio-player').pause();task(t('taskExport'),t('taskExportDetail'),0);await save();const control=new AbortController();taskReject=()=>control.abort();
 try{const scenes=[];for(const scene of project.scenes){const blob=await get('assets',scene.imageKey);if(!blob)throw Error(t('errSceneImageMissing'));scenes.push({...scene,blob});}
 const {exportFilm}=await import('../vendor/export.mjs');const result=await exportFilm({audio:audioBuffer,scenes,...dimensions(project.settings.aspect,project.settings.resolution),motion:project.settings.motion,signal:control.signal,onProgress:percent=>task(t('taskExport'),t('exportProgress',{pct:Math.round(percent)}),percent)});
 if($('download-video').href.startsWith('blob:'))URL.revokeObjectURL($('download-video').href);const url=URL.createObjectURL(result.file);$('download-video').href=url;$('download-video').download=project.title+'.mp4';$('finished-video').src=url;$('export-result').hidden=false;$('export-result').scrollIntoView({block:'center'});toast(t('toastMp4'));
 }finally{endTask();renderVideo();}
}
function download(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);}

function clearProjectUI(){
  revokeURLs();cancelAnimationFrame(previewRaf);previewDrawId++;imageRequest++;
  audioBuffer=null;decodedAudioKey=null;audioSize=0;previewImageKey=null;previewImage=null;imageSceneId=null;proofreadNote='';filter='all';
  for(const id of ['audio-input','subtitles-input','reference-input','images-input','backup-input'])$(id).value='';
  for(const id of ['scenes','reference-list','timeline'])$(id).replaceChildren();
  $('run-controls').hidden=true;$('run-summary').textContent='';$('flow-tab').replaceChildren();
  $('export-result').hidden=true;$('preview-empty').hidden=false;$('scrub').value=0;$('scrub').max=0;$('preview-time').textContent='00:00 / 00:00';
  $('audio-name').textContent='';$('audio-meta').textContent='';$('scene-summary').textContent='';$('prompt-error').hidden=true;
  for(const id of ['waveform','preview']){const canvas=$(id);canvas.getContext('2d').clearRect(0,0,canvas.width,canvas.height);}
  document.querySelectorAll('[data-filter]').forEach(b=>b.classList.toggle('active',b.dataset.filter==='all'));
}
async function ensureResetIdle(){
  assertEditable();if(pipelineActive)throw new Error(t('errBusy'));
  if(project.run&&extension){const state=await send({action:'narrationStatus',runId:project.run.id});if(!state?.success||state.status==='running'||state.status==='paused'||state.downloading)throw new Error(t('resetFlowActive'));}
}
async function resetProject(){
  await ensureResetIdle();busy=true;document.querySelector('main').inert=true;$('projects-btn').disabled=true;renderActions();
  try{
    await save();const previous=project;
    const next=newProject();next.title=t('untitled');
    next.resetUndoId=previous.audioKey||previous.scenes.length||previous.references.length||previous.transcript||!previous.resetUndoId?previous.id:previous.resetUndoId;
    await put('projects',next.id,next);project=next;clearProjectUI();await save();await render();toast(t('resetDone'));
  }finally{endTask();}
}
async function undoReset(){
  await ensureResetIdle();if(!project.resetUndoId)return;busy=true;document.querySelector('main').inert=true;$('projects-btn').disabled=true;renderActions();
  try{const previous=await get('projects',project.resetUndoId);if(!previous)return;await save();project=previous;delete project.resetUndoId;clearProjectUI();await save();await render();toast(t('resetUndone'));}
  finally{endTask();}
}

async function showProjects(){await save();const projects=(await all('projects')).sort((a,b)=>b.updatedAt-a.updatedAt);$('project-list').replaceChildren();for(const p of projects){const div=document.createElement('div');div.className='project-entry';div.innerHTML=`<div><strong>${safe(p.title)}</strong><small>${safe(t('projectMeta',{n:p.scenes.length,duration:fmt(p.duration),date:new Date(p.updatedAt).toLocaleDateString(locale())}))}</small></div><button class="secondary">${safe(t(p.id===project.id?'projCurrent':'projOpen'))}</button>`;div.querySelector('button').onclick=async()=>{try{assertEditable();await save();revokeURLs();project=p;audioBuffer=null;previewImageKey=null;await render();$('projects-dialog').close();}catch(e){report(e);}};$('project-list').append(div);}$('projects-dialog').showModal();}
async function backup(){assertEditable();await save();const keys=[project.audioKey,...project.references.map(r=>r.key),...project.scenes.map(s=>s.imageKey)].filter(Boolean),assets={};busy=true;task(t('taskBackup'),t('taskBackupDetail'));try{for(const key of new Set(keys)){const blob=await get('assets',key);if(blob)assets[key]=await toDataURL(blob);}download(new Blob([JSON.stringify({format:'AutoFlowStory',version:1,project,assets})],{type:'application/json'}),`${project.title.replace(/[<>:"/\\|?*]/g,'_')}.afstory`);toast(t('toastBackup'));}finally{endTask();}}
async function restore(file){assertEditable();if(!file)return;if(file.size>600*1048576)throw new Error(t('errBackupBig'));let data=JSON.parse(await file.text());if(data.format==='ELPODNA'&&data.version===1&&Array.isArray(data.assets)){data={format:'AutoFlowStory',version:1,project:globalThis.elpodnaLegacyStory(data.project),assets:Object.fromEntries(data.assets.map(a=>[a.id,a.data]))};}if(data.format!=='AutoFlowStory'||data.version!==1||!data.project||!data.assets)throw new Error(t('errBackupInvalid'));const p=data.project;if(!Array.isArray(p.scenes)||!Array.isArray(p.references)||!p.settings||!(p.duration>0&&p.duration<=MAX_DURATION))throw new Error(t('errProjectInvalid'));if(p.scenes.length)validateTimeline(p.scenes,p.duration);const map=new Map(),wanted=[p.audioKey,...p.references.map(r=>r.key),...p.scenes.map(s=>s.imageKey)].filter(Boolean);for(const old of new Set(wanted)){const uri=data.assets[old];if(typeof uri!=='string'||!/^data:(audio\/[\w.+-]+|image\/(png|jpeg|webp)|application\/octet-stream);base64,/.test(uri))throw new Error(t('errBackupMedia'));const blob=await(await fetch(uri)).blob(),key=`restore:${uid()}`;await put('assets',key,blob);map.set(old,key);}await save();revokeURLs();p.id=uid();p.run=null;p.title=String(p.title||t('backupProject')).slice(0,100);p.audioKey=map.get(p.audioKey);p.references.forEach(r=>r.key=map.get(r.key));p.scenes.forEach(s=>{s.imageKey=s.imageKey?map.get(s.imageKey):null;s.status=s.imageKey?'ready':'draft';});project=p;await save();await render();$('projects-dialog').close();toast(t('toastRestored'));}
async function render(){if(!readonly){if(migratePromptMetadata(project))await save();const repaired=repairCorruptPrompts(project);if(repaired){await save();toast(t('toastRepairedOld',{n:repaired}));}}$('project-title').value=project.title;for(const[id,key]of Object.entries({language:'language',whisper:'whisper',aspect:'aspect','scene-seconds':'sceneSeconds',extra:'extra','image-model':'imageModel',interval:'interval',resolution:'resolution',motion:'motion'}))$(id).value=project.settings[key];document.querySelectorAll('[data-style]').forEach(b=>b.classList.toggle('selected',b.dataset.style===project.settings.style));showCustomStyle();$('export-result').hidden=true;await loadAudio();renderTranscript();await renderReferences();go(project.step||0);renderActions();}
let imageSceneId=null,imageRequest=0;
async function openImage(id){
  const scene=project.scenes.find(s=>s.id===id);if(!scene?.imageKey)return;
  imageSceneId=id;const request=++imageRequest,url=await blobURL(scene.imageKey);if(request!==imageRequest)return;
  const i=project.scenes.indexOf(scene),ready=project.scenes.filter(s=>s.imageKey),at=ready.indexOf(scene);
  $('image-large').src=url||'';$('image-large').alt=t('sceneN',{n:i+1});
  $('image-title').textContent=t('imageTitle',{n:String(i+1).padStart(2,'0'),total:project.scenes.length});
  $('image-caption').textContent=scene.text;$('image-time').textContent=fmt(scene.start)+' → '+fmt(scene.end);
  const lastFocus=document.activeElement;
  $('image-prev').disabled=at===0;$('image-next').disabled=at===ready.length-1;
  if(lastFocus===$('image-next')&&$('image-next').disabled)$('image-prev').focus();
  if(lastFocus===$('image-prev')&&$('image-prev').disabled)$('image-next').focus();
  if(!$('image-dialog').open)$('image-dialog').showModal();
}
function moveImage(direction){const ready=project.scenes.filter(s=>s.imageKey),i=ready.findIndex(s=>s.id===imageSceneId),next=ready[i+direction];if(next)return openImage(next.id);}

document.querySelectorAll('[data-step]').forEach(b=>b.onclick=()=>go(Number(b.dataset.step)));
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>$(b.dataset.close).close());
document.querySelectorAll('[data-style]').forEach(b=>b.onclick=()=>{project.settings.style=b.dataset.style;document.querySelectorAll('[data-style]').forEach(el=>el.classList.toggle('selected',el===b));showCustomStyle();if(b.dataset.style==='custom')$('custom-style').focus();requestSave();});
function showCustomStyle(){$('custom-style-field').hidden=project.settings.style!=='custom';$('custom-style').value=project.settings.customStyle||'';}
on('custom-style','input',e=>{project.settings.customStyle=e.target.value;requestSave();});
document.querySelectorAll('[data-filter]').forEach(b=>b.onclick=()=>{filter=b.dataset.filter;document.querySelectorAll('[data-filter]').forEach(el=>el.classList.toggle('active',el===b));renderScenes();});
for(const[id,key]of Object.entries({language:'language',whisper:'whisper',aspect:'aspect','scene-seconds':'sceneSeconds',extra:'extra','image-model':'imageModel',interval:'interval',resolution:'resolution',motion:'motion'}))on(id,'change',()=>{if(id==='interval'&&!$(id).checkValidity()){$(id).reportValidity();$(id).value=project.settings.interval;return;}project.settings[key]=$(id).value;requestSave();if(project.step===3)renderVideo();});
on('project-title','input',e=>{project.title=e.target.value||t('untitled');requestSave();});on('home','click',e=>{e.preventDefault();go(0);});
on('audio-drop','click',()=>$('audio-input').click());on('replace-audio','click',()=>$('audio-input').click());on('audio-input','change',e=>addAudio(e.target.files[0]));
for(const ev of['dragover','dragenter'])on('audio-drop',ev,e=>{e.preventDefault();$('audio-drop').classList.add('dragging');});on('audio-drop','dragleave',()=>$('audio-drop').classList.remove('dragging'));on('audio-drop','drop',e=>{e.preventDefault();$('audio-drop').classList.remove('dragging');return addAudio(e.dataTransfer.files[0]);});
on('transcribe','click',transcribe);on('subtitles-btn','click',()=>$('subtitles-input').click());on('subtitles-input','change',e=>addSubtitles(e.target.files[0]));on('to-style','click',()=>go(1));on('create-scenes','click',createScenes);on('improve-prompts','click',improvePrompts);
on('image-prev','click',()=>moveImage(-1));on('image-next','click',()=>moveImage(1));
on('image-dialog','keydown',e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();return moveImage(e.key==='ArrowLeft'?-1:1);}});
on('generate-ready','click',()=>generate());
on('add-reference','click',()=>$('reference-input').click());on('reference-input','change',e=>addReferences(e.target.files));on('library-btn','click',openLibrary);on('import-images','click',()=>$('images-input').click());on('images-input','change',e=>importImages(e.target.files));on('refresh-flow','click',refreshFlow);
on('open-flow','click',()=>{if(extension)return chrome.tabs.create({url:'https://labs.google/fx/tools/flow'});window.open('https://labs.google/fx/tools/flow','_blank','noopener');});on('generate','click',()=>generate());
on('pause-flow','click',async()=>{const res=await send({action:'narrationControl',runId:project.run?.id,command:$('pause-flow').dataset.paused==='1'?'resume':'pause'});if(!res?.success)throw new Error(localizeMessage(res?.error)||t('errAction'));await pollFlow();});on('stop-flow','click',async()=>{const res=await send({action:'narrationControl',runId:project.run?.id,command:'stop'});if(!res?.success)throw new Error(localizeMessage(res?.error)||t('errAction'));await pollFlow();});
on('to-video','click',()=>go(3));on('play-preview','click',()=>{const a=$('audio-player');if(a.paused)return a.play();a.pause();});on('scrub','input',e=>{$('audio-player').currentTime=Number(e.target.value);updatePlayback();});on('audio-player','play',()=>{$('play-preview').textContent='Ⅱ';cancelAnimationFrame(previewRaf);updatePlayback();});on('audio-player','pause',()=>{$('play-preview').textContent='▶';cancelAnimationFrame(previewRaf);});on('audio-player','timeupdate',()=>{if(project?.step===0)drawWave();});
on('export-video','click',exportVideo);on('export-srt','click',()=>download(new Blob([srt(project.scenes)],{type:'text/plain;charset=utf-8'}),t('srtFile')));on('export-prompts','click',()=>download(new Blob([project.scenes.map(s=>`(${fmt(s.start)}) ${s.prompt}`).join('\n\n')],{type:'text/plain;charset=utf-8'}),t('promptsFile')));
on('reset-project','click',resetProject);on('undo-reset','click',undoReset);on('projects-btn','click',showProjects);on('new-project','click',async()=>{assertEditable();await save();revokeURLs();project=newProject();project.title=t('untitled');audioBuffer=null;previewImageKey=null;await save();await render();$('projects-dialog').close();});on('backup-project','click',backup);on('restore-project','click',()=>$('backup-input').click());on('backup-input','change',e=>restore(e.target.files[0]));
on('expand','click',async()=>{if(busy)throw new Error(t('errExpandBusy'));await save();parent.postMessage({type:'af-studio-expand'},location.origin);});
on('cancel-task','click',()=>{cancelRequested=true;aiWorker?.terminate();exportWorker?.terminate();aiWorker=null;exportWorker=null;taskReject?.(new Error(t('errCancelled')));$('task-detail').textContent=t('stopping');});
window.addEventListener('beforeunload',e=>{if(busy){e.preventDefault();e.returnValue='';}});window.addEventListener('pagehide',()=>{aiWorker?.terminate();exportWorker?.terminate();lockRelease?.();});
// Style cards show a real sample when studio/styles/<style>.jpg exists; otherwise the drawn art stays.
async function loadStyleSamples(){
  for(const btn of document.querySelectorAll('[data-style]')){
    const art=btn.querySelector('.style-art');if(!art||art.querySelector('img'))continue;
    const src=`styles/${btn.dataset.style}.jpg`;
    try{if(!(await fetch(src,{method:'HEAD'})).ok)continue;}catch{continue;}
    const img=document.createElement('img');img.alt='';img.src=src;art.append(img);
  }
}
async function init(){loadStyleSamples().catch(()=>{});for(let i=0;i<35;i++){const b=document.createElement('b');b.style.height=`${7+Math.abs(Math.sin(i*.8)*Math.cos(i*.17))*30}px`;$('hero-wave').append(b);}if(navigator.locks){let acquired;const ready=new Promise(r=>acquired=r);navigator.locks.request('af-narration-editor',{ifAvailable:true},async lock=>{readonly=!lock;acquired();if(lock)await new Promise(r=>lockRelease=r);});await ready;}const current=localStorage.getItem('elpodna-story-current');project=current?await get('projects',current):null;if(!project){project=newProject();project.title=t('untitled');}await render();if(readonly){const banner=document.createElement('div');banner.className='read-only-banner';banner.textContent=t('readonlyBanner');document.body.prepend(banner);document.querySelectorAll('button,input,textarea,select').forEach(e=>e.disabled=true);}else{await save();setInterval(()=>pollFlow().catch(e=>console.warn('Flow status:',e.message)),4000);}}
// Language first, then the Pro gate; the studio itself starts only for ViralDNA Pro members.
let started=false;
function relabel(){
  applyStatic();renderGate();relabelTokenStore();
  if(!project)return;
  if(variants('untitled').includes(project.title)){project.title=t('untitled');$('project-title').value=project.title;requestSave();}
  $('pause-flow').textContent=t($('pause-flow').dataset.paused==='1'?'resume':'pause');
  $('save-status').textContent=t(saveStatusKey);if(project.audioKey&&audioSize)renderAudioMeta();
  renderTranscript();renderReferences().catch(report);refreshFlow().catch(()=>{});
  if(project.step===2)renderScenes().catch(report);if(project.step===3)renderVideo().catch(report);
}
// Surum etiketi ELLE yazilmaz: 1.4.6 kaldigi icin studyo eski surumu gosteriyordu.
function showVersion(){try{const v=globalThis.chrome?.runtime?.getManifest?.().version;const el=$('studio-ver');if(el)el.textContent='BETA'+(v?' · '+v:'');}catch(_){}}
async function boot(){
  try{const old=await globalThis.elpodnaMigrate?.();if(old&&!localStorage.getItem('elpodna-story-current'))localStorage.setItem('elpodna-story-current',old);}catch(e){report(new Error('Migration incomplète ; anciennes données conservées. '+e.message));}
  await loadLang();useMessages(key=>t(key));applyStatic();watchLang(relabel);
  showVersion();if(!started){started=true;await init();}
}
on('token-add','click',showProjects);on('gemini-copy','click',copyGemini);on('gemini-apply','click',applyGeminiWeb);on('gemini-open','click',()=>extension?chrome.tabs.create({url:'https://gemini.google.com/app'}):window.open('https://gemini.google.com/app','_blank','noopener'));
boot().catch(report);
