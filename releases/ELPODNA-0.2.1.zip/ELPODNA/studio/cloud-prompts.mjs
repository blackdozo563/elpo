import {buildPrompt, styleText, message} from './core.mjs';
import {repetitionReason} from './prompt-policy.mjs';
import {getLang} from './i18n.mjs';

export function storyPayload(project) {
  return {duration:project.duration, transcript:project.transcript,
    style:styleText(project.settings), aspect:project.settings.aspect,
    direction:project.settings.extra||'', language:getLang(),
    // The description goes into the prompts; the note only tells Gemini who the reference is.
    references:project.references.map(r=>({id:r.id,tag:r.tag,description:r.description||'',note:r.note||''})),
    scenes:project.scenes.map(s=>({id:s.id,start:s.start,end:s.end,text:s.text,refIds:s.refIds}))};
}
// Validate the complete response before replacing a single user-edited prompt.
export function applyStoryPrompts(project, result) {
  if(!Array.isArray(result?.scenes)||result.scenes.length!==project.scenes.length)throw new Error(message('gIncomplete','Gemini tüm sahneleri tamamlayamadı. Mevcut istemler korundu.'));
  const map=new Map(result.scenes.map(s=>[s.id,s]));
  if(map.size!==project.scenes.length)throw new Error(message('gDuplicate','Gemini yanıtında tekrar eden sahne var.'));
  const known=new Set(project.references.map(r=>r.id));
  const updates=project.scenes.map(s=>{
    const item=map.get(s.id),visual=item?.visual;
    if(typeof visual!=='string'||visual.trim().length<20||visual.length>6000||repetitionReason(visual))throw new Error(message('gInvalid','Gemini yanıtı geçersiz. Mevcut istemler korundu.'));
    const refs=Array.isArray(item.refs)?[...new Set(item.refs.filter(id=>known.has(id)))]:null;
    return {s,visual:visual.trim(),refs,warning:typeof item.warning==='string'?item.warning.slice(0,500):''};
  });
  // An explicit empty list is also a decision. Never resurrect a literal-name guess.
  // Legacy replies without refs may use the tags Gemini wrote into the visual.
  for(const u of updates)if(u.refs===null)u.refs=project.references.filter(r=>u.visual.includes(r.tag)).map(r=>r.id);
  for(const u of updates){
    if(!u.s.refsManual)u.s.refIds=u.refs;
    u.s.visual=u.visual;u.s.previousPrompt=u.s.prompt;u.s.prompt=buildPrompt(u.s,project,u.visual);u.s.promptSource='gemini';u.s.promptWarning=u.warning;
  }
  return updates.filter(x=>x.warning).length;
}
