const DB_NAME = 'elpodna-studio-v2';
let connection;
export function openDB() {
  if (!connection) connection = new Promise((resolve,reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      for (const name of ['projects','assets','results']) if (!req.result.objectStoreNames.contains(name)) req.result.createObjectStore(name);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => {connection = null; reject(req.error);};
  });
  return connection;
}
export async function get(store,key) {
  const db = await openDB();
  return new Promise((resolve,reject) => {const r=db.transaction(store).objectStore(store).get(key); r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
}
export async function put(store,key,value) {
  const db=await openDB();
  return new Promise((resolve,reject)=>{const tx=db.transaction(store,'readwrite');tx.objectStore(store).put(value,key);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);});
}
export async function all(store) {
  const db=await openDB();return new Promise((resolve,reject)=>{const r=db.transaction(store).objectStore(store).getAll();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
}
export async function remove(store,key) {
  const db=await openDB();return new Promise((resolve,reject)=>{const tx=db.transaction(store,'readwrite');tx.objectStore(store).delete(key);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});
}
export async function readLibrary() {
  return new Promise(resolve=>{
    const r=indexedDB.open('autoflow-refs',1);
    r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('kv'))r.result.createObjectStore('kv');};
    r.onerror=()=>resolve([]);r.onsuccess=()=>{
      const db=r.result;if(!db.objectStoreNames.contains('kv')){db.close();resolve([]);return;}
      const q=db.transaction('kv').objectStore('kv').get('afLibrary');q.onsuccess=()=>{db.close();resolve(q.result||[]);};q.onerror=()=>{db.close();resolve([]);};
    };
  });
}
