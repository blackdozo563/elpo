// Integration for the separate 1.3.0 narration edition. Original queue routines remain the runner.
function afStoryDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open('elpodna-studio-v2',1);r.onupgradeneeded=()=>{for(const s of ['projects','assets','results'])if(!r.result.objectStoreNames.contains(s))r.result.createObjectStore(s);};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
async function afStoryGet(store,key){const db=await afStoryDB();return new Promise((resolve,reject)=>{const r=db.transaction(store).objectStore(store).get(key);r.onsuccess=()=>{db.close();resolve(r.result);};r.onerror=()=>{db.close();reject(r.error);};});}
async function afStoryPut(store,key,value){const db=await afStoryDB();return new Promise((resolve,reject)=>{const tx=db.transaction(store,'readwrite');tx.objectStore(store).put(value,key);tx.oncomplete=()=>{db.close();resolve();};tx.onerror=()=>{db.close();reject(tx.error);};});}
async function afStoryResults(run){const db=await afStoryDB();return new Promise((resolve,reject)=>{const tx=db.transaction('results'),results=[];for(const id of run.sceneIds){const req=tx.objectStore('results').get(`result:${run.id}:${id}`);req.onsuccess=()=>{if(req.result)results.push(req.result);};}tx.oncomplete=()=>{db.close();resolve(results);};tx.onerror=()=>{db.close();reject(tx.error);};});}
// Media identity of a Flow tile, same rule the download pipeline uses.
function afStoryMediaId(u){const s=String(u||'');const m=s.match(/(?:[?&]name=|flow-content\.google\/[a-z]+\/)([^&?/]+)/i);if(m)return m[1];const a=s.match(/\/asb\/([A-Za-z0-9_-]{20,})/);return a?'asb:'+a[1]:'';}
// Tiles handled by an earlier run of the same story. Without this ledger every new run
// (a single scene regenerated) downloads the whole Flow project again.
async function afStorySeen(projectId){if(!projectId)return[];const seen=await afStoryGet('results',`seen:${projectId}`);return Array.isArray(seen?.ids)?seen.ids:[];}
async function afStoryRemember(projectId,mediaId){
  if(!projectId||!mediaId)return;
  const ids=await afStorySeen(projectId);if(ids.includes(mediaId))return;
  ids.push(mediaId);await afStoryPut('results',`seen:${projectId}`,{ids:ids.slice(-2000)});
}
let afStoryStarting=false;
function afStoryRevision(n){let label='';for(let v=n+1;v>0;v=Math.floor((v-1)/26))label=String.fromCharCode(97+(v-1)%26)+label;return label;}
async function afStoryDownloadPlan(run){
  const key=`downloads:${run.projectId}`;
  const meta=await afStoryGet('results',key)||{folder:state.narrationRun?.projectId===run.projectId&&state.dlFolder?state.dlFolder:makeDownloadFolder(),counts:{},runs:{}};
  if(meta.runs[run.id])return {folder:meta.folder,names:meta.runs[run.id]};
  const names=run.sceneIds.map((id,i)=>{
    const number=run.sceneNumbers?.[i]||i+1;
    const revision=meta.counts[id]??Math.max(0,(run.versions[i]||1)-1);
    meta.counts[id]=revision+1;
    return String(number).padStart(4,'0')+(revision?' ('+afStoryRevision(revision)+')':'');
  });
  meta.runs[run.id]=names;
  await afStoryPut('results',key,meta);
  return {folder:meta.folder,names};
}
chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
  if(!['narrationStart','narrationStatus','narrationControl'].includes(msg?.action))return;
  if(sender.id!==chrome.runtime.id||!String(sender.url||'').startsWith(chrome.runtime.getURL('studio/'))){reply({success:false,error:'Bu işlem yalnızca Sesten Videoya stüdyosundan başlatılabilir.'});return false;}
  (async()=>{
    await initReady;
    if(msg.action==='narrationStart'){
      if(afStoryStarting||state.status==='running'||state.status==='paused'||dlLoopActive)throw new Error('Auto Flow şu anda başka bir işlemi yürütüyor.');
      afStoryStarting=true;
      try{
        const payload=await afStoryGet('results',`request:${msg.runId}`),run=payload?.run;
        if(!run||run.id!==msg.runId||!Array.isArray(run.sceneIds)||!run.sceneIds.length||run.sceneIds.length>500||!Array.isArray(run.versions)||run.versions.length!==run.sceneIds.length||new Set(run.sceneIds).size!==run.sceneIds.length||!Array.isArray(payload.prompts)||payload.prompts.length!==run.sceneIds.length||payload.prompts.some(p=>typeof p!=='string'||!p.trim()||p.length>12000))throw new Error('Geçersiz sahne kuyruğu.');
        const session=await chrome.storage.local.get('sb_session');if(!session.sb_session?.user)throw new Error('Önce Auto Flow panelinden Google ile giriş yapın.');
        const tab=await chrome.tabs.get(payload.tabId),url=new URL(tab.url||'');
        if(url.protocol!=='https:'||!['labs.google','flow.google.com'].includes(url.hostname)||!url.pathname.includes('/project/'))throw new Error('Geçerli bir Google Flow projesi seçin.');
        if((payload.refImagesAll||[]).length>10)throw new Error('En fazla 10 referans kullanılabilir.');
        // Tiles from earlier runs of this story are skipped, so regenerating one scene
        // downloads one image instead of the whole project again.
        const skipKeys={};for(const id of await afStorySeen(run.projectId))skipKeys['k:'+id]=true;
        // retryFailed: a scene Flow could not produce is re-sent at the end of the run.
        if(run.sceneNumbers&&(!Array.isArray(run.sceneNumbers)||run.sceneNumbers.length!==run.sceneIds.length||run.sceneNumbers.some(n=>!Number.isInteger(n)||n<1||n>500)))throw new Error('Geçersiz sahne numaraları.');
        const plan=await afStoryDownloadPlan(run);
        await handleStart({action:'start',prompts:payload.prompts,interval:Math.max(1,Math.min(90,Number(payload.interval)||1)),tabId:payload.tabId,flowUrl:tab.url,narrationRun:{...run,downloadNames:plan.names},narrationFolder:plan.folder,refImagesAll:payload.refImagesAll||[],refMode:'map',promptRefNames:payload.promptRefNames||[],frameMode:'ingredients',autoDownload:true,retryFailed:true,narrationSkipKeys:skipKeys,dlQualityImg:'1k',dlQualityVid:'720p',videoOnly:false,genSettings:{...payload.genSettings,mode:'IMAGE',count:1}});
        if(state.narrationRun?.id!==run.id)throw new Error('Kuyruk henüz başlayamadı. Birkaç saniye sonra tekrar deneyin.');
        return {success:true};
      }finally{afStoryStarting=false;}
    }
    if(msg.action==='narrationControl'){
      if(state.narrationRun?.id!==msg.runId)throw new Error('Bu projeye ait aktif üretim bulunamadı.');
      if(msg.command==='pause')await handlePause();else if(msg.command==='resume')await handleResume();else if(msg.command==='stop'){dlCancel=true;await handleStop();}else throw new Error('Geçersiz işlem.');
      return {success:true};
    }
    // Status polling must not deserialize reference images every four seconds.
    let run=await afStoryGet('results',`run:${msg.runId}`);
    if(!run){run=(await afStoryGet('results',`request:${msg.runId}`))?.run;if(!run)return{success:false};await afStoryPut('results',`run:${msg.runId}`,run);}
    const results=await afStoryResults(run);
    const same=state.narrationRun?.id===msg.runId;
    // retrySoon: the run is over but the download line still waits for Flow's late cards before the retry.
    const retrySoon=same&&!state.retryPhase&&!state.retryDone&&!!state.retryOn&&state.status==='completed'&&!!(dlLoopActive||state.autoDlActive)&&[state.failProven,state.narrationFailed].some(m=>m&&Object.values(m).some(Boolean));
    return {success:true,status:same?state.status:'completed',currentIndex:same?state.currentIndex:run.sceneIds.length,downloading:same&&!!(dlLoopActive||state.autoDlActive||state.retryPhase),retrying:same&&!!state.retryPhase,retrySoon,results};
  })().then(reply).catch(e=>reply({success:false,error:e.message}));return true;
});
// ── 1.4.2 SIRA KANITI ──────────────────────────────────────────────────────────────
// Gemini writes long prompts and Flow titles those cards itself ("Elderly man looking at sea"),
// so the first-characters text proof rarely binds; 1.4.1 downloaded nothing and then re-generated
// every scene. A narration run knows its own send order: every prompt makes exactly one card,
// cards appear in send order, and a prompt Flow could not produce still leaves a failed card.
// The run counts the cards that exist before its first prompt (afNarrationSnapshot); afterwards a
// card's order among the newer cards is its prompt. Older cards are recognised by media id, or by
// count when they had no media yet (they are older than every new card, so they come first).
// No guessing: more new cards than sent prompts (a card made by hand in the same project) gives
// no proof, and a card that is not drawn yet makes the download wait instead of shifting scenes.
async function afNarrationSnapshot(tabId){
  let last=null;
  for(let i=0;i<8;i++){
    let tiles=[];
    try{const res=await chrome.scripting.executeScript({target:{tabId},world:'MAIN',func:flowCollectTiles});tiles=res?.[0]?.result||[];}catch(_){}
    const ids={};let unkeyed=0,loading=0,tail=0;
    for(const t of tiles){
      const sid=t.key?afStableId(t.key):'';
      if(sid){ids[sid]=1;tail=0;continue;}
      if(t.state==='reference')continue;
      unkeyed++;tail++;if(t.state==='pending'||t.state==='generating')loading++;
    }
    // tail: cards without a media id that are newer than the newest card with one (v195).
    const snap={ids,unkeyed,tail,total:tiles.length,loading};
    if(last&&last.total===snap.total&&!loading)return snap;   // two equal scans, every image loaded
    last=snap;await sleep(700);
  }
  return last||{ids:{},unkeyed:0,total:0,loading:0};
}
// ── v195 FLOW IZGARASI ESKI KARTLARI BIRAKIYOR ──────────────────────────────────────
// Kullanici kosusu (2026-09-30, 1.5.4 adayi): ~127 karttan sonra Flow en ESKI kartlari DOM'dan
// cikariyor. Yalniz ekrandaki kartlari saymak her yeni karti ayni siraya koydu (konum:126 sabit):
// 128-130. sahnelerin gorselleri 127'ye baglandi ("(1)(2)(3)" dosyalari), sonra sayi hic tutmadigi
// icin indirme "sira-bekleniyor"da kaldi. Artik kanitlanan her kartin sirasi medya kimligiyle
// saklanir (state.narrationOrd) ve yeni kart, ekranda duran EN YAKIN kayitli karta gore sayilir.
// Flow yalniz en eski uctan biraktigi icin iki kart arasindakiler hep ekrandadir.
// This run's cards (oldest first) and the prompt indices that should own them.
function afNarrationCards(tiles,refLike){
  const base=state.narrationBase;if(!base||!Array.isArray(tiles))return null;
  const known=state.narrationOrd||{},hasTail=Number.isInteger(base.tail);
  // The snapshot is the oldest part of the grid: everything up to its newest card with a media id
  // belongs to it, even after Flow dropped its oldest cards (a count from the top would then eat
  // this run's cards). Only the unkeyed cards that were newer than that card follow it (base.tail).
  let from=0;
  if(hasTail)for(let j=0;j<tiles.length;j++){const t=tiles[j];if(t&&!refLike(t)&&t.key&&base.ids[afStableId(t.key)])from=j+1;}
  const seen=new Set(),cards=[];let older=hasTail?base.tail:(base.unkeyed||0);
  for(let j=from;j<tiles.length;j++){
    const t=tiles[j];if(!t||refLike(t))continue;
    const sid=t.key?afStableId(t.key):'';
    if(sid&&base.ids[sid])continue;
    if(sid){if(seen.has(sid))continue;seen.add(sid);}
    const ord=sid&&Number.isInteger(known[sid])?known[sid]:-1;
    if(ord>=0)older=0;                 // a proven card of this run: the snapshot is behind it
    else if(older>0){older--;continue;}
    cards.push({j,state:t.state,sid,ord});
  }
  const sent=Math.min(state.currentIndex||0,Array.isArray(state.prompts)?state.prompts.length:0),skipped=state.skippedPrompts||{},expected=[];
  for(let i=0;i<sent;i++)if(!skipped[i])expected.push(i);
  return {cards,expected};
}
// {slot} = proven prompt, {wait:true} = an earlier card may still be drawn, {} = no proof.
function afNarrationOrder(tiles,idx,refLike){
  const m=afNarrationCards(tiles,refLike);if(!m)return {};
  const pos=m.cards.findIndex(c=>c.j===idx);if(pos<0)return {};
  const me=m.cards[pos],now=Date.now();
  if(me.ord>=0)return me.ord<m.expected.length?{slot:m.expected[me.ord]}:{};
  // v195: the nearest proven card on screen tells how many older cards Flow has dropped.
  let shift=0,anchored=false;
  for(let d=1;d<m.cards.length&&!anchored;d++)for(const k of [pos-d,pos+d]){const c=m.cards[k];if(c&&c.ord>=0){shift=c.ord-k;anchored=true;break;}}
  if(!anchored&&state.narrationOrd&&Object.keys(state.narrationOrd).length){
    // Every proven card has left the screen: counting what is left would shift the story.
    if(!state.narrationGapSince)state.narrationGapSince=now;
    return now-state.narrationGapSince<30000?{wait:true}:{};
  }
  const order=pos+shift,count=m.cards.length+shift;
  if(order<0||order>=m.expected.length||count>m.expected.length)return {};
  if(count<m.expected.length){
    // Flow draws a new card a moment after the send; a gap older than that is not explained by lag.
    const sentAt=state.promptSentAt||{},missing=m.expected.length-count;
    if(!m.expected.slice(-missing).every(i=>now-(sentAt[i]||0)<20000)){
      if(!state.narrationGapSince)state.narrationGapSince=now;
      return (state.status==='running'||now-state.narrationGapSince<30000)?{wait:true}:{};
    }
  }
  state.narrationGapSince=0;
  if(me.sid)(state.narrationOrd||(state.narrationOrd={}))[me.sid]=order;
  return {slot:m.expected[order]};
}
// Retry at the end only re-sends a scene with evidence that Flow failed it. A finished card that
// could not be bound is not re-generated (that burned Flow credits in 1.4.1); the scene shows
// "Yeniden dene" in the studio instead.
function afNarrationRetryAllowed(i){return !!((state.narrationFailed&&state.narrationFailed[i])||(state.failProven&&state.failProven[i]));}
// Flow v2 (2026-09) serves generated images from flow.google.com/asb/<token>=<size> and media from
// flow-content.google. The first real run (78 scenes) bound every card by order proof and then refused
// every image right here, because this list still only knew the labs.google era hosts.
const AF_STORY_IMAGE_HOST=/(^|\.)(labs\.google|flow\.google\.com|flow-content\.google|googleusercontent\.com)$|^storage\.googleapis\.com$/;
// The worker fetch uses the extension's host permissions; a short network hiccup is tried again. If it
// still fails, the Flow tab (which shows this very image with its own session) fetches it.
async function afNarrationImage(url){
  for(let attempt=0;attempt<2;attempt++){
    try{
      const response=await fetch(url,{credentials:'include',signal:AbortSignal.timeout(25000)});
      if(response.ok){const blob=await response.blob();if(/^image\/(jpeg|png|webp)/.test(blob.type))return blob;}
    }catch(_){}
    if(!attempt)await new Promise(r=>setTimeout(r,1500));
  }
  try{
    const [res]=await chrome.scripting.executeScript({target:{tabId:state.tabId},world:'MAIN',args:[url],func:async u=>{
      try{const r=await fetch(u,{credentials:'include'});if(!r.ok)return null;const b=await r.blob();
        return await new Promise(ok=>{const f=new FileReader();f.onload=()=>ok(f.result);f.onerror=()=>ok(null);f.readAsDataURL(b);});}catch(_){return null;}
    }});
    const dataUrl=res&&res.result;
    if(typeof dataUrl==='string'&&/^data:image\/(jpeg|png|webp);base64,/.test(dataUrl))return await (await fetch(dataUrl)).blob();
  }catch(_){}
  throw new Error('Görsel stüdyoya alınamadı. İndirilen dosyayı sahneden seçin.');
}
async function afNarrationCapture(run,slot,url,source){
  // The file is already on disk at this point, so the tile is remembered even when the
  // scene link cannot be proven; a later run must not download it a second time.
  try{await afStoryRemember(run.projectId,afStoryMediaId(url));}catch(e){console.warn('Tile defteri yazılamadı:',e.message);}
  const sceneId=run.sceneIds?.[slot];if(!sceneId)return;
  const result={runId:run.id,sceneId,generation:run.versions[slot],createdAt:Date.now()};
  try{
    // Refuse positional guesses. A missing Flow output must never shift the story.
    // 'sıra' is not a guess: it counts only this run's cards against its own send order (above).
    if(!/^(ağ-eşlemesi|metin\(prompt#|damga\(prompt#|sıra\(prompt#|tekrar-deneme)/.test(source))throw new Error('Görsel-sahne bağı kesin doğrulanamadı. İndirilen dosyayı sahneden seçin.');
    const u=new URL(url);if(u.protocol!=='https:'||!AF_STORY_IMAGE_HOST.test(u.hostname))throw new Error('Görsel kaynağı desteklenmiyor. Dosyayı sahneden seçin.');
    const blob=await afNarrationImage(url);if(blob.size>25*1048576)throw new Error('Görsel biçimi veya boyutu desteklenmiyor.');
    result.imageKey=`flow:${run.id}:${sceneId}:${result.generation}`;await afStoryPut('assets',result.imageKey,blob);
  }catch(e){result.error=e.message;}
  try{await afStoryPut('results',`result:${run.id}:${sceneId}`,result);}catch(e){console.warn('Sahne sonucu kaydedilemedi:',e.message);}
}
