// Sesten Videoya sekmesi.
//
// 1.5.0 izin tasarimi: bu ozelligin kullandigi adreslerin cogu artik hic izin istemiyor.
//   - Hugging Face (Whisper agirliklari): CORS acik, sunucu chrome-extension kaynagini
//     yankiliyor, agirlik dosyasi da "*" ile geliyor. Olculdu, host izni gereksiz.
//   - viraldna.io (istem yazimi, transkript, Pro kapisi): rotalar chrome-extension
//     kaynagina CORS basligi gonderiyor. Host izni gereksiz.
//   - Flow medya adresleri: gorsel "credentials:'include'" ile cekiliyor, kimlikli
//     istekte CORS joker karaktere izin vermez, Google da bize ozel baslik gondermez.
//     Bu uc adres gercekten izin istiyor ve manifest'te optional_host_permissions'ta.
//
// Izin, stüdyo "Flow'a gonder" dedigi anda isteniyor (studio/app.mjs
// ensureFlowMediaAccess). Sekme acilisinda ISTEMIYORUZ: ses cozumleme, sahneleme ve
// istem yazimi bu izin olmadan zaten calisiyor, kullaniciyi erkenden kutuyla karsilamak
// gereksiz. Burasi yalniz YEDEK yol: studyo kendi cercevesinden izin isteyemezse
// (kullanici hareketi dogrulanamazsa) paneldeki dugmeyi gosteririz, cunku panel ust
// duzey bir eklenti sayfasi ve orada istek kesin calisir.
(() => {
  const frame  = document.getElementById('narration-frame');
  const bar    = document.getElementById('narration-perm');
  const btn    = document.getElementById('narration-perm-btn');
  const denied = document.getElementById('narration-perm-denied');

  // manifest.json > optional_host_permissions ile BIREBIR ayni olmali.
  // development/tests/permissions.test.mjs bunu her koşuda karsilastirir.
  const ORIGINS = [
    'https://flow-content.google/*',
    'https://*.googleusercontent.com/*',
    'https://storage.googleapis.com/*',
  ];

  function mount() {
    if (!frame.getAttribute('src')) frame.src = chrome.runtime.getURL('studio/index.html?embedded=1');
  }

  btn.addEventListener('click', async () => {
    denied.hidden = true;
    btn.disabled = true;
    let ok = false;
    try { ok = await chrome.permissions.request({ origins: ORIGINS }); }
    catch (_) { ok = false; }
    btn.disabled = false;
    if (ok) bar.hidden = true; else denied.hidden = false;
  });

  // Studyo kendi cercevesinden isteyemediyse buraya haber verir.
  window.addEventListener('message', e => {
    if (e.origin !== location.origin) return;          // yalniz kendi sayfalarimiz
    if (e.data && e.data.af === 'narration-permission') { denied.hidden = true; bar.hidden = false; }
  });

  window.addEventListener('af-tab-change', e => { if (e.detail === 'narration') mount(); });
  if (document.body.classList.contains('narration-active')) mount();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.sb_session && typeof refreshAuth === 'function') refreshAuth();
  });
})();
