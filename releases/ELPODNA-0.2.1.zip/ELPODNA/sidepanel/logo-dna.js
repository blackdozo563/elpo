// Basliktaki "Auto Flow" yazisinin arkasinda donen minyatur DNA sarmali.
//
// Sitedeki src/components/DnaHelix.tsx ile ayni geometri ve ayni iki-bant fikri,
// ama YATAY (baslik serit gibi) ve cok kucuk. Sadece suslu: aria-hidden, tiklanmaz,
// hicbir veriye dokunmaz.
//
// Performans, uzun bir Flow kosusu dusunulerek:
//   - tuval ~104x26 CSS px, DPR en fazla 2 -> en kotu 208x52 piksel
//   - ~24 fps, yaklasik 26 dugum; bir karede yapilan is birkac yuz cizim komutu
//   - sekme gorunmez olunca dongu TAMAMEN durur (visibilitychange)
//   - prefers-reduced-motion acikken hic baslamaz, tuval bos kalir
(() => {
  const canvas = document.getElementById('logo-dna');
  if (!canvas || !canvas.getContext) return;

  const azHareket = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (azHareket) return;

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  let w = 0, h = 0;

  function olcule() {
    const r = canvas.getBoundingClientRect();
    w = r.width; h = r.height;
    if (!w || !h) return false;
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return true;
  }

  // Panelin paleti: menekse ve lime. Sitedeki gibi iki bant AYRI renk tasir,
  // boylece kucucuk boyutta bile "DNA" okunur.
  const bantA = [[182, 160, 255], [232, 121, 249]];   // menekse -> magenta
  const bantB = [[143, 120, 255], [209, 237, 170]];   // derin menekse -> lime
  const karis = (pal, t) => {
    const f = t < 0 ? 0 : t > 1 ? 1 : t;
    const a = pal[0], b = pal[1];
    return Math.round(a[0] + (b[0] - a[0]) * f) + ',' +
           Math.round(a[1] + (b[1] - a[1]) * f) + ',' +
           Math.round(a[2] + (b[2] - a[2]) * f);
  };

  const ARALIK = 7;      // baz ciftleri arasi px (yatay)
  const BURGU  = 0.085;  // px basina radyan; bir tam tur ~74px
  const DONUS  = 0.75;   // radyan/sn

  // Uclarda yumusak sonme: sarmal aniden kesilmesin.
  const sonum = (f) => {
    const e = Math.min(f, 1 - f) / 0.18;
    return e >= 1 ? 1 : e * e * (3 - 2 * e);
  };

  let raf = 0, son = 0, basla = 0, calisiyor = false;

  function kare(now) {
    if (!calisiyor) return;
    raf = requestAnimationFrame(kare);
    if (now - son < 41) return;          // ~24 fps
    son = now;
    ciz((now - basla) / 1000);
  }

  function ciz(t) {
    if (!w || !h) { if (!olcule()) return; }
    ctx.clearRect(0, 0, w, h);

    const cy = h / 2;
    const genlik = Math.min(h * 0.34, 9);
    const donus = t * DONUS;
    const xSol = 1, xSag = w - 1;
    const adet = Math.max(4, Math.floor((xSag - xSol) / ARALIK));

    const A = [], B = [];
    for (let i = 0; i <= adet; i++) {
      const x = xSol + i * ((xSag - xSol) / adet);
      const f = i / adet;
      const a = genlik * sonum(f);
      const faz = x * BURGU + donus;
      const s = Math.sin(faz), z = Math.cos(faz);
      A.push({ x: x, y: cy + s * a, z: z, t: f });
      B.push({ x: x, y: cy - s * a, z: -z, t: f });
    }

    // Baz cifti basamaklari: iki yarim, ortada bulusur (klasik DNA ipucu)
    for (let i = 0; i <= adet; i += 2) {
      const a = A[i], b = B[i];
      const ayrik = Math.abs(a.y - b.y) / (2 * genlik);
      if (ayrik < 0.18) continue;
      const alfa = (0.05 + ayrik * 0.26) * sonum(a.t);
      const my = (a.y + b.y) / 2;
      ctx.lineWidth = 1;
      ctx.strokeStyle = 'rgba(' + karis(bantA, a.t) + ',' + alfa.toFixed(3) + ')';
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(a.x, my); ctx.stroke();
      ctx.strokeStyle = 'rgba(' + karis(bantB, b.t) + ',' + alfa.toFixed(3) + ')';
      ctx.beginPath(); ctx.moveTo(b.x, my); ctx.lineTo(b.x, b.y); ctx.stroke();
    }

    // Bantlar: derinlige gore kalinlik ve saydamlik, arka taraf geri cekilir
    const bantlar = [A, B];
    for (let k = 0; k < 2; k++) {
      const bant = bantlar[k], pal = k === 0 ? bantA : bantB;
      for (let i = 1; i <= adet; i++) {
        const p = bant[i - 1], q = bant[i];
        const az = (p.z + q.z + 2) / 4;
        const alfa = (0.10 + az * 0.42) * sonum(q.t);
        ctx.strokeStyle = 'rgba(' + karis(pal, q.t) + ',' + alfa.toFixed(3) + ')';
        ctx.lineWidth = 0.9 + az * 1.3;
        ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke();
      }
    }

    // Dugumler arkadan one; ondekiler hafif hale alir (shadowBlur pahali, kullanmiyoruz)
    const dugumler = A.map((n) => ({ n: n, s: 0 })).concat(B.map((n) => ({ n: n, s: 1 })));
    dugumler.sort((x, y) => x.n.z - y.n.z);
    for (const d of dugumler) {
      const n = d.n;
      const az = (n.z + 1) / 2;
      const tp = sonum(n.t);
      if (tp <= 0.01) continue;
      const rgb = karis(d.s === 0 ? bantA : bantB, n.t);
      const r = (0.8 + az * 1.5) * (0.6 + tp * 0.4);
      if (az > 0.72) {
        ctx.fillStyle = 'rgba(' + rgb + ',' + (0.12 * tp).toFixed(3) + ')';
        ctx.beginPath(); ctx.arc(n.x, n.y, r * 2.4, 0, Math.PI * 2); ctx.fill();
      }
      ctx.fillStyle = 'rgba(' + rgb + ',' + ((0.22 + az * 0.6) * tp).toFixed(3) + ')';
      ctx.beginPath(); ctx.arc(n.x, n.y, r, 0, Math.PI * 2); ctx.fill();
    }
  }

  function baslat() {
    if (calisiyor) return;
    if (!olcule()) return;
    calisiyor = true;
    son = 0;
    raf = requestAnimationFrame(kare);
  }
  function durdur() {
    calisiyor = false;
    if (raf) cancelAnimationFrame(raf);
    raf = 0;
  }

  // Sekme gorunmezken hic cizme: panel arkada kalirsa bedeli sifir olur.
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') durdur(); else baslat();
  });

  if (window.ResizeObserver) {
    const ro = new ResizeObserver(() => { if (olcule() && !calisiyor) ciz(0); });
    ro.observe(canvas);
  }

  basla = performance.now();

  // Tuval HER DURUMDA olculur ve BIR kare cizilir. Sebep: gizli belgede tarayici
  // zaten requestAnimationFrame'i calistirmaz; ustune bir de biz baslatmazsak sarmal
  // hic gorunmez. Tek duran kare bedava, boylece panel gorunur olur olmaz orada olur.
  olcule();
  ciz(0);
  if (document.visibilityState !== 'hidden') baslat();
})();
