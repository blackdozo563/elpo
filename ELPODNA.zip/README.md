# ELPODNA — atelier local de création

Version 0.1.0, candidate de développement. Interface et traitements locaux testés ; parité complète avec ViralDNA Auto Flow **non acquise**. Le chargement MV3 réel et les parcours authentifiés Flow/Gemini ne sont pas validés dans ce cloud. Voir `docs/VALIDATION.md` et la matrice unique `docs/MATRICE_PARITE.csv` avant tout usage important.

## Installation sans compilation

1. Extraire `ELPODNA.zip`.
2. Ouvrir `chrome://extensions` dans Chrome, activer le mode développeur.
3. Choisir **Charger l’extension non empaquetée** et sélectionner le dossier **extension/** contenant `manifest.json`.
4. Épingler ELPODNA puis cliquer sur son icône pour ouvrir le panneau. Le bouton d’agrandissement ouvre le studio dans un onglet.

Chrome 120 minimum déclaré ; Chromium 151.0.7922.173 utilisé pour les tests locaux. La compatibilité avec toutes les versions intermédiaires n’est pas validée. Aucun serveur, abonnement ELPODNA ou clé API requis. Une politique d’entreprise interdisant les extensions peut bloquer l’installation ; il faut un navigateur qui autorise ce chargement. Aucune politique ne doit être contournée.

## Flow : les images sont générées dans votre compte existant

Ouvrir un **projet** Google Flow dans le compte habituel, puis utiliser **Actualiser** dans ELPODNA. Choisir le projet. Préparer les prompts (une ligne par prompt, ou import TXT), les références dans Médias et les réglages de téléchargement/intervalle. Les `[tags]` associent des références par nom ; sans tag, les références cochées sont partagées. En photo-vers-vidéo, sélectionner les images et leur tri ; choisir un prompt partagé ou un prompt par image/paires. Les emplacements début/fin sont vérifiés avant envoi.

Lancer le lot après confirmation. Réserver l’onglet Flow à ELPODNA pendant la production : les résultats sont rapprochés par différence de galerie dans le projet lié, pas par une API officielle propriétaire. Pause/reprise/arrêt et envois incertains se gèrent dans File. Un envoi incertain nécessite une décision explicite après vérification dans Flow. Les médias visibles détectés ne garantissent pas l’accès au fichier haute résolution. Les sélecteurs, les pièces jointes et les variantes actuelles de Flow restent à vérifier sur le site réel ; une cible absente ou ambiguë interrompt l’action.

**Différences non acceptées comme parité complète :** cadence séquentielle après réception du résultat (au lieu d’une production potentiellement pipelinée) ; contrôle automatique complet de tous les modèles/aspects/durées/résolutions non implémenté ; options supplémentaires réglables directement dans Flow ; menus d’upscale 2K/4K/1080p non intégrés. Téléchargement du média source détecté, convention de noms, dossier daté, numéro initial, parallélisme limité à deux, tentatives de transfert limitées à trois et annulation sont implémentés. Ils restent à vérifier avec de vrais téléchargements Google dans Chrome. Les limites/coûts propres au compte Flow restent ceux de Google, sans modification par ELPODNA.

## Studio : narration → Gemini → Flow → film

1. **Audio** : importer un fichier (15 min / 250 Mo maximum), puis transcrire localement ou importer ses sous-titres SRT/VTT. Whisper Tiny/Base télécharge ses poids depuis Hugging Face au premier usage ; l’audio n’est pas envoyé. L’inférence réelle reste non testée dans ce cloud à cause du proxy réseau ; SRT/VTT a été vérifié.
2. **Direction** : choisir style/aspect, rythme et références décrites. Découper les scènes. Les cartes de styles sont des illustrations abstraites originales, pas des résultats générés.
3. **Scènes** : utiliser **Concevoir avec Gemini**. La demande est copiée et peut être préparée dans un éditeur Gemini déjà ouvert si son DOM est reconnu. **L’utilisateur confirme lui-même l’envoi sur le site Gemini.** Copier ensuite le JSON complet dans ELPODNA et le vérifier/appliquer. Les IDs, le nombre de scènes et les références sont validés intégralement avant remplacement ; les corrections de narration sont proposées séparément. Réécrire en relançant cette même action. Aucune clé API, abonnement ViralDNA ou suppression de contrôle d’accès.
4. **Production** : générer les images manquantes dans le projet **Flow sélectionné**, ou associer des images locales. L’IA Gemini conçoit les prompts : elle ne remplace pas Google Flow pour générer les images. Le téléchargement des images vers le studio demande les permissions médias Google ; cette récupération automatique reste à vérifier sur Flow réel.
5. **Film** : aperçu, plans fixes ou zoom lent, export MP4 720p/1080p, SRT et prompts. H.264 est requis ; un encodeur AAC WASM libre embarqué remplace l’AAC natif manquant. Un film synthétique avec pistes H.264/AAC a été produit et inspecté. Les durées longues, 1080p, toutes les sources audio et les ratios restent à tester séparément.

Les projets/assets restent dans IndexedDB. Une sauvegarde `.elpodna` contient les médias nécessaires ; une restauration crée un nouveau projet. Les sauvegardes `.afstory` de la référence ne sont pas importées. La réinitialisation conserve l’ancien projet et peut être annulée dans la même session. Un deuxième studio est en lecture seule. Après suspension du worker, les envois incertains ne sont pas renvoyés automatiquement.

## Données et permissions

- `storage`, `unlimitedStorage` : état local et médias ; `sidePanel` : panneau ; `scripting`, `activeTab` et domaines Flow : adaptation du site.
- `debugger` : clic de génération fiable via API Chrome ; peut produire un avertissement Chrome, jamais utilisé pour contourner un contrôle d’accès. Ne pas garder les DevTools attachés au même onglet pendant le lot.
- `downloads`, `notifications`, `alarms`, `power` : fichiers, fin de lot, reprise de planification, maintien d’activité pendant un lot.
- Permissions hôtes optionnelles : Gemini (préparer l’éditeur après accord), médias Google (récupération d’images), Hugging Face (poids Whisper). Aucun accès global à tous les sites.

Gemini reçoit le texte de narration, des descriptions de références et les choix de style après confirmation. Flow reçoit prompts et images de référence quand vous lancez le lot. Les fournisseurs traitent alors ces données selon leurs propres conditions. Pas de télémétrie ELPODNA, pas de service ViralDNA/Stripe, pas de secret embarqué. Journal exportable localement ; sauvegardes peuvent contenir vos propres médias et textes.

## Maintenance et vérifications

Le code principal lisible est dans `extension/`. `sources/` contient les workers avant compilation, la configuration de build et le verrouillage des dépendances ; `tests/` contient les tests. Il n’est pas nécessaire de compiler pour installer l’archive.

Avec Node 24 et npm 11 :

```sh
cd sources
npm ci --ignore-scripts --no-audit --no-fund
npm run build
npm test
```

Les scripts d’installation natifs ONNX/CUDA sont volontairement ignorés : le build utilise uniquement le runtime navigateur. L’intégrité des archives npm reste contrôlée par le lockfile ; aucune vérification TLS/checksum désactivée. Le worker AAC de la dépendance est extrait statiquement au build et chargé comme fichier local, sans `eval` ni blob worker. Son source modifié est `sources/vendor-aac.mjs` et sa licence MPL est incluse.

Depuis la racine, avec un Chromium autorisé sur la machine :

```sh
node tests/browser-local.mjs
node tests/flow-fixture.mjs
node tests/worker-fixture.mjs
```

Ces tests lancent des services locaux temporaires et les ferment ; ils ne requièrent aucun serveur pour l’extension. `ELPODNA_CHROME` peut désigner l’exécutable de navigateur autorisé. `tests/browser.mjs` vise le vrai chargement MV3 sur une fixture, mais est bloqué dans le Chromium cloud actuel par sa politique d’installation. Les mocks/fixtures ne prouvent pas la compatibilité du site réel. Les résultats sont écrits dans `.test-output/` ; voir les copies de preuves et le rapport dans `docs/`.

## Livraison et limites

Cette archive est une candidate testable, **pas une extension déclarée complète, de parité totale ou « zéro bug »**. Les fonctions locales sont réellement implémentées ; les éléments non exécutés et les fonctions avancées manquantes sont identifiés dans la matrice. Pour achever la mission, il faut un Chrome permettant le chargement, vérifier les parcours dans le compte Flow/Gemini existant, valider Whisper et compléter les réglages/qualités Flow avancés. Pas de publication Chrome Web Store effectuée.
