# ELPODNA 0.2

Interface et moteur Flow repris de l’archive ViralDNA Auto Flow fournie, avec vos couleurs menthe/or et votre identité ELPODNA. Six onglets : texte vers scène, photo vers vidéo, audio vers vidéo, file, bibliothèque, journal. Voir `docs/VALIDATION.md` pour les essais et différences exactes.

## Mettre à jour votre extension existante

1. Sauvegarder vos projets si possible. Garder une copie du dossier existant.
2. Extraire l’archive installable. Copier le contenu du dossier `ELPODNA/` dans le dossier déjà chargé dans Chrome, en remplaçant les fichiers ; conserver le même chemin et la même extension.
3. Dans `chrome://extensions`, cliquer sur **Recharger** pour ELPODNA, puis actualiser l’onglet du projet Flow.
4. Ouvrir le panneau. Choisir les réglages et utiliser **Vérifier ces réglages dans Flow** : aucun prompt envoyé par ce diagnostic. Le lancement utilise ensuite votre compte et ses crédits Flow.

La migration conserve les anciennes données 0.1. Charger le même produit depuis un autre dossier peut créer une autre identité Chrome et un autre stockage ; les backups `.elpodna` et `.afstory` restent importables. L’extension n’a pas de serveur local à démarrer.

## Studio

Audio local ou SRT/VTT, six styles et style personnalisé, scènes, références, Gemini web avec confirmation et réponse JSON, production dans votre Flow, aperçu, MP4, SRT, prompts, projets et sauvegardes. Les fichiers images en lot sont associés par numéro de scène en début du nom (`0001_foret.png`, `0002_ville.png`, etc.). Whisper nécessite ses modèles au premier usage.

## Développement

Node 24 / npm 11, Chromium autorisé pour les essais locaux :

```sh
cd sources
npm ci --ignore-scripts --no-audit --no-fund --cache /workspace/.npm-cache
npm run build
npm test
cd ..
node tests/parity-browser.mjs /workspace/elpo-runtime
```

L’extension installable est précompilée. Les scripts natifs ONNX/CUDA ne sont pas nécessaires à la cible navigateur. Les licences des dépendances embarquées sont dans `extension/licenses` et `extension/studio/vendor/licenses`.

Les tests actuels passent, mais le Chrome cloud interdit le chargement natif. Le compte Flow réel, les uploads/téléchargements/upscales Google, Whisper réel et les exports longs ne sont pas déclarés vérifiés. Gemini conserve le parcours web de la précédente version ; le backend commercial et la correction automatique de transcription de la référence ne sont pas reproduits. Aucun accès ni paiement tiers n’est simulé.
