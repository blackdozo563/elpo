# Décisions et suivi

- Demande : ELPODNA en français, interface soignée, parité de référence et aucun backend payant obligatoire.
- Référence : archive ViralDNA Auto Flow 1.5.6 ; réimplémentation indépendante.
- Réponse utilisateur : possède Flow et Gemini. Précision explicite : les images doivent être générées dans son compte Flow existant.
- Réponse utilisateur : Gemini sur le site uniquement, avec confirmation utilisateur. Pas de clé API, de service ViralDNA ni de demande de secret. L’envoi et la récupération de réponse nécessitent des confirmations/copier-coller ; différence de parcours acceptée par ce choix.
- Attente renforcée : UX/UI et ergonomie de niveau agence, qualité fonctionnelle élevée. La validation doit rester factuelle ; aucune garantie « zéro bug » ne peut remplacer les tests.
- Statut cloud : politique Chromium `ExtensionInstallBlocklist: ["*"]` empêchant le chargement complet ; aucune politique système modifiée.
- Sources officielles : API sidePanel/debugger Chromium téléchargées et référencées dans evidence. Documentation web Chrome/Google Flow inaccessible par le proxy ; prix et quotas non confirmés.
- Whisper : modèle local distant Hugging Face. Requête README officielle refusée par le proxy CONNECT 403 ; inférence réelle non validée dans cet environnement.
- AAC : dépendance libre @mediabunny/aac-encoder 1.61.3 pour suppléer l’encodeur natif absent. Worker extrait statiquement au build, pas d’exécution de chaînes ou de blob worker. Film H.264/AAC 720p de deux secondes produit et inspecté avec ffprobe.
- Le socle et le manifest disposent de 28 tests unitaires passés. Les suites accessibles comptent 13 scénarios navigateur locaux, 7 scénarios DOM Flow synthétiques et 7 scénarios d’orchestration sur API simulées. Chaque résultat navigateur sera consigné dans VALIDATION.md et evidence.

## Écarts nécessitant encore une résolution

La cadence séquentielle proposée, les réglages avancés Flow non exposés, les résolutions améliorées et la corrélation complète des médias tardifs de la référence ne sont pas considérées comme une parité acquise. Le parallélisme de transferts sources limité à deux, les trois tentatives bornées et l’arrêt explicite sont implémentés et testés sur API simulées. Ils doivent être mis en œuvre et validés, ou faire l’objet d’un accord explicite. Aucune absence de réponse n’autorise leur suppression du périmètre.
