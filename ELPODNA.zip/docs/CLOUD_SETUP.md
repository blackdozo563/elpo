# Configuration cloud enregistrée

Les champs `install_script` et `start_skill` ont été enregistrés dans le brouillon. Installation : npm ci avec lockfile/intégrité, cache workspace et cible web sans scripts natifs ONNX/CUDA inutiles ; build et unitaires. Démarrage : checkout existant `/workspace/elpo`, pas de worktree supplémentaire, pas de serveur applicatif requis ; commandes de tests locaux et chargement Chrome explicitement documentés avec leurs limites.

Les domaines personnalisés suivants ont été ajoutés pour la documentation et les modèles : developer.chrome.com, support.google.com, huggingface.co, cdn-lfs.huggingface.co, cdn-lfs-us-1.hf.co, cas-bridge.xethub.hf.co. Les presets réseau existants ont été conservés. Aucun secret/API key demandé ou enregistré.

La sauvegarde du brouillon n’exécute pas les scripts et ne publie pas l’environnement. Le réseau du runtime existant n’a pas été déclaré mis à jour. Pour activer ces changements, revoir/enregistrer les paramètres puis publier l’environnement. La politique gérée du Chromium cloud bloquant les nouvelles extensions reste un obstacle distinct et n’a pas été modifiée. Une nouvelle tâche restaurée n’a pas été testée.
