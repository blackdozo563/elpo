# Validation — ELPODNA 0.1.0

La candidate n’est pas déclarée de parité complète ni validée sur les sites réels. Les fonctionnalités et états de chaque fonction sont dans la matrice unique `MATRICE_PARITE.csv`. Les résultats ci-dessous distinguent exécution locale, DOM synthétique, API simulée et intégration réelle.

Environnement : Node 24.19.0, npm 11.9.0, Python 3.12.14, Chromium 151.0.7922.173, Playwright 1.62.1. Date : 6 octobre 2026. Aucun compte Flow/Gemini réel utilisé, aucun média Google réellement généré, aucun API key reçu, aucune dépense déclenchée.

## Vérifications finales de la copie de développement

| Scénario | Attendu | Obtenu et preuve | Statut |
|---|---|---|---|
| Installation verrouillée et build navigateur | Build reproductible sans native ONNX/CUDA | `npm ci --ignore-scripts`, build esbuild et extraction statique du worker AAC terminés ; lockfile conservé | RÉUSSI |
| Tests de logique et contenu du manifest | Scénarios réellement exécutés, ressources présentes | 28 tests, 28 passés, 0 échoué/skippé ; `evidence/unit-tests.tap` | RÉUSSI |
| Interface locale étroite et large | Rendu sans débordement, navigation clavier | Captures panel/studio, focus vérifié ; `evidence/browser-results.json` | RÉUSSI |
| TXT et bibliothèque | Import, sélection et persistance après reload | Exécuté dans le navigateur local | RÉUSSI |
| WAV réel et SRT | Audio décodé, texte horodaté importé | WAV synthétique de deux secondes ; SRT fin d’audio importé après correction d’une frontière flottante | RÉUSSI |
| Scènes et images | Édition, association et aperçu | Scène créée, prompt édité, image locale associée | RÉUSSI |
| Réponse Gemini invalide | Refus atomique, prompt existant conservé | Vérifié en navigateur et unitaires, aucun appel Gemini réel | RÉUSSI |
| Export MP4 réel sous CSP MV3 | Vidéo et audio encodés localement | H.264 1280×720, AAC mono 44 100 Hz, durée 2,043356 s ; `evidence/ffprobe-mp4.json` et `video-metadata.json` | RÉUSSI |
| Backup/restauration/rechargement | Médias, scènes et paramètres conservés | Sauvegarde `.elpodna` comprenant trois assets ; restauration dans un nouveau projet et reload exécutés | RÉUSSI |
| Studio simultané | Deuxième éditeur en lecture seule | Verrou Web Locks et contrôles de modification désactivés | RÉUSSI |
| Erreurs JavaScript des parcours locaux | Aucune erreur non gérée | 13 scénarios locaux passés, aucune pageerror sur ces parcours | RÉUSSI |
| Adaptateur Flow sur DOM synthétique | Inspecter/stager sans envoi prématuré, pièces jointes et blocage des ambiguïtés | 7 scénarios : contenu texte littéral, résultat visible, pièce jointe, ancienne référence non retirable, éditeurs ambigus, origine refusée, hors projet ; `evidence/flow-fixture-results.json` | RÉUSSI |
| Orchestrateur sur API Chrome simulées | Lot, reçus, result correlation, non duplication, projet lié et redémarrage | 7 scénarios, IndexedDB réel ; `evidence/worker-fixture-results.json` | RÉUSSI |
| Chargement natif de l’extension dans le Chrome cloud | Worker MV3 et panneau réellement chargés | Interdit par la politique gérée `ExtensionInstallBlocklist: ["*"]` ; aucun worker chargé ; test natif arrêté | ÉCHOUÉ |
| Ouverture native du panneau, debugger, alarmes et téléchargements Google | APIs Chrome et Flow authentifiés fonctionnent ensemble | Aucun compte/site réel testé, politique bloque le chargement | NON EXÉCUTÉ |
| Gemini sur compte réel | Demande préparée, envoi confirmé et réponse structurée exploitable | Requête/validation testées localement ; éditeur Gemini proposé, DOM réel non vérifié | NON EXÉCUTÉ |
| Whisper sur audio parlé | Inférence exacte et timestamps plausibles | Poids et README Hugging Face refusés par proxy CONNECT HTTP 403 ; licence/version poids non confirmées | NON EXÉCUTÉ |
| Documentation web actuelle et coûts Flow | Contenus officiels accessibles | developer.chrome.com/support.google.com refusés par proxy HTTP 403 ; sources officielles Chromium sidePanel/debugger obtenues sur GitHub | ÉCHOUÉ pour les pages ; RÉUSSI pour les sources API |
| Réglages Flow complets et qualités 2K/4K/1080p | Parité des commandes et downloads d’upscale | Contrôles avancés non implémentés/menus non vérifiés | NON EXÉCUTÉ |
| Ratio vertical/carré, 1080p, vidéos longues et autres codecs audio | Exports décodables et synchronisés | Seul cas 720p paysage de deux secondes réellement exporté | NON EXÉCUTÉ |
| ZIP et copie extraite | Intégrité/extraction et tests accessibles rejoués | 55 vérifications accessibles passées sur copies extraites, ressources applicatives comparées, ZIP intègre ; `evidence/release-verification.json` | RÉUSSI pour ces vérifications accessibles |

Les 55 vérifications passant dans ces suites ne constituent pas 54 tests réussis sur les services réels. Les tests de téléchargements sont unitaires ou sur API simulées ; `downloads.download()` retournant un ID ne vaut pas transfert réussi, la logique attend l’état Chrome `complete`. La piste audio du film a été vérifiée par ffprobe, pas déduite du seul lecteur vidéo.

## Corrections et essais antérieurs

- La première sonde navigateur utilisant une page externe a échoué sur une navigation `chrome-error` ; elle a été remplacée par une sonde de capacités locale.
- Installation npm initiale : cache utilisateur inaccessible, puis script natif ONNX tentant un téléchargement NuGet inutile au workflow navigateur. Cache placé dans `/workspace/.npm-cache`, installation `--ignore-scripts` prise en charge pour la cible web uniquement. Aucune vérification TLS/intégrité désactivée.
- AAC natif absent : sonde `isConfigSupported` retourne false. Résolu pour le parcours testé par encodeur libre statique WASM ; vrai MP4 produit ensuite.
- Première exécution SRT navigateur : échec à cause de la durée audio décodée inférieure de quelques microsecondes à deux secondes. Correction bornée à 1 ms, test de non-régression et parcours rejoués avec succès.
- Premier test backup cherchait un contrôle situé dans une section repliée ; scénario corrigé pour ouvrir la section, puis sauvegarde et restauration réellement exécutées.
- Première assertion d’ambiguïté DOM plaçait l’éditeur supplémentaire hors du composant Flow ciblé. Fixture corrigée pour deux éditeurs dans le composant ; refus observé.
- Premier test de worker utilisait un prédicat asynchrone traité comme immédiatement truthy par le polling de test ; remplacé par interrogation explicite jusqu’à un état réel, résultats vérifiés ensuite.

Les échecs antérieurs ne sont pas comptés comme des réussites. Leurs étapes corrigées figurent dans les dernières preuves ; le blocage de politique Chrome et les vérifications réelles non exécutées restent ouverts.

## Scénarios requis pour achever la mission

1. Sur un Chrome autorisant l’installation, charger le dossier `extension/`, ouvrir le panneau et contrôler les erreurs de worker/permissions. Vérifier fermeture/reprise du worker natif, pause/arrêt pendant un envoi et changements de projet.
2. Sur le compte Flow existant : confirmer mode, modèles, aspect/durée/résolution, références partagées et par prompt, début/fin, résultats multiples, pages dynamiques et qualité des médias. Compléter les contrôles avancés et downloads de résolution améliorée avant de déclarer la parité.
3. Sur Gemini web : confirmer le geste utilisateur, qualité/cohérence des descriptions, correction conservant le sens, JSON incomplet, réseau indisponible et sélecteur absent ; aucune transmission automatique sans confirmation.
4. Autoriser les domaines de modèles dans les paramètres cloud puis tester Whisper Tiny/Base sur paroles françaises connues, silence, langues, longue durée, annulation et cache. Vérifier licence/version des poids avant redistribution éventuelle.
5. Exporter des films réels longs en 720p/1080p et plusieurs ratios ; décoder vidéo et audio et vérifier leur synchronisation. Tester permissions refusées et stockage plein.

La cadence séquentielle, le mapping par tags sans dialogue intégral et les commandes avancées absentes sont des écarts ouverts ; aucune réduction matérielle de périmètre n’a été présumée acceptée. Le choix Gemini web avec confirmation a été expressément accepté. Les tests locaux ne permettent pas de garantir « zéro bug ».

- Revue finale : une inspection refusée pouvait laisser l’état de lancement actif. Le lancement restaure maintenant la file et l’état précédents si l’inspection échoue ; un septième scénario d’orchestration vérifie ce cas.
