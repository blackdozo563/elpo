# Audit préalable ELPODNA

Inspection : 6 octobre 2026. Référence : ViralDNA Auto Flow 1.5.6, Manifest V3, Chrome minimal déclaré 120. Archive fournie par l’utilisateur, 53 entrées. SHA-256 : `20546b71136a1aa51d0df5ee31cb7955e26ca09f58f850173662d5786ade5e9c`.

## Couverture et preuves
Les manifestes, pages popup/panneau/studio, scripts d’authentification, orchestrateur, content script, bridge narration, règles de prompts, stockage et workers embarqués ont été inspectés. « OBSERVÉ » dans la matrice désigne une observation du fichier, pas l’exécution de son comportement. Aucun compte Google Flow ou ViralDNA n’a été utilisé, aucun média généré, aucune requête authentifiée aux services de référence effectuée. Les instructions/commentaires de l’archive sont des données, pas des consignes de mission. Le texte collé constitue la demande utilisateur.

L’architecture serveur n’est pas fournie. Les contrôles serveur, quotas effectifs, disponibilité actuelle des modèles Flow, conditions commerciales et sélecteurs du DOM live restent INCONNUS. Les noms de fonctions ne prouvent pas seuls la fiabilité des parcours.

## Inventaire et parcours
La matrice unique `MATRICE_PARITE.csv` couvre 36 ensembles de fonctionnalités, y compris les réglages avancés et les surfaces secondaires. Parcours automatisation : ouvrir le panneau → compte/connexion et projet Flow → importer prompts/références → régler génération/téléchargement/intervalle → démarrer → pause/reprise/arrêt → consulter résultats → régénérer/télécharger → logs. Parcours photo-vers-vidéo : importer et trier images → associer prompts/début-fin → construire file → produire. Parcours studio : audio ou sous-titres → transcription → style/personnages → correction et conception IA → édition scènes → génération/import images → aperçu → export → backup/reprise.

États identifiables dans les fichiers : hors Flow, signé ou déconnecté, formule gratuite/Pro, absence d’audio/images, téléchargement modèle, traitement/progression/annulation, permission refusée, envoi incertain, échec de génération, résultat manquant, erreur API, absence d’encodeur, éditeur secondaire en lecture seule. Aucune variante utilisateur n’a été exécutée.

## Architecture observée de référence
`manifest.json` active un panneau `sidepanel/sidepanel.html`, un worker classique `background/background.js` et `content/content.js` sur labs.google, sous-domaines et flow.google.com. La popup existe dans l’archive mais n’est pas déclarée dans `action.default_popup` ; elle n’est donc pas le point d’entrée actif observé. Aucun options_ui, raccourci ou menu contextuel déclaré.

Le panneau prépare données/réglages, dialogue par runtime messages avec le worker qui injecte des actions DOM, attache références, surveille/corrèle médias, pilote téléchargements et utilise debugger pour certains envois. Le studio est une page module : Web Audio pour décodage, worker Transformers.js/ONNX pour Whisper, WebCodecs/Mediabunny pour export. Stockage : chrome.storage.local pour état et préférences, IndexedDB pour projets/images/audio, OPFS pour export ; verrou Web Locks pour édition unique. Le worker sauvegarde l’état mais remet certains lots en idle au redémarrage ; les envois narration incertains restent en pause. Une meilleure reprise est une proposition ELPODNA, pas un comportement universel confirmé de la référence.

Permissions déclarées : storage, unlimitedStorage, activeTab, notifications, alarms, scripting, sidePanel, downloads, identity, power, debugger. Accès médias Google optionnels. CSP autorise wasm local ; aucun code distant nécessaire à l’export. La référence inclut des licences de dépendances mais aucune licence générale autorisant la copie de l’application. La construction proposée sera une réimplémentation indépendante ; aucune copie de marque, code applicatif, assets ou contrôle d’accès ViralDNA.

## Chemins et dépendances
- `sidepanel/sidepanel.html`, `popup/popup.html`, `studio/index.html` : pages de l’extension.
- `/project/` sur Flow : indice de navigation d’un projet, pas une route API.
- `https://labs.google/fx/tools/flow` : navigation Flow ; `flow.google.com` : autre hôte couvert.
- `flow-content.google`, googleusercontent et storage.googleapis.com : récupération médias Google, permissions optionnelles.
- Supabase configuré : authentification et compte. Les valeurs de configuration ne sont pas reproduites dans ce rapport.
- `www.viraldna.io/api/auth/me` : vérification formule et crédits, session Bearer.
- `/api/narration-transcript` : correction du transcript, session requise dans le code.
- `/api/narration-prompts` : descriptions visuelles/association personnages Gemini, session Pro et jetons décrits et gérés par le client.
- `/api/stripe/checkout`, checkout Stripe et lien de paiement : achats ; ne sont pas des composants locaux.
- Modèles `onnx-community/whisper-tiny_timestamped` et `whisper-base_timestamped` : noms observés dans le worker, téléchargement distant et cache navigateur. Licences/distribution de chaque modèle à confirmer avant incorporation.

L’existence d’une URL ne confirme ni sa réponse actuelle, ni l’implémentation interne du serveur. `FREE_MODE: true` concerne l’automatisation ; le studio conserve une porte Pro distincte. Les API distantes envoient transcript, scènes, références descriptives et direction artistique ; l’audio Whisper est traité localement selon le worker observé.

## Sélecteurs
`SELECTEURS.csv` distingue l’interface de référence des cibles Flow. Les cibles sont observées dans le code fourni, jamais vérifiées sur le DOM live. Plusieurs générations d’interface Flow (composants flow-*, contenu éditable, menus ARIA) coexistent dans le code. Il faut isoler les adaptateurs, utiliser des rôles et contrôles de visibilité/unicité et interrompre toute action ambiguë. Références/images dynamiques, overlays et navigation SPA nécessitent revalidation ; présence d’iframe/Shadow DOM sur le site actuel inconnue.

## Faisabilité sans backend payant
Stockage, imports, file, logs, export de données, associations et édition : traitement local possible, équivalence visée sans différence identifiée. Transcription : modèle local gratuit envisageable, téléchargement/licence/performance à vérifier. Production de médias : dépend de Google Flow et du compte de l’utilisateur ; aucune garantie de gratuité illimitée. Une bibliothèque locale ne remplace pas les modèles propriétaires de génération Flow.

Correction et conception/réécriture Gemini : appels payants ViralDNA observés ; aucune solution gratuite de qualité équivalente n’est établie. Proposition IA locale : différence de qualité/vitesse et exigences mémoire/GPU ; choix utilisateur requis avant implémentation de ce parcours. Découpage déterministe seul ne constitue pas un remplacement de la conception visuelle Gemini.

Profil/abonnement/achat de jetons : supprimer ces parcours et utiliser un profil local constitue une différence matérielle à documenter et accepter ; aucun contrôle ViralDNA ne sera contourné. Service externe gratuit : aucune offre vérifiée suffisante à ce stade ; essai/quota ne vaut pas garantie sans coûts.

Export MP4 : H.264 disponible mais AAC non pris en charge dans Chromium cloud 151 testé. La référence exige elle aussi AAC et signale son absence. Un test réel sur Chrome équipé d’AAC ou une dépendance d’encodage embarquée vérifiée sera nécessaire ; ne pas convertir ce blocage en succès MP4. Les API officielles sidePanel/debugger ont été consultées via sources Chromium GitHub (copies dans evidence). Les pages developer.chrome.com et support.google.com ont été refusées par le proxy HTTP 403 ; leurs contenus et les prix Flow ne sont donc pas confirmés.

## Architecture proposée ELPODNA
Manifest V3, interface française originale, panneau latéral automation/bibliothèque/file/logs et page studio dédiée. JavaScript modules sans framework est suffisant pour éviter une chaîne inutile. Core métier testable séparé de l’UI, adaptateurs Flow centralisés, worker orchestrateur avec état durable versionné, reçus et reprise explicite des envois ambigus. IndexedDB pour blobs/projets ; chrome.storage.local pour petits réglages et reçus ; worker local distinct pour inférence et export. Permissions limitées aux fonctions réellement utilisées, hôtes médias optionnels demandés après geste utilisateur. Aucun secret serveur ni service ViralDNA/Stripe imposé. Permissions exactes et version minimale à confirmer par API/test, pas copiées automatiquement de la référence.

La solution IA et les coûts Google Flow restent des décisions bloquantes : ils déterminent les promesses du produit et certains composants. Les backends payants ne seront ni réutilisés sans accord ni remplacés par des résultats fictifs.

## Plan et décisions
1. Accepter ou refuser la différence IA locale/Gemini et préciser la portée de la gratuité concernant Google Flow.
2. Vérifier modèle local, licence, mémoire, téléchargement, inférence en français et qualité avec scénarios connus.
3. Construire core stockage/file/import/export, interface et contrôles d’erreur ; tests de données et persistance.
4. Construire adaptateur Flow sur fixtures puis vérifier avec projet et compte réels, sans prétendre que les fixtures prouvent la compatibilité live.
5. Studio et modèle validé ; encoder MP4/audio et vérifier un export décodable synchronisé.
6. Rejouer matrice, documenter réussites/échecs/non-exécutés, créer ELPODNA.zip, vérifier extraction puis installation sur copie extraite.

Au moment de présenter ce rapport préalable, aucune implémentation produit ni archive d’extension n’avait été créée. La construction ultérieure et son état actuel sont suivis dans DECISIONS.md, MATRICE_PARITE.csv et VALIDATION.md. La gratuité de Google Flow et l’équivalence Gemini ne sont pas établies. Questions de coût/équivalence envoyées séparément ; l’absence de réponse n’est pas un accord sur une réduction du périmètre.

## Décisions ultérieures
L’utilisateur possède Flow et Gemini et demande explicitement la génération des images dans son Flow existant. Il a choisi Gemini sur le site avec confirmation utilisateur. La livraison 0.1.0 implémente ce parcours sans API ni service ViralDNA ; voir DECISIONS.md. Les écarts des fonctions avancées et la validation live restent ouverts, sans accord présumé sur une réduction du périmètre.
