# Dépendances et notices

Code et identité ELPODNA créés indépendamment. Aucun code applicatif, marque ou image de l’archive ViralDNA n’est distribué. L’archive fournie sert seulement à observer et documenter les comportements.

| Composant | Version | Rôle | Licence/source |
|---|---|---|---|
| Transformers.js | 4.3.0 | Transcription navigateur | Apache-2.0 ; https://github.com/huggingface/transformers.js |
| ONNX Runtime Web | 1.31.0-dev.20260914-8d85527a0 | WASM d’inférence | MIT et notices tierces ; commit 8d85527a010e294a26b274749f74294b2a32cec5, https://github.com/microsoft/onnxruntime |
| Mediabunny | 1.61.3 | Muxage MP4 et encodage média | MPL-2.0 ; https://github.com/Vanilagy/mediabunny |
| AAC encoder Mediabunny | 1.61.3 | AAC-LC local en WASM | MPL-2.0 pour le composant ; libavcodec/FFmpeg sous LGPL-2.1+ ; https://github.com/Vanilagy/mediabunny/tree/main/packages/aac-encoder |
| esbuild / acorn / Playwright | voir package-lock.json | Outils de build/AST/test, non requis à l’installation | Dépendances de développement, source/versions dans le lockfile |

Les notices runtime sont incluses dans `extension/licenses/` et dans les commentaires légaux des bundles. Pour AAC, `sources/vendor-aac.mjs` contient le module modifié : le worker embarqué d’origine a été extrait sans évaluation de code et la fabrique a été remplacée par un Worker statique local ; la licence MPL-2.0 s’applique à ce fichier. `extension/vendor/aac-worker.js` contient le code de worker et ses données WASM tel qu’extrait du paquet. `sources/build.mjs` reproduit cette transformation à partir du paquet verrouillé. Le code source original et les instructions de construction de la dépendance/FFmpeg sont disponibles dans son paquet npm et son dépôt officiel ; README amont explique les options FFmpeg/Emscripten. Les textes LGPL et notices ONNX sont conservés en sources pour refaire le build sans récupérer les licences au réseau.

Les modèles Whisper ne sont pas inclus dans l’archive : leur téléchargement nécessite accès à leur dépôt Hugging Face. La licence et la version précise des poids n’ont pas pu être vérifiées dans le cloud (HTTP CONNECT 403) ; cette vérification reste requise avant toute redistribution de poids. Aucune licence de modèle ni gratuité future d’un fournisseur n’est inventée. L’audio est traité localement lorsque le runtime et le modèle fonctionnent.
