import {test} from 'node:test';
import assert from 'node:assert/strict';
import {newProject,migrateImageModel} from '../extension/studio/core.mjs';

test('new studio projects select the current Nano Banana 2.1 model',()=>{
  assert.equal(newProject().settings.imageModel,'Nano Banana 2.1');
});
test('old saved model migrates once without changing Lite, Pro or future choices',()=>{
  const old={settings:{imageModel:'Nano Banana 2',aspect:'9:16'}};
  assert.equal(migrateImageModel(old),true);
  assert.deepEqual(old.settings,{imageModel:'Nano Banana 2.1',aspect:'9:16'});
  assert.equal(migrateImageModel(old),false);
  for(const name of ['Nano Banana 2 Lite','Nano Banana Pro','Future model']){
    const p={settings:{imageModel:name}};
    assert.equal(migrateImageModel(p),false);
    assert.equal(p.settings.imageModel,name);
  }
});
