/** Socle local ELPODNA. Aucune API distante ni code de la référence. */
export const VERSION = 1;
export const LIMITS = Object.freeze({audioBytes:250*1024*1024,duration:900,prompts:10000,backupBytes:600*1024*1024});
export const DEFAULTS = Object.freeze({mode:'IMAGE',interval:1,randomInterval:false,intervalMax:5,autoDownload:false,parallelDownload:false,retryDownload:true,folder:'ELPODNA',datedFolder:true,naming:'num',startNumber:1,stripTags:false,style:'cinematic',aspect:'16:9',sceneSeconds:8,resolution:'720p',motion:'fixed'});
export function uid(){return crypto.randomUUID();}
export function integer(value,min,max,label){const n=Number(value);if(!Number.isInteger(n)||n<min||n>max)throw new Error(`${label} : entier requis entre ${min} et ${max}.`);return n;}
export function preferences(input={}){
 const p={...DEFAULTS,...input};
 p.interval=integer(p.interval,1,300,'Intervalle');p.intervalMax=integer(p.intervalMax,1,300,'Intervalle maximal');p.startNumber=integer(p.startNumber,1,99999,'Numéro initial');
 if(p.randomInterval&&p.intervalMax<p.interval)throw new Error('L’intervalle maximal doit être supérieur ou égal au minimum.');
 for(const [key,values] of Object.entries({mode:['IMAGE','VIDEO'],naming:['num','prompt','time','numtime'],aspect:['16:9','9:16','1:1'],resolution:['720p','1080p'],motion:['fixed','zoom']}))if(!values.includes(p[key]))throw new Error(`Réglage invalide : ${key}.`);
 for(const key of ['randomInterval','autoDownload','parallelDownload','retryDownload','datedFolder','stripTags'])if(typeof p[key]!=='boolean')throw new Error(`Réglage booléen invalide : ${key}.`);
 p.folder=safeFolder(p.folder);return p;
}
export function safeBase(value,max=100){return String(value).normalize('NFC').replace(/[<>:"/\\|?*\u0000-\u001f]/g,'_').replace(/\s+/g,' ').replace(/[. ]+$/g,'').trim().slice(0,max)||'sans-nom';}
export function safeFolder(value){
 if(typeof value!=='string'||value.length>200||/^[\\/]|^[a-z]:/i.test(value))throw new Error('Le dossier doit être un chemin relatif.');
 const parts=value.replace(/\\/g,'/').split('/');if(parts.some(x=>x==='..'||x==='.'||!x.trim()))throw new Error('Le dossier ne peut pas contenir de segment vide, . ou ...');
 return parts.map(x=>safeBase(x,80)).join('/');
}
export function stamp(date=new Date()){if(!Number.isFinite(date.getTime()))throw new Error('Date invalide.');return date.toISOString().replace(/[:.]/g,'-').replace('T','_').replace('Z','');}
export function filename(prompt,index,prefs,ext,now=new Date()){
 const p=preferences(prefs);integer(index,0,LIMITS.prompts-1,'Index');if(!/^(png|jpg|jpeg|webp|mp4|webm)$/.test(ext))throw new Error('Extension média invalide.');
 const num=String(index+p.startNumber).padStart(4,'0');const base={num,prompt:safeBase(prompt),time:stamp(now),numtime:`${num}_${stamp(now)}`}[p.naming];
 return `${p.folder}${p.datedFolder?'/'+now.toISOString().slice(0,10):''}/${base}.${ext}`;
}
export function parsePrompts(text,{stripTags=false}={}){
 if(typeof text!=='string'||text.length>5*1024*1024)throw new Error('Texte de prompts invalide ou trop volumineux.');
 const lines=text.replace(/^\uFEFF/,'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 if(lines.length>LIMITS.prompts)throw new Error('Le lot dépasse 10 000 prompts.');
 return lines.map(line=>{const tags=[...line.matchAll(/\[([^\]\r\n]{1,80})\]/g)].map(m=>m[1].trim());const content=stripTags?line.replace(/\[[^\]\r\n]{1,80}\]/g,'').replace(/\s+/g,' ').trim():line;if(!content)throw new Error('Un prompt ne contient que des tags.');return {id:uid(),text:content,tags:[...new Set(tags)],refIds:[],status:'waiting',receipt:null,result:null,attempts:0,error:''};});
}
export function tagForName(name){return String(name).replace(/\.[^.]*$/,'').normalize('NFC').trim().toLocaleLowerCase('fr');}
export function mapReferences(prompts,assets){return prompts.map(p=>({...p,refIds:assets.filter(a=>p.tags.some(t=>tagForName(t)===tagForName(a.name))).map(a=>a.id)}));}
export function sortAssets(assets,order='added'){
 const comparators={added:(a,b)=>a.added-b.added,name:(a,b)=>a.name.localeCompare(b.name,'fr',{numeric:true}),'name-desc':(a,b)=>b.name.localeCompare(a.name,'fr',{numeric:true}),oldest:(a,b)=>a.modified-b.modified,newest:(a,b)=>b.modified-a.modified};
 if(!comparators[order])throw new Error('Tri inconnu.');return [...assets].sort(comparators[order]);
}
export function imageVideoQueue(assets,prompts,{order='added',frames=false}={}){
 const imgs=sortAssets(assets,order);if(!imgs.length||!prompts.length)throw new Error('Ajoutez des images et au moins un prompt.');
 const count=frames?imgs.length-1:imgs.length;if(count<1)throw new Error('Deux images minimum sont nécessaires pour les images de début et fin.');
 if(prompts.length!==1&&prompts.length!==count)throw new Error(`Utilisez un prompt partagé ou exactement ${count} prompts.`);
 return Array.from({length:count},(_,i)=>({...prompts[prompts.length===1?0:i],id:uid(),refIds:frames?[imgs[i].id,imgs[i+1].id]:[imgs[i].id],frameMode:frames?'pair':'start',status:'waiting',receipt:null,result:null}));
}
export function parseClock(value){
 const match=/^(?:(\d{1,3}):)?(\d{2}):(\d{2})[,.](\d{3})$/.exec(value.trim());
 if(!match||Number(match[2])>59||Number(match[3])>59)throw new Error(`Horodatage invalide : ${value}`);
 return Number(match[1]||0)*3600+Number(match[2])*60+Number(match[3])+Number(match[4])/1000;
}
export function subtitles(text,duration){
 if(typeof text!=='string'||text.length>10*1024*1024)throw new Error('Sous-titres invalides ou trop volumineux.');
 const lines=text.replace(/^\uFEFF/,'').replace(/\r/g,'').split('\n');const cues=[];
 for(let i=0;i<lines.length;i++){
  if(!lines[i].includes('-->'))continue;
  const m=/^\s*(\S+)\s+-->\s+(\S+)/.exec(lines[i]);if(!m)throw new Error('Plage de sous-titres invalide.');
  const start=parseClock(m[1]);let end=parseClock(m[2]);const content=[];while(i+1<lines.length&&lines[i+1].trim())content.push(lines[++i]);
  const words=content.join(' ').replace(/<[^>]*>/g,'').trim();if(!(end>start)||start<0||(duration!=null&&end>duration+.001))throw new Error('Sous-titre hors durée ou durée négative.');
  if(duration!=null&&end>duration)end=duration;if(end<=start)throw new Error('Sous-titre hors durée.');
  if(!words)throw new Error('Sous-titre sans texte.');if(cues.length&&start<cues.at(-1).end)throw new Error('Les sous-titres se chevauchent.');cues.push({start,end,text:words});
 }
 if(!cues.length)throw new Error('Aucun sous-titre horodaté trouvé.');return cues;
}
export function validateTimeline(scenes,duration){
 if(!Number.isFinite(duration)||duration<=0||duration>LIMITS.duration)throw new Error('Durée audio invalide (maximum 15 minutes).');
 if(!Array.isArray(scenes)||!scenes.length)throw new Error('La timeline doit comporter au moins une scène.');
 const ids=new Set();let end=0;
 for(const s of scenes){if(typeof s.id!=='string'||!s.id||ids.has(s.id))throw new Error('Identifiants de scènes invalides ou dupliqués.');ids.add(s.id);if(!Number.isFinite(s.start)||!Number.isFinite(s.end)||Math.abs(s.start-end)>.001||s.end<=s.start||s.end>duration+.001)throw new Error('La timeline contient un trou, un chevauchement ou une limite invalide.');end=s.end;}
 if(Math.abs(end-duration)>.001)throw new Error('La timeline ne couvre pas toute la durée.');return true;
}
export function scenesFromCues(cues,duration,seconds=8){
 if(!Array.isArray(cues)||!cues.length)throw new Error('Une transcription horodatée est nécessaire.');
 if(![5,8,12,20,'sentence','two-sentences'].includes(seconds))throw new Error('Découpage invalide.');
 let last=-Infinity;for(const c of cues){if(typeof c.text!=='string'||!c.text.trim()||!Number.isFinite(c.start)||!Number.isFinite(c.end)||c.start<0||c.end<=c.start||c.end>duration||c.start<last)throw new Error('Transcription invalide ou non triée.');last=c.end;}
 const groups=[];let bucket=[];
 for(let i=0;i<cues.length;i++){
  bucket.push(cues[i]);const text=bucket.map(c=>c.text.trim()).join(' ');const sentences=(text.match(/[.!?](?:\s|$)/g)||[]).length;
  const done=typeof seconds==='number'?cues[i].end-bucket[0].start>=seconds:sentences>=(seconds==='sentence'?1:2);
  if(done||i===cues.length-1){groups.push(bucket);bucket=[];}
 }
 const result=groups.map((g,i)=>({id:uid(),start:i===0?0:g[0].start,end:i===groups.length-1?duration:groups[i+1][0].start,text:g.map(c=>c.text.trim()).join(' '),prompt:'',refIds:[],imageKey:null,status:'draft'}));
 validateTimeline(result,duration);return result;
}
export function changeBoundary(scenes,index,end,duration){
 integer(index,0,scenes.length-2,'Scène');const next=structuredClone(scenes);next[index].end=Number(end);next[index+1].start=Number(end);validateTimeline(next,duration);return next;
}
export function sceneAt(scenes,time){return scenes.find((s,i)=>time>=s.start&&(time<s.end||(i===scenes.length-1&&time===s.end)))||null;}
function srtClock(seconds){const ms=Math.round(seconds*1000);return `${String(Math.floor(ms/3600000)).padStart(2,'0')}:${String(Math.floor(ms/60000)%60).padStart(2,'0')}:${String(Math.floor(ms/1000)%60).padStart(2,'0')},${String(ms%1000).padStart(3,'0')}`;}
export function srt(scenes,duration){validateTimeline(scenes,duration);return scenes.map((s,i)=>`${i+1}\n${srtClock(s.start)} --> ${srtClock(s.end)}\n${s.text}\n`).join('\n');}
export function newProject(){return {version:VERSION,id:uid(),title:'Nouvelle histoire',duration:0,settings:{...DEFAULTS},chunks:[],scenes:[],references:[],audioKey:null,updatedAt:Date.now()};}
/** Aucun envoi automatique après une suspension si son résultat est incertain. */
export function restoreQueue(queue){return queue.map(p=>p.status==='sending'?{...p,status:'uncertain',error:'Envoi interrompu : vérifiez le résultat sur Flow avant de reprendre.'}:structuredClone(p));}
export function markSending(item,now=Date.now()){
 if(!['waiting','failed'].includes(item.status))throw new Error('Cet élément ne peut pas être envoyé.');
 return {...item,status:'sending',attempts:item.attempts+1,receipt:{id:uid(),at:now},error:''};
}
export function markAccepted(item,receiptId,resultId){
 if(item.receipt?.id!==receiptId||!['sending','uncertain'].includes(item.status))throw new Error('Reçu périmé ou envoi absent.');
 if(typeof resultId!=='string'||!resultId)throw new Error('Identifiant de résultat manquant.');return {...item,status:'submitted',result:{id:resultId}};
}
export function validateBackup(data){
 if(!data||data.format!=='ELPODNA'||data.version!==VERSION||!data.project||!Array.isArray(data.assets))throw new Error('Sauvegarde ELPODNA invalide ou version non prise en charge.');
 const p=data.project;if(typeof p.id!=='string'||typeof p.title!=='string'||!Array.isArray(p.scenes)||!Array.isArray(p.references))throw new Error('Structure du projet invalide.');
 preferences(p.settings);if(p.scenes.length)validateTimeline(p.scenes,p.duration);
 const ids=new Set();for(const a of data.assets){if(typeof a.id!=='string'||ids.has(a.id)||typeof a.data!=='string'||!/^data:(audio\/[\w.+-]+|image\/(png|jpeg|webp)|application\/octet-stream);base64,[A-Za-z0-9+/]*={0,2}$/.test(a.data))throw new Error('Ressource invalide ou dupliquée.');ids.add(a.id);}
 for(const key of [p.audioKey,...p.references.map(r=>r.key),...p.scenes.map(s=>s.imageKey)].filter(Boolean))if(!ids.has(key))throw new Error('La sauvegarde est incomplète : ressource manquante.');
 return structuredClone(data);
}
