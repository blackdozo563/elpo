/* Flow v2 / legacy selectors audited against the user-supplied ViralDNA archive.
 * No proprietary backend, account or subscription endpoint is used. */
(()=>{
 if(globalThis.__ELPODNA_SETTINGS__)return;
 const icons={IMAGE:'image',VIDEO:'videocam',VIDEO_FRAMES:'crop_free',VIDEO_REFERENCES:'chrome_extension',LANDSCAPE:'crop_16_9',LANDSCAPE_4_3:'crop_landscape',SQUARE:'crop_square',PORTRAIT_3_4:'crop_portrait',PORTRAIT:'crop_9_16'};
 const wait=ms=>new Promise(r=>setTimeout(r,ms));
 const visible=e=>{if(!e||e.closest('[hidden],[aria-hidden="true"]'))return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&s.opacity!=='0';};
 const all=(s,r=document)=>[...r.querySelectorAll(s)].filter(visible);
 const clean=e=>{const c=e.cloneNode(true);c.querySelectorAll('mat-icon,i').forEach(n=>n.remove());return c.textContent.replace(/\s+/g,' ').trim();};
 const norm=s=>String(s).normalize('NFKC').replace(/[^\p{L}\p{N}]/gu,'').toLowerCase();
 function one(list,name){if(list.length!==1)throw Error(`${name} : ${list.length} cibles dans le compositeur principal. Aucun envoi effectué.`);return list[0];}
 function leftmost(list,name){const sorted=[...list].sort((a,b)=>a.getBoundingClientRect().left-b.getBoundingClientRect().left);if(!sorted.length)return null;if(sorted.length>1&&Math.abs(sorted[0].getBoundingClientRect().left-sorted[1].getBoundingClientRect().left)<2)throw Error(`${name} : deux cibles à la même position. Aucun envoi effectué.`);return sorted[0];}
 function trigger(){return leftmost(all('button.settings-trigger-button'),'Réglages Flow');}
 function composer(){const t=trigger();return t?.closest('flow-prompt-box,flow-base-prompt-box')||leftmost(all('flow-prompt-box,flow-base-prompt-box'),'Compositeur Flow')||document;}
 function pane(){const t=trigger(),id=t?.getAttribute('aria-controls');if(id){const e=document.getElementById(id);if(visible(e))return e;}const p=all('.cdk-overlay-pane').filter(e=>e.querySelector('flow-prompt-box-settings'));return p.length?one(p,'Panneau de réglages'):null;}
 async function poll(fn,name){for(let i=0;i<16;i++){const v=fn();if(v)return v;await wait(125);}throw Error(`${name} : réponse de Flow non confirmée. Aucun envoi effectué.`);}
 async function open(){if(pane())return pane();const t=trigger();if(!t)return null;t.click();return poll(pane,'Ouverture des réglages');}
 async function close(){if(pane()){one([trigger()].filter(Boolean),'Fermeture des réglages').click();await poll(()=>!pane(),'Fermeture des réglages');}}
 function byIcon(root,icon){return all('button[role="radio"],[role="tab"]',root).filter(e=>[...e.querySelectorAll('mat-icon,i')].some(n=>n.textContent.trim()===icon));}
 async function pick(list,name){const e=one(list,name);if(e.disabled||e.getAttribute('aria-disabled')==='true')throw Error(`${name} : option indisponible pour ce compte/modèle.`);const attr=e.getAttribute('role')==='tab'?'aria-selected':'aria-checked';if(e.getAttribute(attr)!=='true'){e.click();await poll(()=>e.isConnected?e.getAttribute(attr)==='true':null,name);}return clean(e);}
 function numeric(root,key,value){return all('button[role="radio"],[role="tab"]',root).filter(e=>{const t=clean(e);if(key==='resolution')return t.toLowerCase().replace(/[^0-9p]/g,'')===String(value).toLowerCase();if(t.includes(':')||t.replace(/\D/g,'')!==String(value))return false;return key==='count'?/^x\s*\d/i.test(t):!/^x/i.test(t)&&/\p{L}/u.test(t);});}
 function menuItems(){const pools=all('.cdk-overlay-pane,[role="menu"],[data-radix-popper-content-wrapper]');return [...new Set(pools.flatMap(p=>all('button.mat-mdc-menu-item,[role="menuitem"],[role="menuitemradio"]',p)))];}
 async function model(root,want){const b=one(all('button.mat-mdc-menu-trigger,button[aria-haspopup="menu"]',root),'Menu du modèle');if(norm(clean(b))===norm(want))return clean(b);b.click();await poll(()=>menuItems().length,'Liste des modèles');const exact=menuItems().filter(e=>norm(clean(e))===norm(want));one(exact,`Modèle « ${want} »`).click();await poll(()=>norm(clean(b))===norm(want),'Confirmation du modèle');return clean(b);}
 async function apply(settings={}){
  const report=[];const t=trigger();
  if(t){try{
   let p=await open();
   for(const key of ['mode','frameTab','model','aspect','resolution','duration','count']){
    const value=settings[key];if(value==null||value==='')continue;
    let label;if(key==='model')label=await model(p,value);else if(icons[value]&&['mode','frameTab','aspect'].includes(key))label=await pick(byIcon(p,icons[value]),`${key}=${value}`);else label=await pick(numeric(p,key,value),`${key}=${value}`);
    report.push({option:key,value,label,confirmed:true});p=pane()||p;
   }
   return {layout:'material-v2',report,chip:clean(t)};
  }finally{await close();}}
  // Legacy Radix: stable IDs from the reference, scoped to the settings overlay.
  let root=all('[role="dialog"],[role="menu"],[data-radix-popper-content-wrapper]').find(p=>p.querySelector('[role="tab"][id*="-trigger-"]'));
  let opener=null;
  if(!root){const scope=composer();const candidates=all('button[aria-haspopup="menu"]',scope).filter(b=>b.getBoundingClientRect().top>innerHeight*.55);opener=leftmost(candidates,'Réglages historiques');if(opener){opener.click();root=await poll(()=>all('[role="dialog"],[role="menu"],[data-radix-popper-content-wrapper]').find(p=>p.querySelector('[role="tab"][id*="-trigger-"]')),'Panneau historique');}}
  if(root){try{for(const key of ['mode','frameTab','model','aspect','resolution','duration','count']){const value=settings[key];if(value==null||value==='')continue;let label;if(key==='model')label=await model(root,value);else if(['mode','frameTab','aspect'].includes(key))label=await pick(all('[role="tab"]',root).filter(e=>e.id.endsWith('-trigger-'+value)),`${key}=${value}`);else label=await pick(numeric(root,key,value),`${key}=${value}`);report.push({option:key,value,label,confirmed:true});}return {layout:'radix-legacy',report};}finally{document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}));if(opener?.getAttribute('aria-expanded')==='true')opener.click();}}
  // Text-only fixtures / legacy sites exposing direct mode tabs.
  const aliases=settings.mode==='VIDEO'?['video','vidéo','videos','vidéos','text to video']:['image','images','générer des images'];
  const buttons=all('button,[role="tab"],[role="radio"]',composer()).filter(e=>aliases.includes(clean(e).toLowerCase()));
  const b=one(buttons,'Mode de génération');if(b.getAttribute('aria-selected')!=='true'&&b.getAttribute('aria-checked')!=='true')b.click();
  if(Object.keys(settings).some(k=>k!=='mode'&&settings[k]))throw Error('Ce Flow ne présente pas les réglages demandés. Aucun envoi effectué.');
  return {layout:'text-legacy',report:[{option:'mode',value:settings.mode,label:clean(b),confirmed:true}]};
 }
 async function inspect(){if(!trigger())return {layout:'legacy',options:{}};try{const p=await open();const options={};for(const key of ['mode','frameTab','aspect'])options[key]=Object.entries(icons).filter(([code,icon])=>byIcon(p,icon).length&& (key==='mode'?['IMAGE','VIDEO'].includes(code):key==='frameTab'?code.startsWith('VIDEO_'):!code.startsWith('VIDEO')&&code!=='IMAGE')).map(([value,icon])=>({value,label:clean(byIcon(p,icon)[0]),selected:byIcon(p,icon)[0].getAttribute('aria-checked')==='true'}));for(const key of ['count','duration','resolution'])options[key]=all('button[role="radio"]',p).filter(e=>{const t=clean(e);return key==='count'?/^x\s*\d+$/i.test(t):key==='resolution'?/^\d+p$/i.test(t):/^\d+\s*[\p{L}.]+$/u.test(t)&&!/^x|p$/i.test(t);}).map(e=>({value:key==='resolution'?clean(e):Number(clean(e).replace(/\D/g,'')),label:clean(e),selected:e.getAttribute('aria-checked')==='true'}));const b=all('button.mat-mdc-menu-trigger',p);options.model=b.map(e=>({value:clean(e),label:clean(e),selected:true}));if(b.length===1){b[0].click();await poll(()=>menuItems().length,'Lecture des modèles');options.model=menuItems().map(e=>({value:clean(e),label:clean(e),selected:norm(clean(e))===norm(clean(b[0]))}));document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}));}return {layout:'material-v2',options};}finally{await close();}}
 globalThis.__ELPODNA_SETTINGS__={apply,inspect,composer,visible,all,clean,one,poll,leftmost};
})();
