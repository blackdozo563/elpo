/** Téléchargements vérifiés avec tentatives bornées et arrêt explicite. */
export async function verifiedDownload({url,filename,previousId,api,signal,onStarted=async()=>{},attempts=3,pollMs=500}){
 if(!/^https:\/\//.test(url)||typeof filename!=='string')throw new Error('Téléchargement invalide.');
 let id=previousId;
 for(let attempt=0;attempt<attempts;attempt++){
  if(signal?.aborted)throw new DOMException('Téléchargement annulé.','AbortError');
  if(id){const existing=(await api.search({id}))[0];if(existing?.state==='complete')return {id,state:'complete'};if(!existing||existing.state==='interrupted')id=null;}
  if(!id){id=await api.download({url,filename,conflictAction:'uniquify',saveAs:false});await onStarted(id,attempt+1);}
  const until=Date.now()+10*60*1000;
  let failure;
  while(Date.now()<until){
   if(signal?.aborted){await api.cancel(id).catch(()=>{});throw new DOMException('Téléchargement annulé.','AbortError');}
   const record=(await api.search({id}))[0];if(record?.state==='complete')return {id,state:'complete'};
   if(record?.state==='interrupted'){failure=record.error||'Téléchargement interrompu.';if(failure==='USER_CANCELED')throw new Error('Téléchargement annulé dans Chrome.');break;}
   if(!record){failure='Téléchargement absent de Chrome.';break;}await new Promise(r=>setTimeout(r,pollMs));
  }
  if(!failure)throw new Error('Le téléchargement reste en cours après dix minutes. Vérifiez le gestionnaire Chrome.');
  id=null;if(attempt===attempts-1)throw new Error(failure);
 }
}
export async function limitedMap(items,limit,work){
 if(!Number.isInteger(limit)||limit<1||limit>4)throw new Error('Parallélisme invalide.');let index=0;const result=new Array(items.length);const errors=[];
 await Promise.all(Array.from({length:Math.min(limit,items.length)},async()=>{while(index<items.length){const current=index++;try{result[current]=await work(items[current],current);}catch(e){errors.push(e);}}}));
 if(errors.length)throw new AggregateError(errors,errors.map(e=>e.message).join(' ; '));return result;
}
