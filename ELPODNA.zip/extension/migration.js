/* Preserve ELPODNA 0.1 projects and media when reloading the same extension ID. */
(()=>{
 const request=r=>new Promise((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
 async function open(name,stores){const r=indexedDB.open(name,1);r.onupgradeneeded=()=>{for(const s of stores)if(!r.result.objectStoreNames.contains(s))r.result.createObjectStore(s);};return request(r);}
 function story(old){const p=structuredClone(old);p.schema=1;p.createdAt||=p.updatedAt||Date.now();p.transcript=(p.chunks||[]).map(c=>c.text).join(' ');p.chunks=(p.chunks||[]).map(c=>({text:c.text,timestamp:c.timestamp||[c.start,c.end]}));p.settings={...p.settings,resolution:String(p.settings.resolution||'720').replace('p',''),motion:p.settings.motion==='fixed'?'still':p.settings.motion||'still',imageModel:'Nano Banana 2.1',interval:p.settings.interval||1,whisper:p.settings.whisper||'tiny',sceneSeconds:({'sentence':'sentence-1','two-sentences':'sentence-2'})[p.settings.sceneSeconds]||p.settings.sceneSeconds};p.scenes=p.scenes.map(s=>({...s,generation:s.generation||0,promptSource:s.prompt?'manual':'draft',refsManual:true}));p.references=p.references.map(r=>({...r,tag:r.tag||r.name,description:r.description||'',note:r.note||''}));p.run=null;p.step=p.scenes.length?2:0;return p;}
 globalThis.elpodnaLegacyStory=story;
 globalThis.elpodnaMigrate=async()=>{
  if(!indexedDB.databases)return null;const names=await indexedDB.databases();if(!names.some(d=>d.name==='elpodna'))return null;
  const old=await open('elpodna',[]);if(!['state','assets','projects'].every(s=>old.objectStoreNames.contains(s))){old.close();return null;}
  const read=(s,k)=>request(old.transaction(s).objectStore(s).get(k));const ui=await read('state','ui'),current=await read('state','current-project');
  if(await read('state','migration-0.2')){old.close();return current;}
  const tx=old.transaction(['assets','projects']),a=tx.objectStore('assets'),p=tx.objectStore('projects');const [keys,values,projects]=await Promise.all([request(a.getAllKeys()),request(a.getAll()),request(p.getAll())]);
  const db=await open('elpodna-studio-v2',['projects','assets','results']);
  const write=async(db,store,key,value)=>{if(await request(db.transaction(store).objectStore(store).get(key))!==undefined)return;await new Promise((resolve,reject)=>{const t=db.transaction(store,'readwrite');t.objectStore(store).put(value,key);t.oncomplete=resolve;t.onerror=()=>reject(t.error);});};
  for(let i=0;i<keys.length;i++){const blob=values[i]?.blob;if(blob instanceof Blob)await write(db,'assets',keys[i],blob);}
  for(const project of projects)await write(db,'projects',project.id,story(project));db.close();
  const refs=await open('autoflow-refs',['kv']),existing=await request(refs.transaction('kv').objectStore('kv').get('afLibrary'))||[],library=[...existing];
  for(let i=0;i<keys.length;i++){const v=values[i];if(v?.kind!=='library'||library.some(a=>a.id===keys[i]))continue;const bytes=new Uint8Array(await v.blob.arrayBuffer());let binary='';for(let j=0;j<bytes.length;j+=32768)binary+=String.fromCharCode(...bytes.subarray(j,j+32768));library.push({id:keys[i],name:v.name,tag:String(v.name).replace(/\.[^.]+$/,''),dataUrl:`data:${v.blob.type};base64,${btoa(binary)}`,type:v.blob.type});}
  if(library.length)await new Promise((resolve,reject)=>{const t=refs.transaction('kv','readwrite');t.objectStore('kv').put(library,'afLibrary');t.oncomplete=resolve;t.onerror=()=>reject(t.error);});refs.close();
  if(ui&&globalThis.chrome?.storage){const saved=await chrome.storage.local.get(['afPromptDraft','afInterval','afDlRoot']);const v={};if(saved.afPromptDraft==null)v.afPromptDraft=ui.prompts||'';if(saved.afInterval==null)v.afInterval=ui.prefs?.interval||1;if(saved.afDlRoot==null)v.afDlRoot=ui.prefs?.folder||'ELPODNA';await chrome.storage.local.set(v);}
  await new Promise((resolve,reject)=>{const t=old.transaction('state','readwrite');t.objectStore('state').put(true,'migration-0.2');t.oncomplete=resolve;t.onerror=()=>reject(t.error);});old.close();return current;
 };
})();
