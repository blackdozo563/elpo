/** Persistence transactionnelle locale, indépendante du worker d’automatisation. */
let opening;
export function database(){
 if(!opening)opening=new Promise((resolve,reject)=>{
  const r=indexedDB.open('elpodna',1);
  r.onupgradeneeded=()=>{for(const name of ['projects','assets','state','logs'])if(!r.result.objectStoreNames.contains(name))r.result.createObjectStore(name);};
  r.onsuccess=()=>{r.result.onversionchange=()=>{r.result.close();opening=null;};resolve(r.result);};
  r.onerror=()=>{opening=null;reject(r.error);};r.onblocked=()=>{opening=null;reject(new Error('Fermez les autres fenêtres ELPODNA pour mettre à jour le stockage.'));};
 });return opening;
}
export async function transaction(stores,mode,work){
 const db=await database();return new Promise((resolve,reject)=>{
  const tx=db.transaction(stores,mode);let result;
  tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('Écriture annulée.'));
  try{result=work(tx);}catch(e){tx.abort();reject(e);}
 });
}
export async function get(store,key){let value;await transaction([store],'readonly',tx=>{const r=tx.objectStore(store).get(key);r.onsuccess=()=>value=r.result;});return value;}
export async function put(store,key,value){await transaction([store],'readwrite',tx=>tx.objectStore(store).put(value,key));}
export async function remove(store,key){await transaction([store],'readwrite',tx=>tx.objectStore(store).delete(key));}
export async function entries(store){let values=[];await transaction([store],'readonly',tx=>{const r=tx.objectStore(store).openCursor();r.onsuccess=()=>{const c=r.result;if(c){values.push({key:c.key,value:c.value});c.continue();}};});return values;}
export async function saveProjectWithAssets(project,assets){await transaction(['projects','assets'],'readwrite',tx=>{tx.objectStore('projects').put(project,project.id);for(const a of assets)tx.objectStore('assets').put(a.value,a.key);});}
export async function appendLog(event){
 const level=['info','error','success','warning'].includes(event.level)?event.level:'info';
 const value={id:crypto.randomUUID(),at:Date.now(),level,message:String(event.message||'').slice(0,2000)};
 await put('logs',value.id,value);return value;
}
