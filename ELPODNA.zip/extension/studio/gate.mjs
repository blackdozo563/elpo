// ViralDNA Pro gate. The studio stays hidden until the site confirms profiles.is_pro for the
// signed-in account (/api/auth/me, the same source the website and the YouTube extension use).
// Every paid server call checks Pro again; this gate is the product boundary, not the only lock.
import {t} from './i18n.mjs';

const CACHE_KEY = 'afNarrationPro';
const CACHE_FRESH = 10 * 60 * 1000;      // open instantly for a Pro member seen in the last 10 minutes
const CACHE_OFFLINE = 24 * 60 * 60 * 1000; // a network failure does not lock out a confirmed member for a day
const $ = id => document.getElementById(id);
const cfg = () => (typeof AUTOFLOW_CONFIG !== 'undefined' ? AUTOFLOW_CONFIG : {});

let state = 'loading', email = '', note = '', onUnlock = null, extension = false, checking = null, lastCheck = 0, preview = false;

export function renderGate() {
  const gate = $('pro-gate');
  if (!gate) return;
  gate.dataset.state = state;
  $('gate-status').textContent = state === 'free' ? t('gateFree', {email: email || 'ViralDNA'})
    : state === 'signed-out' ? t('gateSignedOut') : state === 'error' ? t('gateError') : '';
  $('gate-note').textContent = note;
  $('gate-note').hidden = !note;
}

function setState(next, {mail = '', message = ''} = {}) {
  state = next; email = mail; note = message;
  renderGate();
  const open = next === 'pro';
  document.body.classList.toggle('gate-locked', !open);
  if (!open) document.querySelectorAll('dialog[open]').forEach(d => d.close());
  if (open) onUnlock?.();
}

async function readCache() { try { return (await chrome.storage.local.get(CACHE_KEY))[CACHE_KEY] || null; } catch { return null; } }
async function writeCache(value) { try { await chrome.storage.local.set({[CACHE_KEY]: value}); } catch {} }

async function currentSession() {
  try { return await globalThis.SBAuth?.getValidSession(); } catch { return null; }
}
export const sessionToken = async () => (await currentSession())?.access_token || '';

// Script token balance for the header chip and the token store. It rides on the same
// /api/auth/me call the gate already makes (profile.script_credits); a site that does not
// send the field yet simply leaves the chip hidden. Paid calls report the new balance too.
export function publishCredits(n) {
  if (typeof n !== 'number' || !Number.isFinite(n)) return;
  try { window.dispatchEvent(new CustomEvent('af-credits', {detail: n})); } catch {}
}
export const refreshCredits = () => check({quiet: true});

async function verify() {
  const session = await currentSession();
  if (!session?.access_token) return {state: 'signed-out'};
  const uid = session.user?.id || '';
  try {
    const res = await fetch(cfg().VIRALDNA_ME_URL, {headers: {Authorization: 'Bearer ' + session.access_token},
      cache: 'no-store', signal: AbortSignal.timeout(15000)});
    if (!res.ok) throw new Error('status ' + res.status);
    const data = await res.json();
    if (!data?.user) return {state: 'signed-out'};
    const pro = !!data.profile?.is_pro;
    publishCredits(data.profile?.script_credits);
    await writeCache({uid: data.user.id, pro, at: Date.now()});
    return {state: pro ? 'pro' : 'free', mail: data.user.email || ''};
  } catch {
    const cached = await readCache();
    if (cached?.pro && cached.uid && cached.uid === uid && Date.now() - cached.at < CACHE_OFFLINE) return {state: 'pro'};
    return {state: 'error'};
  }
}

async function check({quiet = false, message = ''} = {}) {
  if (preview) return state;
  if (checking) return checking;
  if (!quiet && state !== 'pro') setState('loading');
  checking = (async () => {
    try { const r = await verify(); setState(r.state, {mail: r.mail, message: r.state === 'free' ? message : ''}); return r.state; }
    finally { checking = null; lastCheck = Date.now(); }
  })();
  return checking;
}

async function signIn() {
  if (preview) return;
  try { await globalThis.SBAuth.signInWithGoogle(); }
  catch { setState(state === 'loading' ? 'signed-out' : state, {mail: email, message: t('gateLoginFailed')}); return; }
  await check();
}

function busy(button, work) {
  return async () => {
    if (button.disabled) return;
    button.disabled = true;
    try { await work(); } finally { button.disabled = false; }
  };
}

export async function startGate(options) {
  ({extension, onUnlock} = options);
  const $b = id => $(id);
  $b('gate-signin').onclick = busy($b('gate-signin'), signIn);
  $b('gate-switch').onclick = busy($b('gate-switch'), async () => {
    if (preview) return;
    try { await globalThis.SBAuth.signOut(); } catch {}
    setState('signed-out');
    await signIn();
  });
  $b('gate-retry').onclick = busy($b('gate-retry'), () => check());
  $b('gate-recheck').onclick = busy($b('gate-recheck'), async () => {
    await check({quiet: true, message: t('gateStillFree')});
  });
  $b('gate-upgrade').onclick = () => {
    const url = cfg().VIRALDNA_PRICING_URL || 'https://www.viraldna.io/#pricing';
    if (extension) chrome.tabs.create({url}).catch(() => window.open(url, '_blank', 'noopener'));
    else window.open(url, '_blank', 'noopener');
  };

  // A page outside the extension (design preview) has no account: open it, or show a forced gate state.
  if (!extension) {
    const forced = new URLSearchParams(location.search).get('gate');
    preview = true;
    if (['loading', 'signed-out', 'free', 'error'].includes(forced)) setState(forced, {mail: 'creator@example.com'});
    else setState('pro');
    return;
  }

  // Sign-in, sign-out or an account switch in the side panel re-evaluates the gate.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.sb_session) check({quiet: state === 'pro'});
  });
  // Coming back from the pricing page (or any other tab) re-checks a locked gate on its own.
  const recheckLocked = () => {
    if (document.visibilityState === 'visible' && (state === 'free' || state === 'error') && Date.now() - lastCheck > 4000) check({quiet: true});
  };
  document.addEventListener('visibilitychange', recheckLocked);
  window.addEventListener('focus', recheckLocked);

  // "Daha fazla bilgi": sure siniri ve token gibi ayrintilar sitede anlatilir,
  // kapida yalniz iki satir durur. Adres config'ten gelir.
  const more = document.getElementById('gate-more');
  if (more) {
    const url = cfg().NARRATION_INFO_URL;
    // closest() BILEREK kullanilmiyor: gate testindeki sahte DOM minimal tutuldu ve
    // closest metodunu tasimiyor. Satira kendi id degeri verildi; getElementById hem
    // tarayicida hem testte calisir.
    const satir = document.getElementById('gate-more-row') || more;
    if (url) { more.href = url; satir.hidden = false; }
    else satir.hidden = true;   // adres yoksa satir hic yer kaplamaz
  }

  const [session, cached] = await Promise.all([currentSession(), readCache()]);
  const uid = session?.user?.id || '';
  if (session?.access_token && cached?.pro && uid && cached.uid === uid && Date.now() - cached.at < CACHE_FRESH) {
    setState('pro');
    check({quiet: true});
  } else {
    await check();
  }
}
