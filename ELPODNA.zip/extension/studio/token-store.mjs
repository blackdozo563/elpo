// Sesten Videoya token magazasi: sag ustteki bakiye + "Token ekle" + paket penceresi.
// Bakiye Pro kapisinin zaten yaptigi /api/auth/me cagrisindan gelir (gate.mjs publishCredits),
// ek istek yok. Paket secilince sitede Stripe odeme oturumu acilir ve yeni sekmede gosterilir;
// odeme bitince sekmeye donuldugunde bakiye kendiliginden tazelenir.
// Paketler ve fiyatlar sitedeki TokenStoreModal.tsx ve /api/stripe/checkout ile AYNI olmali.
import {t} from './i18n.mjs';
import {sessionToken, refreshCredits} from './gate.mjs';

export const PACKS = [
  {plan: 'script50',   tokens: 50,   price: '3.99',  old: '5',   off: '-20%'},
  {plan: 'script100',  tokens: 100,  price: '7.99',  old: '10',  off: '-20%', tag: 'popular'},
  {plan: 'script500',  tokens: 500,  price: '34.99', old: '50',  off: '-30%'},
  {plan: 'script1000', tokens: 1000, price: '59.99', old: '100', off: '-40%', tag: 'best'},
];
const STRIPE_CHECKOUT = /^https:\/\/checkout\.stripe\.com\//;
const $ = id => document.getElementById(id);
const cfg = () => (typeof AUTOFLOW_CONFIG !== 'undefined' ? AUTOFLOW_CONFIG : {});
let credits = null, buying = '', pendingSince = 0, pendingFrom = null, extension = false;

function renderChip() {
  const chip = $('token-chip');
  if (!chip) return;
  chip.hidden = credits === null;
  $('token-count').textContent = credits === null ? '' : String(credits);
  chip.title = t('tokenChipTitle');
  const bal = $('token-balance');
  if (bal) { bal.hidden = credits === null; bal.textContent = credits === null ? '' : t('tokenBalance', {n: credits}); }
}

function renderPacks() {
  const box = $('token-packs');
  if (!box) return;
  box.replaceChildren(...PACKS.map(p => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'tk-pack' + (p.tag ? ' tk-' + p.tag : '');
    b.dataset.plan = p.plan;
    b.disabled = !!buying;
    b.setAttribute('aria-busy', buying === p.plan ? 'true' : 'false');
    const per = (parseFloat(p.price) / p.tokens).toFixed(3);
    const tag = p.tag ? `<span class="tk-tag">${t(p.tag === 'best' ? 'tokenBest' : 'tokenPopular')}</span>` : '';
    b.innerHTML = `${tag}<span class="tk-amount"><b>${p.tokens}</b> <small>${t('tokenWordCap')}</small></span>` +
      `<span class="tk-price"><b>$${p.price}</b> <s>$${p.old}</s> <em>${p.off}</em></span>` +
      `<span class="tk-per">${buying === p.plan ? t('tokenOpening') : `$${per} ${t('tokenPer')}`}</span>`;
    b.onclick = () => buy(p.plan);
    return b;
  }));
}

function note(key, isError) {
  const el = $('token-note');
  if (!el) return;
  el.hidden = !key;
  el.textContent = key ? t(key) : '';
  el.classList.toggle('is-error', !!isError);
}

async function openUrl(url) {
  if (extension) { try { await chrome.tabs.create({url}); return; } catch {} }
  window.open(url, '_blank', 'noopener');
}

async function buy(plan) {
  if (buying) return;
  note('');
  const token = await sessionToken();
  if (!token) { note('tokenSignin', true); return; }
  buying = plan; renderPacks();
  try {
    const res = await fetch(cfg().VIRALDNA_CHECKOUT_URL, {method: 'POST', cache: 'no-store',
      headers: {Authorization: 'Bearer ' + token, 'Content-Type': 'application/json'},
      body: JSON.stringify({plan}), signal: AbortSignal.timeout(20000)});
    const data = await res.json().catch(() => ({}));
    if (!res.ok || typeof data.url !== 'string' || !STRIPE_CHECKOUT.test(data.url)) throw new Error('checkout ' + res.status);
    await openUrl(data.url);
    pendingSince = Date.now(); pendingFrom = credits;
    note('tokenOpened');
  } catch {
    note('tokenError', true);
  } finally {
    buying = ''; renderPacks();
  }
}

// Odeme sekmesinden donulunce bakiye tazelenir. Stripe webhook'u birkac saniye gecikebildigi
// icin bir kez hemen, sonra kisa araliklarla (en cok 2 dk) bakiye degisene kadar sorulur.
let recheckTimer = 0;
function afterPurchase() {
  if (!pendingSince || document.visibilityState !== 'visible') return;
  clearTimeout(recheckTimer);
  const tick = async n => {
    await refreshCredits().catch(() => {});
    if (!pendingSince) return;
    if (Date.now() - pendingSince > 120000) { pendingSince = 0; return; }
    if (n < 6) recheckTimer = setTimeout(() => tick(n + 1), 5000);
  };
  tick(0);
}

export function openTokenStore() {
  const d = $('token-dialog');
  if (!d) return;
  note(''); renderPacks(); renderChip();
  if (!d.open) d.showModal();
  refreshCredits().catch(() => {});
}

export function relabelTokenStore() { renderChip(); renderPacks(); }

export function startTokenStore(options = {}) {
  extension = !!options.extension;
  window.addEventListener('af-credits', e => {
    credits = e.detail;
    if (pendingSince && pendingFrom !== null && credits > pendingFrom) { pendingSince = 0; note('tokenAdded'); }
    renderChip();
  });
  $('token-add')?.addEventListener('click', openTokenStore);
  $('token-chip')?.addEventListener('click', openTokenStore);
  document.addEventListener('visibilitychange', afterPurchase);
  window.addEventListener('focus', afterPurchase);
  renderChip(); renderPacks();
}
