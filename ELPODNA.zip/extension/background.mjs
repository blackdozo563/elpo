import {preferences,filename,markSending,restoreQueue} from './core.mjs';
import {verifiedDownload,limitedMap} from './downloads.mjs';
import {get,put,appendLog} from './store.mjs';
const FLOW=['https://labs.google/*','https://*.labs.google/*','https://flow.google.com/*'];
let downloadAbort=null,downloadBusy=false;
let state={version:1,status:'idle',queue:[],index:0,tabId:null,prefs:preferences(),nextAt:0,logs:[]},lock=false;
const ready=(async()=>{const old=await get('state','automation');if(old){state={...state,...old,queue:restoreQueue(old.queue||[])};if(state.status==='running')state.status='paused';await save();}})();
async function save(){await put('state','automation',state);chrome.runtime.sendMessage({channel:'ELPODNA_UPDATE'}).catch(()=>{});}
async function log(message,level='info'){await appendLog({message,level});await save();}
async function tabs(){return (await chrome.tabs.query({url:FLOW})).filter(t=>/\/project\//.test(t.url||''));}
async function call(action,data={}){
 const tab=await chrome.tabs.get(state.tabId);if(!FLOW.some(()=>/^https:\/\/(labs\.google|[a-z0-9.-]+\.labs\.google|flow\.google\.com)\//.test(tab.url||''))||!/\/project\//.test(tab.url||''))throw new Error('L’onglet choisi n’est plus un projet Flow.');
 if(action!=='inspect'&&state.projectUrl&&(tab.url||'').split(/[?#]/)[0]!==state.projectUrl.split(/[?#]/)[0])throw new Error('Le projet Flow a changé dans cet onglet. Reconnectez le bon projet avant de reprendre.');
 let response;try{response=await chrome.tabs.sendMessage(state.tabId,{channel:'ELPODNA_FLOW',action,...data});}catch{await chrome.scripting.executeScript({target:{tabId:state.tabId},files:['flow-settings.js','flow-content.js']});response=await chrome.tabs.sendMessage(state.tabId,{channel:'ELPODNA_FLOW',action,...data});}
 if(!response?.ok)throw new Error(response?.error||'Flow n’a pas répondu.');return response.data;
}
function wake(ms=1000){state.nextAt=Date.now()+ms;chrome.alarms.create('elpodna-run',{when:state.nextAt});setTimeout(()=>step().catch(fail),ms);}
async function fail(e){state.status='paused';await log(e.message,'error');chrome.power.releaseKeepAwake();}
async function click(position){
 const target={tabId:state.tabId};await chrome.debugger.attach(target,'1.3');
 try{if(state.status!=='running'){const e=new Error('Envoi annulé avant le clic.');e.code='NOT_SENT';throw e;}await chrome.debugger.sendCommand(target,'Input.dispatchMouseEvent',{type:'mousePressed',x:position.x,y:position.y,button:'left',clickCount:1});await chrome.debugger.sendCommand(target,'Input.dispatchMouseEvent',{type:'mouseReleased',x:position.x,y:position.y,button:'left',clickCount:1});}finally{await chrome.debugger.detach(target).catch(()=>{});}
}
async function blobData(blob){const data=new Uint8Array(await blob.arrayBuffer());let s='';for(let i=0;i<data.length;i+=32768)s+=String.fromCharCode(...data.subarray(i,i+32768));return `data:${blob.type};base64,${btoa(s)}`;}
async function refsFor(item){const refs=[];for(const id of item.refIds||[]){const a=await get('assets',id);if(!a?.blob)throw new Error('Référence locale manquante.');refs.push({name:a.name,data:await blobData(a.blob)});}if(new Set(refs.map(r=>r.name.toLocaleLowerCase())).size!==refs.length)throw new Error('Les références sélectionnées portent le même nom. Renommez-les dans Médias.');return refs;}
async function step(){
 await ready;if(lock||state.status!=='running'||Date.now()+20<state.nextAt)return;lock=true;
 try{
  const item=state.queue[state.index];if(!item){state.status='done';await log('Lot terminé.','success');chrome.power.releaseKeepAwake();Promise.resolve(chrome.notifications.create({type:'basic',iconUrl:'icons/128.png',title:'ELPODNA',message:'Le lot Google Flow est terminé.'})).catch(e=>log('Notification indisponible : '+e.message,'warning')); return;}
  if(item.status==='waiting'||item.status==='failed'){
   if(item.attempts>=3)throw new Error('Trois tentatives atteintes. Vérifiez Flow avant une relance manuelle.');
   const staged=await call('stage',{prompt:item.text,refs:await refsFor(item),mode:state.prefs.mode,frameMode:item.frameMode||null,options:state.options||[],settings:state.genSettings||{}});
   if(state.status!=='running')return;
   state.queue[state.index]={...markSending(item),before:staged.media.map(m=>m.id),sentAt:Date.now(),projectUrl:state.projectUrl};await save();
   // Le reçu est enregistré AVANT le clic ; si le clic est incertain, aucune relance aveugle.
   if(state.status!=='running'){state.queue[state.index].status='waiting';state.queue[state.index].receipt=null;await save();return;}
   await click(staged.click);await log(`Prompt ${state.index+1}/${state.queue.length} envoyé.`);wake(3000);await save();return;
  }
  if(item.status==='sending'){
   const {media}=await call('snapshot');const fresh=media.filter(m=>!item.before.includes(m.id)&&m.kind===state.prefs.mode);
   if(fresh.length>=(Number(state.genSettings?.count)||1)){item.status='ready';item.results=fresh;item.result=fresh[0];await log(`Résultat ${state.index+1} reçu.`, 'success');if(state.prefs.autoDownload)await downloadItem(state.index);state.index++;const p=state.prefs;const delay=p.randomInterval?p.interval+Math.random()*(p.intervalMax-p.interval):p.interval;wake(Math.round(delay*1000));await save();return;}
   if(Date.now()-item.sentAt>10*60*1000){item.status='uncertain';throw new Error('Aucun résultat confirmé après 10 minutes. Vérifiez Flow ; aucun renvoi automatique.');}
   wake(3000);await save();return;
  }
  if(item.status==='uncertain')throw new Error('Un envoi est incertain. Confirmez son résultat ou autorisez explicitement sa relance.');
  state.index++;wake(1000);await save();
 }catch(e){if(state.queue[state.index]?.status==='sending'){state.queue[state.index].status=e.code==='NOT_SENT'?'waiting':'uncertain';if(e.code==='NOT_SENT')state.queue[state.index].receipt=null;}await fail(e);}finally{lock=false;}
}
async function downloadItem(index){
 const item=state.queue[index];if(!item?.results?.length)throw new Error('Aucun résultat confirmé à télécharger.');
 if(downloadBusy)throw new Error('Un téléchargement est déjà en cours. Attendez sa fin ou arrêtez-le.');
 if(state.quality&&state.quality!=='source')throw new Error('Les variantes de résolution Flow ne sont pas vérifiées. Utilisez le fichier source ou le menu Flow.');
 downloadBusy=true;downloadAbort=new AbortController();const signal=downloadAbort.signal;
 try{await limitedMap(item.results,state.prefs.parallelDownload?2:1,async(media,n)=>{
  const ext=media.kind==='VIDEO'?'mp4':(/\.webp(?:\?|$)/.test(media.url)?'webp':/\.png(?:\?|$)/.test(media.url)?'png':'jpg');
  const name=filename(item.text,index,{...state.prefs,startNumber:state.prefs.startNumber+n},ext);
  const old=item.downloadRecords?.[media.id];const result=await verifiedDownload({url:media.url,filename:name,previousId:old?.id,api:chrome.downloads,signal,attempts:state.prefs.retryDownload?3:1,onStarted:async(id,attempt)=>{item.downloadRecords||={};item.downloadRecords[media.id]={id,attempt,state:'in_progress'};item.downloadIds=(item.downloadIds||[]).concat(id);await save();}});
  item.downloadRecords[media.id]={...item.downloadRecords[media.id],...result};await save();
 });await log('Les fichiers demandés sont téléchargés.','success');
 }finally{downloadBusy=false;downloadAbort=null;}
}
chrome.downloads.onChanged.addListener(async delta=>{await ready;for(const item of state.queue)if(item.downloadIds?.includes(delta.id)){if(delta.state?.current==='complete'){await log('Téléchargement terminé.','success');}if(delta.error){item.downloadError=delta.error.current;await log(`Téléchargement interrompu : ${delta.error.current}`,'error');}await save();}});
chrome.alarms.onAlarm.addListener(a=>{if(a.name==='elpodna-run')step().catch(fail);});
chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:true}).catch(()=>{});
async function handle(m){
 await ready;
 if(m.action==='state')return state;
 if(m.action==='tabs')return await tabs();
 if(m.action==='diagnose'){if(state.status==='running'||lock)throw new Error('Mettez le lot en pause avant de vérifier les réglages.');const prior=state.tabId;state.tabId=Number(m.tabId);try{return await call('diagnose',{settings:m.settings});}finally{state.tabId=prior;}}
 if(m.action==='inspect'){const prior=state.tabId;state.tabId=Number(m.tabId);try{return await call('inspect');}finally{if(state.status==='running')state.tabId=prior;}}
 if(m.action==='start'){
  if(state.status==='running'||lock)throw new Error('Un lot est déjà actif.');if(!Array.isArray(m.queue)||!m.queue.length||m.queue.length>10000||m.queue.some(p=>typeof p.id!=='string'||typeof p.text!=='string'||!p.text.trim()||p.text.length>12000||!Array.isArray(p.refIds)))throw new Error('File invalide.');
  const previous=state;
  state={version:1,status:'running',queue:m.queue.map(p=>({...p,status:'waiting',attempts:0,receipt:null,result:null})),index:0,tabId:Number(m.tabId),prefs:preferences(m.prefs),options:(m.options||[]).map(String),genSettings:m.genSettings||{},quality:m.quality||'source',nextAt:0,projectId:m.projectId||null};
  let inspected;try{inspected=await call('inspect');}catch(e){state=previous;throw e;}state.projectUrl=inspected.url;chrome.power.requestKeepAwake('display');await log('Lot démarré : réservez cet onglet Flow à ELPODNA jusqu’à la fin.');wake(500);await save();return state;
 }
 if(m.action==='pause'||m.action==='stop'){state.status=m.action==='pause'?'paused':'stopped';chrome.alarms.clear('elpodna-run');chrome.power.releaseKeepAwake();await log(m.action==='pause'?'Lot en pause.':'Lot arrêté.');return state;}
 if(m.action==='resume'){if(state.queue[state.index]?.status==='uncertain')throw new Error('Résolvez d’abord l’envoi incertain dans la file.');state.status='running';chrome.power.requestKeepAwake('display');wake(500);await save();return state;}
 if(m.action==='resolve'){
  const item=state.queue[Number(m.index)];if(item?.status!=='uncertain')throw new Error('Aucun envoi incertain à cet index.');
  if(m.choice==='retry'){item.status='waiting';item.receipt=null;}else if(m.choice==='skip'){item.status='skipped';if(state.index===Number(m.index))state.index++;}else throw new Error('Décision invalide.');await log('Envoi incertain résolu par confirmation utilisateur.');return state;
 }
 if(m.action==='download'){await downloadItem(Number(m.index));return state;}
 if(m.action==='cancelDownloads'){downloadAbort?.abort();state.prefs.autoDownload=false;for(const p of state.queue)for(const id of p.downloadIds||[]){const d=(await chrome.downloads.search({id}))[0];if(d?.state==='in_progress')await chrome.downloads.cancel(id).catch(()=>{});}await save();return state;}
 if(m.action==='regenerate'){const item=state.queue[Number(m.index)];if(!item)throw new Error('Élément absent.');if(state.status==='running')throw new Error('Mettez en pause avant de régénérer.');state.queue.push({...item,id:crypto.randomUUID(),status:'waiting',attempts:0,receipt:null,result:null,results:[]});if(state.index>=state.queue.length-1)state.index=state.queue.length-1;await save();return state;}
 if(m.action==='clear'){if(state.status==='running')throw new Error('Arrêtez le lot avant de vider la file.');state.queue=[];state.index=0;state.status='idle';await save();return state;}
 throw new Error('Commande inconnue.');
}
chrome.runtime.onMessage.addListener((m,s,reply)=>{if(s.id!==chrome.runtime.id||!s.url?.startsWith(chrome.runtime.getURL(''))||m?.channel!=='ELPODNA')return;handle(m).then(data=>reply({ok:true,data})).catch(e=>reply({ok:false,error:e.message}));return true;});
