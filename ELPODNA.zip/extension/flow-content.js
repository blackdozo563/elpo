(()=>{
 if(globalThis.__ELPODNA_FLOW__)return;globalThis.__ELPODNA_FLOW__=true;
 // Cibles observées dans les fichiers de référence, encore à vérifier sur le Flow live.
 const S={editor:'flow-prompt-box [contenteditable="true"], flow-prompt-box textarea, .ProseMirror, [data-lexical-editor="true"], textarea, [contenteditable="true"]',tiles:'flow-grid-tile-container, flow-tile-container, flow-image-tile, flow-video-tile, [class*="grid-tile"]',buttons:'button,[role="button"]'};
 const visible=e=>!!e&&e.getBoundingClientRect().width>0&&e.getBoundingClientRect().height>0&&getComputedStyle(e).visibility!=='hidden';
 const unique=(selector,root=document)=>[...root.querySelectorAll(selector)].filter(visible);
 const label=e=>[e.getAttribute('aria-label'),e.getAttribute('title'),e.innerText].filter(Boolean).join(' ').trim().toLocaleLowerCase();
 const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 function one(list,what){if(list.length!==1)throw new Error(`${what} : ${list.length} cibles trouvées. Action interrompue pour éviter une mauvaise cible.`);return list[0];}
 function editor(){const all=unique(S.editor).filter(e=>!e.closest('[role="dialog"], [aria-hidden="true"]'));const special=all.filter(e=>e.closest('flow-prompt-box,flow-base-prompt-box')||e.matches('.ProseMirror,[data-lexical-editor="true"]'));return one(special.length?special:all,'Zone de prompt');}
 function snapshot(){
  let tiles=unique(S.tiles);tiles=tiles.filter(t=>!tiles.some(x=>x!==t&&x.contains(t)));const media=[];
  for(const tile of tiles){if(tile.querySelector('[role="progressbar"],progress,mat-spinner'))continue;for(const el of tile.querySelectorAll('video,img')){const url=el.currentSrc||el.src;if(!url||!/^https:\/\//.test(url))continue;if(el.tagName==='IMG'&&(!el.complete||el.naturalWidth<100))continue;media.push({id:tile.getAttribute('data-id')||tile.getAttribute('data-media-id')||url,url,kind:el.tagName==='VIDEO'?'VIDEO':'IMAGE',text:tile.innerText.slice(0,300)});}}
  return [...new Map(media.map(m=>[m.id,m])).values()];
 }
 function setText(el,text){el.focus();if(el.tagName==='TEXTAREA'||el.tagName==='INPUT'){Object.getOwnPropertyDescriptor(el.tagName==='INPUT'?HTMLInputElement.prototype:HTMLTextAreaElement.prototype,'value').set.call(el,text);}else{el.textContent=text;}el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:text}));el.dispatchEvent(new Event('change',{bubbles:true}));}
 async function choose(value){
  if(!value)return;const exact=e=>label(e)===value.toLocaleLowerCase()||e.textContent.trim().toLocaleLowerCase()===value.toLocaleLowerCase();
  let candidates=unique('button,[role="tab"],[role="radio"],option').filter(exact);
  if(candidates.length===1){candidates[0].click();await sleep(250);return;}
  const opener=unique(S.buttons).filter(e=>/settings|paramètres|ayarlar/.test(label(e))||e.matches('button.settings-trigger-button'));
  one(opener,'Réglages de génération').click();await sleep(300);
  candidates=unique('[role="menuitem"],[role="option"],[role="tab"],[role="radio"],button').filter(exact);one(candidates,`Option « ${value} »`).click();await sleep(300);
 }
 async function chooseMode(mode,frames){
  const aliases=frames?['frames to video','images to video','images vers vidéo','image to video']:mode==='IMAGE'?['image','images','görsel','générer des images']:['video','videos','vidéo','vidéos','text to video'];
  const matches=e=>aliases.includes(e.textContent.trim().toLocaleLowerCase())||aliases.includes((e.getAttribute('aria-label')||'').trim().toLocaleLowerCase());
  let candidates=unique('[role="tab"],[role="radio"],button').filter(matches);
  if(candidates.length===1){if(candidates[0].getAttribute('aria-selected')!=='true'&&candidates[0].getAttribute('aria-checked')!=='true')candidates[0].click();await sleep(250);return;}
  const trigger=unique('button.settings-trigger-button, flow-prompt-box-settings button[aria-haspopup]');one(trigger,'Sélecteur de mode Flow').click();await sleep(300);candidates=unique('[role="tab"],[role="radio"],button').filter(matches);one(candidates,'Mode de génération demandé').click();await sleep(250);
 }
 async function attachFrames(refs,mode){
  const expected=mode==='pair'?2:1;if(refs.length!==expected)throw new Error('Nombre d’images de début/fin invalide.');
  const labels=[/start.*frame|first.*frame|image.*début|première.*image|başlangıç|ilk.*kare/,/end.*frame|last.*frame|image.*fin|dernière.*image|bitiş|son.*kare/];
  for(let i=0;i<expected;i++){
   const slot=one(unique('.frame-trigger, button, [role="button"]').filter(e=>labels[i].test(label(e))),i?'Image de fin':'Image de début');slot.click();await sleep(300);
   const input=one([...document.querySelectorAll('input[type="file"]')].filter(e=>!e.accept||/image/.test(e.accept)),'Import d’image de début/fin');
   const ref=refs[i];if(!/^data:image\/(png|jpeg|webp);base64,/.test(ref.data))throw new Error('Image de début/fin invalide.');const blob=await(await fetch(ref.data)).blob();const dt=new DataTransfer();dt.items.add(new File([blob],ref.name,{type:blob.type}));input.files=dt.files;input.dispatchEvent(new Event('change',{bubbles:true}));await sleep(2500);
   const container=slot.closest('[data-frame-slot], .frame-slot')||slot.parentElement;if(!container?.querySelector('img'))throw new Error('L’image de début/fin n’est pas confirmée. Vérifiez les emplacements dans Flow avant de reprendre.');
  }
 }
 async function attach(refs){
  const chips=()=>unique('flow-ingredient-bar button.chip-container, .ingredient-bar-container .chip-container');
  let existing=chips();
  const matches=(chip,ref)=>label(chip).includes(ref.name.toLocaleLowerCase());
  if(existing.length===refs.length&&refs.every(ref=>existing.some(chip=>matches(chip,ref))))return;
  for(const chip of existing){
   const remove=[...chip.querySelectorAll('*')].filter(e=>!e.children.length&&/^(cancel|close|remove|delete|supprimer)$/i.test((e.textContent||'').trim())||/^(remove|supprimer|retirer)\b/i.test(e.getAttribute('aria-label')||''));
   one(remove,'Retrait de l’ancienne référence').click();await sleep(300);if(chips().includes(chip))throw new Error('Une ancienne référence reste attachée dans Flow. Retirez-la avant de reprendre.');
  }
  if(chips().length)throw new Error('Les anciennes références ne sont pas toutes retirées.');
  if(!refs.length)return;
  const files=[];for(const ref of refs){if(typeof ref.data!=='string'||!/^data:image\/(png|jpeg|webp);base64,/.test(ref.data))throw new Error('Référence image invalide.');const blob=await(await fetch(ref.data)).blob();files.push(new File([blob],ref.name,{type:blob.type}));}
  let inputs=[...document.querySelectorAll('input[type="file"]')].filter(e=>!e.accept||/image/.test(e.accept));
  if(inputs.length!==1){const add=unique(S.buttons).filter(e=>/add reference|ajouter.*référence|upload image|importer.*image/.test(label(e)));one(add,'Ajout de références').click();await sleep(300);inputs=[...document.querySelectorAll('input[type="file"]')].filter(e=>!e.accept||/image/.test(e.accept));}
  const input=one(inputs,'Champ de pièces jointes');const dt=new DataTransfer();for(const f of files)dt.items.add(f);input.files=dt.files;input.dispatchEvent(new Event('change',{bubbles:true}));
  await sleep(2500);const attached=unique('flow-ingredient-bar button.chip-container, .ingredient-bar-container img, flow-prompt-box img');
  if(attached.length!==refs.length||refs.some(ref=>!attached.some(chip=>matches(chip,ref))))throw new Error('Les pièces jointes ne sont pas confirmées dans Flow. Vérifiez-les avant de reprendre.');
 }
 async function handle(m){
  if(!/\/project\//.test(location.pathname))throw new Error('Ouvrez un projet Google Flow, puis synchronisez.');
  if(m.action==='inspect'){const options=unique('[role="option"],[role="tab"],[role="radio"],select option').map(e=>e.textContent.trim()).filter(Boolean);return {url:location.href,title:document.title,options:[...new Set(options)],hasEditor:unique(S.editor).length>0,media:snapshot()};}
  if(m.action==='snapshot')return {media:snapshot()};
  if(m.action==='stage'){
   if(typeof m.prompt!=='string'||!m.prompt.trim()||m.prompt.length>12000)throw new Error('Prompt invalide.');
   if(!Array.isArray(m.refs)||m.refs.length>10)throw new Error('Références invalides.');
   if(m.mode)await chooseMode(m.mode,m.frameMode);for(const value of m.options||[])await choose(value);
   if(m.frameMode)await attachFrames(m.refs,m.frameMode);else await attach(m.refs);const el=editor();setText(el,m.prompt);await sleep(250);
   const scope=el.closest('flow-prompt-box,flow-base-prompt-box,form')||document;
   const btns=unique(S.buttons,scope).filter(e=>/^(generate|générer|generer|oluştur|create|send|envoyer)(\b|\s)|arrow_forward|send$/i.test(label(e))&&!e.disabled&&e.getAttribute('aria-disabled')!=='true');
   const btn=one(btns,'Bouton Générer');const r=btn.getBoundingClientRect();return {media:snapshot(),click:{x:r.x+r.width/2,y:r.y+r.height/2}};
  }
  throw new Error('Action inconnue.');
 }
 chrome.runtime.onMessage.addListener((m,s,reply)=>{if(s.id!==chrome.runtime.id||m?.channel!=='ELPODNA_FLOW')return;handle(m).then(data=>reply({ok:true,data})).catch(e=>reply({ok:false,error:e.message}));return true;});
})();
