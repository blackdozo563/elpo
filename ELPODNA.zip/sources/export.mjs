import {Output,Mp4OutputFormat,StreamTarget,CanvasSource,AudioBufferSource,canEncodeAudio,canEncodeVideo} from 'mediabunny';
import {registerAacEncoder} from './vendor-aac.mjs';
export async function exportFilm({audio,scenes,width,height,motion='fixed',onProgress=()=>{},signal}){
 if(!await canEncodeVideo('avc',{width,height,bitrate:5000000}))throw new Error('L’encodage H.264 est indisponible dans ce navigateur.');
 if(!await canEncodeAudio('aac',{sampleRate:audio.sampleRate,numberOfChannels:audio.numberOfChannels,bitrate:192000}))registerAacEncoder();
 const directory=await navigator.storage.getDirectory();const file=await directory.getFileHandle(`ELPODNA-${crypto.randomUUID()}.mp4`,{create:true});const writable=await file.createWritable();
 const target=new StreamTarget(new WritableStream({write:chunk=>writable.write({type:'write',position:chunk.position,data:chunk.data}),close:()=>writable.close(),abort:()=>writable.abort()}),{chunked:true,chunkSize:4*1024*1024});
 const output=new Output({format:new Mp4OutputFormat({fastStart:'fragmented'}),target});const canvas=new OffscreenCanvas(width,height);const ctx=canvas.getContext('2d');const video=new CanvasSource(canvas,{codec:'avc',bitrate:5000000,keyFrameInterval:2});const sound=new AudioBufferSource({codec:'aac',bitrate:192000});output.addVideoTrack(video,{frameRate:24});output.addAudioTrack(sound);let bitmap;
 try{
  await output.start();const audioTask=sound.add(audio);audioTask.catch(()=>{});
  let current=-1;const count=Math.ceil(audio.duration*24);
  for(let frame=0;frame<count;frame++){
   if(signal?.aborted)throw new DOMException('Export annulé.','AbortError');const time=frame/24;const index=scenes.findIndex(s=>time>=s.start&&time<s.end);if(index<0)throw new Error('Trou dans la timeline.');
   if(current!==index){bitmap?.close();bitmap=await createImageBitmap(scenes[index].blob);current=index;}
   const s=scenes[index],zoom=motion==='zoom'?1+.06*(time-s.start)/(s.end-s.start):1,ratio=Math.max(width/bitmap.width,height/bitmap.height)*zoom,w=bitmap.width*ratio,h=bitmap.height*ratio;
   ctx.fillStyle='#111923';ctx.fillRect(0,0,width,height);ctx.drawImage(bitmap,(width-w)/2,(height-h)/2,w,h);await video.add(time,Math.min(1/24,audio.duration-time));
   if(frame%12===0)onProgress(frame/count*100);
  }
  await audioTask;await output.finalize();onProgress(100);return {file:await file.getFile(),name:file.name};
 }catch(e){await output.cancel().catch(()=>{});await directory.removeEntry(file.name).catch(()=>{});throw e;}finally{bitmap?.close();}
}
