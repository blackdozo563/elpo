import {build} from 'esbuild';import {parse} from 'acorn';import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';import {fileURLToPath} from 'node:url';
const base=fileURLToPath(new URL('.',import.meta.url));process.chdir(base);await mkdir('../extension/vendor',{recursive:true});
const aac=await readFile('node_modules/@mediabunny/aac-encoder/dist/bundles/mediabunny-aac-encoder.mjs','utf8');const ast=parse(aac,{ecmaVersion:'latest',sourceType:'module'});const factory=ast.body.find(n=>n.type==='FunctionDeclaration'&&n.id.name==='Worker2');const inline=ast.body.find(n=>n.type==='FunctionDeclaration'&&n.id.name==='inlineWorker');
if(!factory||!inline)throw new Error('Format du paquet AAC changé ; extraction du worker à revoir.');
const call=factory.body.body.find(n=>n.type==='ReturnStatement')?.argument;const tpl=call?.arguments[0];if(tpl?.type!=='TemplateLiteral'||tpl.expressions.length)throw new Error('Worker AAC non statique.');const worker=tpl.quasis[0].value.cooked;if(!worker)throw new Error('Worker AAC invalide.');
await writeFile('../extension/vendor/aac-worker.js','/*! AAC encoder, MPL-2.0, Vanilagy et contributeurs. Voir licenses/. */\n'+worker);
let converted=aac;for(const [start,end,replacement] of [[factory.start,factory.end,"function Worker2(){return new Worker(new URL('./aac-worker.js',import.meta.url),{type:'module'});}"],[inline.start,inline.end,'']].sort((a,b)=>b[0]-a[0]))converted=converted.slice(0,start)+replacement+converted.slice(end);
await writeFile('vendor-aac.mjs',converted);
await build({entryPoints:['export.mjs'],outfile:'../extension/vendor/export.mjs',bundle:true,format:'esm',platform:'browser',target:'chrome120',minify:true,legalComments:'eof'});
await build({entryPoints:['whisper.mjs'],outfile:'../extension/vendor/whisper.mjs',bundle:true,format:'esm',platform:'browser',target:'chrome120',minify:true,legalComments:'eof'});
for(const name of ['ort-wasm-simd-threaded.jsep.mjs','ort-wasm-simd-threaded.jsep.wasm','ort-wasm-simd-threaded.mjs','ort-wasm-simd-threaded.wasm'])await copyFile('node_modules/onnxruntime-web/dist/'+name,'../extension/vendor/'+name);
await mkdir('../extension/licenses',{recursive:true});
for(const [pkg,dest] of [['mediabunny','mediabunny.txt'],['@mediabunny/aac-encoder','aac-encoder.txt'],['@huggingface/transformers','transformers.txt']])await copyFile('node_modules/'+pkg+'/LICENSE','../extension/licenses/'+dest);
console.log('Workers statiques et dépendances navigateur construits.');

for(const name of ['onnxruntime.txt','onnx-third-party.txt','ffmpeg-lgpl-2.1.txt'])await copyFile('licenses/'+name,'../extension/licenses/'+name);
