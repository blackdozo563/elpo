import {pipeline,env} from '@huggingface/transformers';
env.allowLocalModels=false;env.useBrowserCache=true;env.backends.onnx.wasm.wasmPaths=new URL('./',import.meta.url).href;env.backends.onnx.wasm.numThreads=1;env.backends.onnx.wasm.proxy=false;
self.onmessage=async({data})=>{
 let engine;try{
  if(data.type!=='transcribe'||!(data.audio instanceof Float32Array)||data.audio.length>900*16000)throw new Error('Données audio invalides.');
  const model=data.model==='base'?'onnx-community/whisper-base_timestamped':'onnx-community/whisper-tiny_timestamped';
  engine=await pipeline('automatic-speech-recognition',model,{device:'wasm',dtype:{encoder_model:'fp32',decoder_model_merged:'q8'},progress_callback:p=>postMessage({type:'download',progress:p})});
  const opts={return_timestamps:'word',task:'transcribe',max_new_tokens:256,do_sample:false};if(data.language&&data.language!=='auto')opts.language=data.language;
  const chunks=[];const block=20*16000;
  for(let offset=0;offset<data.audio.length;offset+=block){const section=data.audio.subarray(offset,Math.min(data.audio.length,offset+block));let energy=0;for(const x of section)energy+=x*x;if(Math.sqrt(energy/section.length)<.0003)continue;
   const result=await engine(section,opts);for(const c of result.chunks||[]){const [a,b]=c.timestamp;if(!Number.isFinite(a)||!Number.isFinite(b)||b<=a||!c.text?.trim())continue;chunks.push({start:offset/16000+a,end:Math.min(data.audio.length/16000,offset/16000+b),text:c.text.trim()});}postMessage({type:'progress',percent:Math.min(100,(offset+block)/data.audio.length*100)});
  }
  if(!chunks.length)throw new Error('Aucune parole horodatée reconnue. Essayez un fichier SRT/VTT.');postMessage({type:'result',chunks});
 }catch(e){postMessage({type:'error',message:e.message});}finally{await engine?.dispose();}
};
